#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitImport.cpp"
char sz__TFormTulkinta[(int)sizeof(TFormTulkinta)];
char sz__rivitulkintatp[(int)sizeof(rivitulkintatp)];
