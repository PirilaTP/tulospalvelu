#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitNollaus.cpp"
char off__TFormNollaus__CBTulokset[(int)(long)&(((TFormNollaus*)0)->CBTulokset)+1];
char off__TFormNollaus__CBEil[(int)(long)&(((TFormNollaus*)0)->CBEil)+1];
char off__TFormNollaus__CBPoissa[(int)(long)&(((TFormNollaus*)0)->CBPoissa)+1];
char off__TFormNollaus__CBEmit[(int)(long)&(((TFormNollaus*)0)->CBEmit)+1];
char off__TFormNollaus__CBRadat[(int)(long)&(((TFormNollaus*)0)->CBRadat)+1];
char off__TFormNollaus__CBVa[(int)(long)&(((TFormNollaus*)0)->CBVa)+1];
char off__TFormNollaus__Label1[(int)(long)&(((TFormNollaus*)0)->Label1)+1];
char off__TFormNollaus__CBOsuudet[(int)(long)&(((TFormNollaus*)0)->CBOsuudet)+1];
char off__TFormNollaus__RGSarjat[(int)(long)&(((TFormNollaus*)0)->RGSarjat)+1];
char off__TFormNollaus__LBSarjat[(int)(long)&(((TFormNollaus*)0)->LBSarjat)+1];
char off__TFormNollaus__Label2[(int)(long)&(((TFormNollaus*)0)->Label2)+1];
char off__TFormNollaus__Button1[(int)(long)&(((TFormNollaus*)0)->Button1)+1];
char off__TFormNollaus__MainMenu1[(int)(long)&(((TFormNollaus*)0)->MainMenu1)+1];
char off__TFormNollaus__Erikoistoiminnot1[(int)(long)&(((TFormNollaus*)0)->Erikoistoiminnot1)+1];
char off__TFormNollaus__Kerrokaikkiajatkymmenell1[(int)(long)&(((TFormNollaus*)0)->Kerrokaikkiajatkymmenell1)+1];
char off__TFormNollaus__Jaakaikkiajatkymmenell1[(int)(long)&(((TFormNollaus*)0)->Jaakaikkiajatkymmenell1)+1];
char off__TFormNollaus__LblTila[(int)(long)&(((TFormNollaus*)0)->LblTila)+1];
char off__TFormNollaus__N1[(int)(long)&(((TFormNollaus*)0)->N1)+1];
char off__TFormNollaus__Suljekaavake1[(int)(long)&(((TFormNollaus*)0)->Suljekaavake1)+1];
char off__TFormNollaus__Poistamiljoonat[(int)(long)&(((TFormNollaus*)0)->Poistamiljoonat)+1];
char off__TFormNollaus__CBPisteet[(int)(long)&(((TFormNollaus*)0)->CBPisteet)+1];
char off__TFormNollaus__CBFlags[(int)(long)&(((TFormNollaus*)0)->CBFlags)+1];
char off__TFormNollaus__Vaihdaetusuku[(int)(long)&(((TFormNollaus*)0)->Vaihdaetusuku)+1];
char off__TFormNollaus__vaihdaetusuku[(int)(long)&(((TFormNollaus*)0)->vaihdaetusuku)+1];
