	.386p
	ifdef ??version
	if ??version GT 500H
	.mmx
	endif
	endif
	model flat
	ifndef	??version
	?debug	macro
	endm
	endif
	?debug	S "vi.cpp"
	?debug	T "vi.cpp"
_TEXT	segment dword public use32 'CODE'
_TEXT	ends
_DATA	segment dword public use32 'DATA'
_DATA	ends
_BSS	segment dword public use32 'BSS'
_BSS	ends
DGROUP	group	_BSS,_DATA
_TEXT	segment dword public use32 'CODE'
@VersioInt$qv	segment virtual
	align	2
@@VersioInt$qv	proc	near
?live16385@0:
 ;	
 ;	int VersioInt(void) { return((int)(100*_wtof(VERSIOKDI))); }
 ;	
@1:
	push      offset s@
	call      @__wtof
	pop       ecx
	fmul      dword ptr [@2]
	call      __ftol
@4:
@3:
	ret 
	align 4        
@2:
	db	0,0,200,66
@@VersioInt$qv	endp
@VersioInt$qv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@VersioInt20$qv	segment virtual
	align	2
@@VersioInt20$qv	proc	near
?live16386@0:
 ;	
 ;	int VersioInt20(void) { return((int)(100*_wtof(L"5.20"))); }
 ;	
@5:
	push      offset s@+10
	call      @__wtof
	pop       ecx
	fmul      dword ptr [@6]
	call      __ftol
@8:
@7:
	ret 
	align 4        
@6:
	db	0,0,200,66
@@VersioInt20$qv	endp
@VersioInt20$qv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
_main	segment virtual
	align	2
@_main	proc	near
?live16387@0:
 ;	
 ;	int main(){ printf("cw=%04X VersioInt=%d v520=%d\n", _control87(0,0), VersioInt(), VersioInt20()); return 0; }
 ;	
@9:
	call      @@VersioInt20$qv
	push      eax
	call      @@VersioInt$qv
	push      eax
	push      0
	push      0
	call      @__control87
	add       esp,8
	push      eax
	push      offset s@+20
	call      @_printf
	add       esp,16
	xor       eax,eax
@11:
@10:
	ret 
@_main	endp
_main	ends
_TEXT	ends
_DATA	segment dword public use32 'DATA'
	align	2
s@	label	byte
	;	s@+0:
	db	"5",0
	;	s@+2:
	db	".",0
	;	s@+4:
	db	"2",0
	;	s@+6:
	db	"1",0,0,0
	;	s@+10:
	db	"5",0
	;	s@+12:
	db	".",0
	;	s@+14:
	db	"2",0
	;	s@+16:
	db	"0",0,0,0
	;	s@+20:
	db	"cw=%04X VersioInt=%d v520=%d",10,0
	align	4
_DATA	ends
_TEXT	segment dword public use32 'CODE'
_TEXT	ends
@__wtof equ __wtof
 extrn __wtof:near
 extrn __ftol:near
@_printf equ _printf
 extrn _printf:near
@__control87 equ __control87
 extrn __control87:near
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\mem.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\_loc.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\locale.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\_str.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\tchar.h" 23780 45058
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\wchar.h" 23780 45058
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\float.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\errno.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\search.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\stdlib.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\_nfile.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\_null.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\_defs.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\_stddef.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\stdio.h" 23780 45057
	?debug	D "vi.cpp" 23929 16864
	end
