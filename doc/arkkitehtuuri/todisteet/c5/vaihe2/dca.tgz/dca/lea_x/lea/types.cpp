// Probe: fundamental type sizes/alignment/bit-field layout. No file I/O.
#include <stdio.h>
#include <stddef.h>
#include <time.h>
#include <wchar.h>
#include <string.h>
template<class T> struct AL{ char c; T t; };
#define ALIGNOF(T) ((int)offsetof(AL<T>,t))
#define SA(T) printf("%-18s size=%2d align=%2d\n", #T, (int)sizeof(T), ALIGNOF(T))
enum E1 { E1a, E1b };
enum E2 { E2a = 70000 };
enum E3 { E3a = -1 };
struct Bf  { unsigned a:3; unsigned b:5; unsigned c:1; int d:4; };
struct Bf2 { unsigned char a:3; unsigned short b:5; unsigned c:1; };
struct Bf3 { int a:4; int b:4; bool f:1; bool g:1; };
struct Mix { char c; bool b; short s; int i; long l; double d; long double ld; time_t t; wchar_t w; E1 e; __int64 q; };
#pragma pack(push,1)
struct P1  { char c; bool b; short s; int i; long l; double d; long double ld; time_t t; wchar_t w; E1 e; __int64 q; };
struct Bf1p { unsigned a:3; unsigned b:5; unsigned c:1; int d:4; };
struct Bf2p { unsigned char a:3; unsigned short b:5; unsigned c:1; };
struct Bf3p { int a:4; int b:4; bool f:1; bool g:1; };
#pragma pack(pop)
static void hex(const char*tag,const void*p,int n){ printf("%s:",tag); for(int i=0;i<n;i++) printf(" %02X",((const unsigned char*)p)[i]); printf("\n"); }
int main(){
 SA(char); SA(short); SA(int); SA(long); SA(__int64); SA(float); SA(double); SA(long double); SA(bool); SA(wchar_t); SA(time_t); SA(void*); SA(size_t);
 SA(E1); SA(E2); SA(E3); SA(Bf); SA(Bf2); SA(Bf3); SA(Bf1p); SA(Bf2p); SA(Bf3p);
 printf("Mix size=%d offs c=%d b=%d s=%d i=%d l=%d d=%d ld=%d t=%d w=%d e=%d q=%d\n",(int)sizeof(Mix),(int)offsetof(Mix,c),(int)offsetof(Mix,b),(int)offsetof(Mix,s),(int)offsetof(Mix,i),(int)offsetof(Mix,l),(int)offsetof(Mix,d),(int)offsetof(Mix,ld),(int)offsetof(Mix,t),(int)offsetof(Mix,w),(int)offsetof(Mix,e),(int)offsetof(Mix,q));
 printf("P1  size=%d offs ld=%d t=%d w=%d e=%d q=%d\n",(int)sizeof(P1),(int)offsetof(P1,ld),(int)offsetof(P1,t),(int)offsetof(P1,w),(int)offsetof(P1,e),(int)offsetof(P1,q));
 { Bf b; memset(&b,0,sizeof b); b.a=5; b.b=19; b.c=1; b.d=-3; hex("Bf bytes",&b,sizeof b); }
 { Bf2 b; memset(&b,0,sizeof b); b.a=5; b.b=19; b.c=1; hex("Bf2 bytes",&b,sizeof b); }
 { Bf3 b; memset(&b,0,sizeof b); b.a=5; b.b=-2; b.f=1; b.g=1; hex("Bf3 bytes",&b,sizeof b); }
 { Bf2p b; memset(&b,0,sizeof b); b.a=5; b.b=19; b.c=1; hex("Bf2p bytes",&b,sizeof b); }
 { Bf3p b; memset(&b,0,sizeof b); b.a=5; b.b=-2; b.f=1; b.g=1; hex("Bf3p bytes",&b,sizeof b); }
 printf("char signed? %d  (int)(char)0xE4=%d\n",(char)0xE4<0,(int)(char)0xE4);
 { bool t=true; unsigned char raw; memcpy(&raw,&t,1); int v=5; bool bb=(bool)v; unsigned char r2; memcpy(&r2,&bb,1); printf("bool true raw=%d  (bool)5 raw=%d\n",raw,r2); }
 { long double x=1.5L; hex("long double 1.5",&x,sizeof x); }
 { time_t t=-1; printf("time_t signed? %d\n", t<0); }
 { printf("(int)E3a=%d  (int)E2a=%d\n",(int)E3a,(int)E2a); }
 { int a=-7, b=2; printf("-7/2=%d -7%%2=%d -7>>1=%d\n",a/b,a%b,a>>1); }
 return 0;}
