#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitNappain.cpp"
char sz__TFormNappain[(int)sizeof(TFormNappain)];
