#include <stdio.h>
#include "kk.h"
#pragma hdrstop
int after4(char c){ return c < 0; }
int main(){ char c=(char)0xE4; printf("after4=%d\n", after4(c)); return 0; }
