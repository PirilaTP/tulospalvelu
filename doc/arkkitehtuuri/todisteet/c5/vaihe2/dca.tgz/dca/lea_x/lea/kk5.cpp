#include <stdio.h>
int c_before = '�';
char arr_before[256];
#include "kk.h"
int c_after = '�';
const char *s_after = "�";
int main(){ char t[256]; t[(int)('�')]=1; printf("c_before=%d c_after=%d sizeof('�')=%d (int)s_after[0]=%d idx=%d\n", c_before, c_after, (int)sizeof('�'), (int)s_after[0], (int)'�'); return 0;}
