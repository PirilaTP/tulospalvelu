#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitKirjoitinVal.cpp"
char sz__TFormKirjVal[(int)sizeof(TFormKirjVal)];
