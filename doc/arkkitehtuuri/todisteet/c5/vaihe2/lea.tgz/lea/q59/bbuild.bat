@echo off
set BIN=c:\program files (x86)\embarcadero\studio\37.0\bin
set LR=c:\program files (x86)\embarcadero\studio\37.0\lib\win32\release
set TP=C:\dev\tulospalvelu\TPsource\V52
cd /d "%~dp0\bcc"
"%BIN%\bcc32.exe" @..\..\tf.args -S -oTextFileClass.asm "%TP%\tputilv2\TextFileClass.cpp" > cc_asm.txt 2>&1
"%BIN%\bcc32.exe" @..\..\tf.args -oTextFileClass.obj "%TP%\tputilv2\TextFileClass.cpp" > cc_tf.txt 2>&1
"%BIN%\bcc32.exe" @..\..\tf.args -I"%TP%\Tp" -ogs59.obj ..\gs59.cpp > cc_main.txt 2>&1
"%BIN%\ilink32.exe" -ap -Tpe -L"%LR%";"%LR%\psdk" c0x32w gs59.obj TextFileClass.obj , gs59_bcc.exe , , "%TP%\..\..\TPexe\Lib\V521\release_build\Tputil-XE.lib" import32.lib cw32mti.lib , , > link.txt 2>&1
