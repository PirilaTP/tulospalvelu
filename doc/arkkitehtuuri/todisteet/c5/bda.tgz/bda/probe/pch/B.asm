	.386p
	ifdef ??version
	if ??version GT 500H
	.mmx
	endif
	endif
	model flat
	ifndef	??version
	?debug	macro
	endm
	endif
	?debug	S "B.cpp"
	?debug	T "B.cpp"
_TEXT	segment dword public use32 'CODE'
_TEXT	ends
_DATA	segment dword public use32 'DATA'
_DATA	ends
_BSS	segment dword public use32 'BSS'
_BSS	ends
DGROUP	group	_BSS,_DATA
_BSS	segment dword public use32 'BSS'
_sz_B_HS	label	byte
	db	5	dup(?)
_sz_B_BS	label	byte
	db	5	dup(?)
_sgn_B	label	byte
	db	2	dup(?)
_BSS	ends
_TEXT	segment dword public use32 'CODE'
_TEXT	ends
	public	_sz_B_HS
	public	_sz_B_BS
	public	_sgn_B
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\_nfile.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\_null.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\_defs.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\_stddef.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\stdio.h" 23780 45057
	?debug	D "hdr.h" 23929 2049
	?debug	D "B.cpp" 23929 2049
	end
