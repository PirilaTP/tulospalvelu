#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitAutoFile.cpp"
char sz__TFormAutoFile[(int)sizeof(TFormAutoFile)];
