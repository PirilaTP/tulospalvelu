# For each unit compiled in HkKisaWin (from cbproj CppCompile), does the include DFS (ignoring #if) reach tputil.h, and what repo code precedes it.
import re, os, sys, xml.etree.ElementTree as ET
BSL=chr(92)
ROOT='C:/dev/tulospalvelu/TPsource/V52'
RAD=ROOT+'/RADStudio10'
inc_dirs=['cbTp','cbHk','tputilv2','Tp','include','com','Hk','.']  # relative to V52 (RAD relative ..\x)
def load(p):
    try: return open(p,'rb').read().decode('cp1252',errors='replace')
    except Exception: return None
cache={}
def resolve(name, cur_dir):
    cands=[os.path.join(cur_dir,name)]+[os.path.join(ROOT,d,name) for d in inc_dirs]
    for c in cands:
        c=os.path.normpath(c)
        if os.path.isfile(c): return c
    return None
def strip_comments(t):
    return t
def walk(path, visited, order, state):
    # returns True if tputil.h reached (state['reached']); records code lines before.
    if path in visited: return
    visited.add(path)
    t=cache.get(path) or load(path)
    if t is None: return
    cache[path]=t
    t=strip_comments(t)
    for ln,line in enumerate(t.split('\n'),1):
        m=re.match(r'\s*#\s*include\s*[<"]([^>"]+)[>"]',line)
        if m:
            nm=m.group(1).replace(BSL,'/')
            if os.path.basename(nm).lower()=='tputil.h':
                if not state['reached']: state['reached']=(path,ln)
                continue
            r=resolve(nm, os.path.dirname(path))
            if r and r.startswith(os.path.normpath(ROOT)): walk(r,visited,order,state)
            continue
        if state['reached']: return
        s=line.strip()
        if s and not s.startswith('#') and not s.startswith('//') and not s.startswith('/*') and not s.startswith('*'):
            state['code'].append((os.path.relpath(path,ROOT).replace(os.sep,'/'),ln,s[:70]))
    return
tree=ET.parse(RAD+'/HkKisaWin.cbproj')
units=[]
for e in tree.iter():
    if e.tag.endswith('CppCompile') and e.get('Include'):
        units.append(e.get('Include'))
print(len(units),'units')
res=[]
for u in units:
    p=os.path.normpath(os.path.join(RAD,u.replace(BSL,'/')))
    state={'reached':None,'code':[]}
    walk(p,set(),[],state)
    res.append((os.path.relpath(p,ROOT).replace(os.sep,'/'),state))
nr=[r for r in res if not r[1]['reached']]
print('units never reaching tputil.h (whole unit signed char):',len(nr))
for p,s in nr: print('  NOTREACHED',p)
print('units reaching tputil.h only after repo code:')
for p,s in res:
    if s['reached'] and s['code']:
        print('  ',p,'reach at',s['reached'][0].replace(ROOT,'')[1:],s['reached'][1],'code lines before:',len(s['code']),s['code'][:2])
