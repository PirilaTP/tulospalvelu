#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitArvonta.cpp"
char sz__TFormSarjatiedot[(int)sizeof(TFormSarjatiedot)];
