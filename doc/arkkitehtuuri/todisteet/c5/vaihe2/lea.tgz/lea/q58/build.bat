@echo off
set BIN=c:\program files (x86)\embarcadero\studio\37.0\bin
set LR=c:\program files (x86)\embarcadero\studio\37.0\lib\win32\release
set INC=-I"c:\program files (x86)\embarcadero\studio\37.0\include";"c:\program files (x86)\embarcadero\studio\37.0\include\dinkumware";"c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl";"c:\program files (x86)\embarcadero\studio\37.0\include\windows\sdk"
rem dynamic RTL (as GUI: -tR -tM), unicode console entry c0x32w
"%BIN%\bcc32.exe" -Q -c -tR -tM -tWC -O2 %INC% -DUSE_CT -n. -owt58_dyn_ct.obj wt58.cpp > dyn_ct.cc.txt 2>&1
"%BIN%\ilink32.exe" -ap -Tpe -L"%LR%";"%LR%\psdk" c0x32 wt58_dyn_ct.obj , wt58_dyn_ct.exe , , import32.lib cw32mti.lib , , > dyn_ct.link.txt 2>&1
"%BIN%\bcc32.exe" -Q -c -tR -tM -tWC -O2 %INC% -n. -owt58_dyn_bt.obj wt58.cpp > dyn_bt.cc.txt 2>&1
"%BIN%\ilink32.exe" -ap -Tpe -L"%LR%";"%LR%\psdk" c0x32 wt58_dyn_bt.obj , wt58_dyn_bt.exe , , import32.lib cw32mti.lib , , > dyn_bt.link.txt 2>&1
rem static RTL control
"%BIN%\bcc32.exe" -Q -c -tM -tWC -O2 %INC% -DUSE_CT -n. -owt58_st_ct.obj wt58.cpp > st_ct.cc.txt 2>&1
"%BIN%\ilink32.exe" -ap -Tpe -L"%LR%";"%LR%\psdk" c0x32 wt58_st_ct.obj , wt58_st_ct.exe , , import32.lib cw32mt.lib , , > st_ct.link.txt 2>&1
