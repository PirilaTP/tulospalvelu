#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitYLahdot.cpp"
char off__TFormYLahdot__LBSarjat[(int)(long)&(((TFormYLahdot*)0)->LBSarjat)+1];
char off__TFormYLahdot__BtnLisKaikki[(int)(long)&(((TFormYLahdot*)0)->BtnLisKaikki)+1];
char off__TFormYLahdot__BtnLisValitut[(int)(long)&(((TFormYLahdot*)0)->BtnLisValitut)+1];
char off__TFormYLahdot__BtnPoisValitut[(int)(long)&(((TFormYLahdot*)0)->BtnPoisValitut)+1];
char off__TFormYLahdot__BtnPoisKaikki[(int)(long)&(((TFormYLahdot*)0)->BtnPoisKaikki)+1];
char off__TFormYLahdot__LBSarjaVal[(int)(long)&(((TFormYLahdot*)0)->LBSarjaVal)+1];
char off__TFormYLahdot__Label9[(int)(long)&(((TFormYLahdot*)0)->Label9)+1];
char off__TFormYLahdot__Label8[(int)(long)&(((TFormYLahdot*)0)->Label8)+1];
char off__TFormYLahdot__SG1[(int)(long)&(((TFormYLahdot*)0)->SG1)+1];
char off__TFormYLahdot__Button1[(int)(long)&(((TFormYLahdot*)0)->Button1)+1];
char off__TFormYLahdot__Button2[(int)(long)&(((TFormYLahdot*)0)->Button2)+1];
char off__TFormYLahdot__Button3[(int)(long)&(((TFormYLahdot*)0)->Button3)+1];
char off__TFormYLahdot__Label1[(int)(long)&(((TFormYLahdot*)0)->Label1)+1];
char off__TFormYLahdot__Label2[(int)(long)&(((TFormYLahdot*)0)->Label2)+1];
char off__TFormYLahdot__Button6[(int)(long)&(((TFormYLahdot*)0)->Button6)+1];
char off__TFormYLahdot__BitBtn1[(int)(long)&(((TFormYLahdot*)0)->BitBtn1)+1];
char off__TFormYLahdot__SarjaValinnat[(int)(long)&(((TFormYLahdot*)0)->SarjaValinnat)+1];
