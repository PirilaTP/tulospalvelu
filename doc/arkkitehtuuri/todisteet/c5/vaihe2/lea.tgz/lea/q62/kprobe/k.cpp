// Q62b probe: do VCL/RTL/std header inlines change codegen with char signedness (-K)?
#include <vcl.h>
#pragma hdrstop
#include <string>
#include <ctype.h>
#include <algorithm>
bool f_lt(char a, char b)            { return std::char_traits<char>::lt(a, b); }
int  f_toint(char a)                 { return std::char_traits<char>::to_int_type(a); }
bool f_strless(const std::string &a, const std::string &b) { return a < b; }
bool f_cmp(const char *a, const char *b) { return std::lexicographical_compare(a, a + 3, b, b + 3); }
int  f_ucs_char(char c)              { UnicodeString u(c); return u.Length(); }
int  f_ucs_cmp(const UnicodeString &a, const UnicodeString &b) { return a < b; }
int  f_ans_char(char c)              { AnsiString s(c); return s.Length() + (s == "x"); }
int  f_isalpha(char c)               { return isalpha(c) + isdigit(c) + isspace(c) + toupper(c); }
int  f_cast(char c)                  { return c; }
