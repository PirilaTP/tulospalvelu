// Probe: member offsets of raw-written/network structs (Hk build). Includes the repo headers.
#include "HkDeclare.h"
#include <stddef.h>
#include <stdio.h>
#define O(T,m) printf("  %-10s.%-10s off=%3d size=%3d\n",#T,#m,(int)offsetof(T,m),(int)sizeof(((T*)0)->m))
int wmain(){
 printf("sizeof aikatp=%d emittp=%d emitvatp=%d combufrec=%d\n",(int)sizeof(aikatp),(int)sizeof(emittp),(int)sizeof(emitvatp),(int)sizeof(combufrec));
 O(aikatp,t);O(aikatp,date);O(aikatp,kno);O(aikatp,piste);O(aikatp,tapahtuma);O(aikatp,badge);O(aikatp,kanava);O(aikatp,jono);O(aikatp,status);
 O(emittp,package);O(emittp,badge);O(emittp,badgeyear);O(emittp,maali);O(emittp,time);O(emittp,ctrlcode);O(emittp,ctrltime);O(emittp,sc);O(emittp,kilpno);O(emittp,osuus);O(emittp,badge0);O(emittp,kirjaus);
 O(emitvatp,kilpno);O(emitvatp,tulos);O(emitvatp,rastiluku);O(emitvatp,rata);O(emitvatp,ok);O(emitvatp,rastit);
 O(combufrec,lahetetty);O(combufrec,portti);O(combufrec,so);O(combufrec,pkgclass);O(combufrec,len);O(combufrec,checksum);O(combufrec,d);
 O(combufrec,d.k.ckilp);O(combufrec,d.pv.cpv);O(combufrec,d.a.daika);O(combufrec,d.a.iaika);O(combufrec,d.lm.keskhyl);O(combufrec,d.sra.snimi);O(combufrec,d.ec.piste);O(combufrec,d.fl.buf);
#if defined(EMIT)
 O(combufrec,d.em);O(combufrec,d.emva);
#endif
 return 0;}
