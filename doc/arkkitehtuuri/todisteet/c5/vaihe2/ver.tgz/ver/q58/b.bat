@echo off
set BIN=c:\program files (x86)\embarcadero\studio\37.0\bin
set LR=c:\program files (x86)\embarcadero\studio\37.0\lib\win32\release
"%BIN%\ilink32.exe" -ap -Tpe -L"%LR%";"%LR%\psdk" c0x32 wt.obj , wt.exe , , import32.lib cp32mti.lib , , > ln.txt 2>&1
"%BIN%\tdump.exe" -em wt.exe > td.txt 2>&1
