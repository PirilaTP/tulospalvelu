@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars32.bat" >nul
cl /nologo /O2 /MT /GS /EHsc wfo.cpp /Fe:wfo-msvc.exe > build-msvc.txt 2>&1
wfo-msvc.exe > wfo-msvc.out 2>&1
echo exit=%ERRORLEVEL% >> wfo-msvc.out
