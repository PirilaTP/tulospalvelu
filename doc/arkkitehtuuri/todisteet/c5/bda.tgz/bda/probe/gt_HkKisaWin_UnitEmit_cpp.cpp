#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitEmit.cpp"
char sz__TFormEmitFile[(int)sizeof(TFormEmitFile)];
char sz__TFormEmitMuutokset[(int)sizeof(TFormEmitMuutokset)];
char sz__TFormKirjVal[(int)sizeof(TFormKirjVal)];
