@echo off
set BIN=c:\program files (x86)\embarcadero\studio\37.0\bin
set TP=C:\dev\tulospalvelu\TPsource\V52
cd /d "%~dp0\RADStudio10dir"
"%BIN%\bcc32.exe" @..\args_gui.txt -S -o..\pch\HkKisaWin.asm -H=..\pch\HkKisaWin.pch -H %TP%\RADStudio10\HkKisaWin.cpp > ..\pch\HkKisaWin.txt 2>&1
"%BIN%\bcc32.exe" @..\args_gui.txt -S -o..\pch\UnitEmitMuutokset.asm -H=..\pch\HkKisaWin.pch -H %TP%\cbHk\UnitEmitMuutokset.cpp > ..\pch\UnitEmitMuutokset.txt 2>&1
"%BIN%\bcc32.exe" @..\args_gui.txt -S -o..\nopch\UnitEmitMuutokset.asm %TP%\cbHk\UnitEmitMuutokset.cpp > ..\nopch\UnitEmitMuutokset.txt 2>&1
