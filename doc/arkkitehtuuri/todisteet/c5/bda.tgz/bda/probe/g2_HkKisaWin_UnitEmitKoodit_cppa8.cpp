#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitEmitKoodit.cpp"
char off__TFormEmitKoodit__SG1[(int)(long)&(((TFormEmitKoodit*)0)->SG1)+1];
char off__TFormEmitKoodit__Button1[(int)(long)&(((TFormEmitKoodit*)0)->Button1)+1];
char off__TFormEmitKoodit__Button2[(int)(long)&(((TFormEmitKoodit*)0)->Button2)+1];
char off__TFormEmitKoodit__Button3[(int)(long)&(((TFormEmitKoodit*)0)->Button3)+1];
char off__TFormEmitKoodit__CBVaiheet[(int)(long)&(((TFormEmitKoodit*)0)->CBVaiheet)+1];
char off__TFormEmitKoodit__Label1[(int)(long)&(((TFormEmitKoodit*)0)->Label1)+1];
char off__TFormEmitKoodit__RGBadge[(int)(long)&(((TFormEmitKoodit*)0)->RGBadge)+1];
char off__TFormEmitKoodit__BitBtn1[(int)(long)&(((TFormEmitKoodit*)0)->BitBtn1)+1];
char off__TFormEmitKoodit__RGLaina[(int)(long)&(((TFormEmitKoodit*)0)->RGLaina)+1];
