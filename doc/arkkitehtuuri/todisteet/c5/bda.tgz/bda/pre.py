import os,re,subprocess,sys,json,collections
from multiprocessing import Pool
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import ana
S=ana.SCR;WORK=ana.WORK
PFX=ana.PFX
def work(a):
    proj,n,src,cmd=a
    cmd=cmd.replace('bcc32.exe','cpp32.exe',1)
    cmd=re.sub(r' -o\S+','',cmd);cmd=re.sub(r' -n\S+','',cmd);cmd=re.sub(r' -H=\S+',' ',cmd);cmd=re.sub(r' -H(c)? ',' ',cmd);cmd=cmd.replace(' -c ',' ')
    exe,rest=cmd.split('.exe ',1)
    out=os.path.join(ana.TMP,'pre_%s_%03d.i'%(proj,n))
    p=subprocess.run('"'+exe+'.exe" '+rest[:-len(src)]+'-o'+out+' '+src,cwd=WORK,capture_output=True,text=True,encoding='cp1252',errors='replace')
    code=collections.Counter();seen=False;firstcode={}
    with open(out,encoding='cp1252',errors='replace') as f:
        for ln in f:
            m=PFX.match(ln)
            if not m: continue
            fl,no,body=m.group(1),int(m.group(2)),m.group(3)
            if 'option -K -a1' in body and 'tputil.h' in fl.lower(): seen=True;break
            nf=ana.norm(fl)
            if nf and body.strip() and not body.lstrip().startswith('#'):
                code[nf]+=1
                firstcode.setdefault(nf,no)
    os.remove(out)
    return {'proj':proj,'src':src,'seen':seen,'code':dict(code),'first':firstcode}
if __name__=='__main__':
    jobs=[]
    for proj in ['HkKisaWin','ViestiWin']:
        for n,(s,c) in enumerate(ana.getcmds(proj)): jobs.append((proj,n,s,c))
    with Pool(6) as pool: res=pool.map(work,jobs)
    json.dump(res,open(S+'/pre_res.json','w'))
    print('done',len(res))
