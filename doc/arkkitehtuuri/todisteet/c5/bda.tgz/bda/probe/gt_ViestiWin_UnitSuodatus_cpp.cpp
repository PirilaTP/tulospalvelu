#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitSuodatus.cpp"
char sz__TFormSuodatus[(int)sizeof(TFormSuodatus)];
