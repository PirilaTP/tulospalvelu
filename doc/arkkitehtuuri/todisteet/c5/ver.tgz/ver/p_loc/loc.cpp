#include <stdio.h>
#include <wchar.h>
#include <wctype.h>
#include <locale.h>
static void t(const char *tag){ printf("%-22s iswalnum(E4)=%d iswalnum(C4)=%d iswalnum(0161)=%d towupper(E4)=%04X\n",tag,!!iswalnum(0xE4),!!iswalnum(0xC4),!!iswalnum(0x161),(unsigned)towupper(0xE4)); }
int main(){
  t("default (C)");
  const wchar_t *r=_wsetlocale(LC_CTYPE, L"fi-FI"); printf("_wsetlocale(LC_CTYPE,fi-FI) -> %ls\n", r? r: L"(NULL)");
  t("after fi-FI");
  r=_wsetlocale(LC_CTYPE, L""); printf("_wsetlocale(LC_CTYPE,\"\") -> %ls\n", r? r: L"(NULL)");
  t("after \"\"");
  return 0;}
