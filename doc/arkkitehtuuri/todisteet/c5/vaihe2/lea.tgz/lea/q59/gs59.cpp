// Q59 probe: reach TextFl::Open (tputilv2/TextFileClass.cpp:347 wchar_t mode[16]) with TextType 'W'.
// usage: gs59 <utf16le-file> <mode for Open>   (prints before/after; a /GS hit ends the process with 0xC0000409)
#include <windows.h>
#include <stdio.h>
#include <wchar.h>
#include "tputil.h"
int wmain(int argc, wchar_t **argv)
{
	if (argc < 3) return 2;
	{ FILE *f = _wfopen(argv[1], L"wb"); const unsigned char b[] = {0xFF,0xFE,'a',0,'b',0,13,0,10,0}; fwrite(b,1,sizeof b,f); fclose(f); }
	SetFileAttributesW(argv[1], FILE_ATTRIBUTE_READONLY);   // read-only copy: Open("r+") then fails to open, not a crash cause
	TextFl t(argv[1], L"r");               // autodetect: BOM FF FE -> TextType 'W'
	wchar_t buf[40]; wchar_t *r = t.ReadLine(buf, 40);
	wprintf(L"ctor ok, first line=%ls\n", r ? buf : L"(null)"); fflush(stdout);
	int rc = t.Open(argv[2]);               // overflow site
	wprintf(L"Open(%ls) returned %d (process survived)\n", argv[2], rc); fflush(stdout);
	t.Close();
	return 0;
}
