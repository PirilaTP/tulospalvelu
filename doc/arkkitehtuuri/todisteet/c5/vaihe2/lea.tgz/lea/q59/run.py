import subprocess,os,stat,sys
os.makedirs('run',exist_ok=True)
for v in ('gl','nogl','nogs'):
    for m in ('r','w','r+'):
        p='run/t.txt'
        if os.path.exists(p): os.chmod(p,stat.S_IWRITE); os.remove(p)
        r=subprocess.run(['./gs59_%s.exe'%v,p,m],capture_output=True)
        print('%-6s Open(%-2s) rc=0x%08X  %s'%(v,m,r.returncode&0xFFFFFFFF,r.stdout.decode('utf-8','replace').replace('\r','').replace('\n',' | ')))
