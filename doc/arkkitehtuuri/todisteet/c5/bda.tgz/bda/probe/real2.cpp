#include <stdlib.h>
#include <ctype.h>
#include <tputil.h>
#include <boxr.h>
#ifdef WIN32
char macro_WIN32_defined[1];
#endif
#ifdef _WIN32
char macro__WIN32_defined[1];
#endif
#ifdef _CONSOLE
char macro__CONSOLE_defined[1];
#endif
#ifdef UNICODE
char macro_UNICODE_defined[1];
#endif
#ifdef _UNICODE
char macro__UNICODE_defined[1];
#endif
#ifdef _BORLAND_
char macro__BORLAND__defined[1];
#endif
#ifdef _MBCS
char macro__MBCS_defined[1];
#endif
char sz_datafile[(int)sizeof(datafile)];
char sz_HANDLE[(int)sizeof(HANDLE)];
