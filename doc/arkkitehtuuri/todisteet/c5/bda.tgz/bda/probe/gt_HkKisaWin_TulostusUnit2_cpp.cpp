#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/TulostusUnit2.cpp"
char sz__TFormAutoFile[(int)sizeof(TFormAutoFile)];
char sz__TFormHtmlEdit[(int)sizeof(TFormHtmlEdit)];
char sz__TFormLisaTekstit[(int)sizeof(TFormLisaTekstit)];
char sz__TFormMuotoilu[(int)sizeof(TFormMuotoilu)];
