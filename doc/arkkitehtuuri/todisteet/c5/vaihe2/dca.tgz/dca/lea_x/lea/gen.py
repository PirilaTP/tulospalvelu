src = r'''#include <stdio.h>
#include <wchar.h>
const char  n1[] = "%s";
const wchar_t w1[] = L"%s";
const char  c1 = '%c';
const wchar_t c2 = L'%c';
const char  c3 = '%c';
int sw(char c){ switch(c){ case '%c': return 1; case 'a': return 2; default: return 0; } }
int swu(unsigned char c){ switch(c){ case '%c': return 1; default: return 0; } }
int swW(wchar_t c){ switch(c){ case L'%c': return 1; default: return 0; } }
int main(){
 int i; printf("N:"); for(i=0;i<(int)sizeof n1;i++) printf(" %%02X",(unsigned char)n1[i]);
 printf("\nW:"); for(i=0;i<(int)(sizeof w1/sizeof w1[0]);i++) printf(" %%04X",(unsigned)w1[i]);
 printf("\nc1=%%d c2=%%04X c3=%%d\n", (int)c1,(unsigned)c2,(int)c3);
 printf("sw(byte E4)=%%d sw(0xE4)=%%d swu(0xE4)=%%d swW(0xE4)=%%d sizeof(c1lit)=%%d sizeof(wlit)=%%d\n", sw((char)0xE4), sw(-28), swu(0xE4), swW(0xE4), (int)sizeof('%c'), (int)sizeof(L'%c'));
 return 0;}
'''
s = src % (("äöÄÖå",)*1 + ("ä","ä","ä","ä","ä","ä","ä","ä","ä"))  if False else None
# simpler: build with explicit substitutions
def build(strlit, ch):
    t = src.replace('%%','\x00')
    t = t.replace('%s','@S@').replace('%c','@C@').replace('\x00','%%')
    t = t.replace('@S@',strlit).replace('@C@',ch)
    return t.replace('%%','%')
txt = build("äöÄÖå","ä")
for name,enc,bom in [("cp","cp1252",b""),("u8","utf-8",b""),("u8b","utf-8",b"\xef\xbb\xbf")]:
    open(name+".cpp","wb").write(bom+txt.encode(enc))
