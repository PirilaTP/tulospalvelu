#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/TulostusUnit2.cpp"
char sz__TFormAutoFile[(int)sizeof(TFormAutoFile)];
char sz__TFormBrowser[(int)sizeof(TFormBrowser)];
char sz__TFormHtmlEdit[(int)sizeof(TFormHtmlEdit)];
char sz__TFormLisaTekstit[(int)sizeof(TFormLisaTekstit)];
char sz__TFormMuotoilu[(int)sizeof(TFormMuotoilu)];
