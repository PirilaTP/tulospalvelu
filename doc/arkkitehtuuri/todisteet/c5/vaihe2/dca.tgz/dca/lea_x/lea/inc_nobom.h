const wchar_t hw[] = L"äö";
const char hn[] = "äö";
