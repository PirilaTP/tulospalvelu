#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitSelect.cpp"
char sz__TValitse[(int)sizeof(TValitse)];
