#include <stdio.h>
#include <wchar.h>
const char  n1[] = "äöÄÖå";
const wchar_t w1[] = L"äöÄÖå";
const char  c1 = 'ä';
const wchar_t c2 = L'ä';
const char  c3 = 'ä';
int sw(char c){ switch(c){ case 'ä': return 1; case 'a': return 2; default: return 0; } }
int swu(unsigned char c){ switch(c){ case 'ä': return 1; default: return 0; } }
int swW(wchar_t c){ switch(c){ case L'ä': return 1; default: return 0; } }
int main(){
 int i; printf("N:"); for(i=0;i<(int)sizeof n1;i++) printf(" %02X",(unsigned char)n1[i]);
 printf("\nW:"); for(i=0;i<(int)(sizeof w1/sizeof w1[0]);i++) printf(" %04X",(unsigned)w1[i]);
 printf("\nc1=%d c2=%04X c3=%d\n", (int)c1,(unsigned)c2,(int)c3);
 printf("sw(byte E4)=%d sw(0xE4)=%d swu(0xE4)=%d swW(0xE4)=%d sizeof(c1lit)=%d sizeof(wlit)=%d\n", sw((char)0xE4), sw(-28), swu(0xE4), swW(0xE4), (int)sizeof('ä'), (int)sizeof(L'ä'));
 return 0;}
