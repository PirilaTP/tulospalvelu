#include <stdlib.h>
#include <wchar.h>
int VersioIntProbe(const wchar_t *s) { return (int)(100*_wtof(s)); }
