#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitEmitMuutokset.cpp"
char sz__TFormEmitMuutokset[(int)sizeof(TFormEmitMuutokset)];
