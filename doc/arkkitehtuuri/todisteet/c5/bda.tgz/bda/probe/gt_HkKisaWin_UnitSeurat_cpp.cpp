#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitSeurat.cpp"
char sz__TEditDialog[(int)sizeof(TEditDialog)];
