#include <stdio.h>
#include <string.h>
#include <wchar.h>
int main(){
 setvbuf(stdout,0,_IONBF,0);
 wchar_t b[80]; unsigned long long u=1234567890123ULL; long long s=-5; __int64 q=9876543210LL;
 swprintf(b,L"[%lld.%lld]",u,s); wprintf(L"%ls\n",b);
 swprintf(b,L"[%I64d]",q); wprintf(L"%ls\n",b);
 swprintf(b,L"[%llu]",u); wprintf(L"%ls\n",b);
 swprintf(b,L"[%ls|%d]",L"x",5); wprintf(L"%ls\n",b);
 swprintf(b,L"[%5.1f|%e|%g]",2.25,1234.5,0.0001); wprintf(L"%ls\n",b);
 swprintf(b,L"[%x|%X|%08X|%p]",255,255,255,(void*)0x1234); wprintf(L"%ls\n",b);
 swprintf(b,L"[%+d|% d|%-5d|%05d]",5,5,5,5); wprintf(L"%ls\n",b);
 swprintf(b,L"[%.3s|%10.4s]",L"abcdef",L"abcdef"); wprintf(L"%ls\n",b);
 swprintf(b,L"[%s]",(wchar_t*)0); wprintf(L"%ls\n",b);
 return 0;}
