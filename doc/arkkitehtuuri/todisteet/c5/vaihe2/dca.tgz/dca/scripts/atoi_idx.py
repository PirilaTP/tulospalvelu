import re, sys, os, csv
root, units, out = sys.argv[1], sys.argv[2], sys.argv[3]
files = [l.strip() for l in open(units) if l.strip()]
PARSE = re.compile(r'\b(_wtoi|_wtol|atoi|atol|wcstol|wcstoul|_wtoi64)\s*\(')
ASSIGN = re.compile(r'([A-Za-z_][\w\.\->\[\]]*?)\s*(\+|-)?=\s*[^=;]*?\b(_wtoi|_wtol|atoi|atol|wcstol|wcstoul)\s*\(')
rows = []
for f in files:
    p = os.path.join(root, f)
    try:
        lines = open(p, 'rb').read().decode('cp1252', 'replace').splitlines()
    except Exception:
        continue
    for i, ln in enumerate(lines):
        s = ln.strip()
        if s.startswith('//'):
            continue
        if not PARSE.search(ln):
            continue
        m = ASSIGN.search(ln)
        if not m:
            continue
        var = m.group(1)
        base = re.split(r'[\.\->\[]', var)[-1] if '[' not in var else var
        simple = re.sub(r'\[.*$', '', var)
        if not re.match(r'^[A-Za-z_]\w*$', simple):
            # struct member etc: take last identifier
            simple = re.findall(r'[A-Za-z_]\w*', var)[-1]
        uses = []
        checks = []
        for j in range(i+1, min(i+25, len(lines))):
            l2 = lines[j]
            if re.search(r'\[[^\]]*\b' + re.escape(simple) + r'\b', l2):
                uses.append(('index', j+1))
            if re.search(r'\b(new\s+\w+\s*\[|[cm]alloc\s*\()[^;]*\b' + re.escape(simple) + r'\b', l2):
                uses.append(('alloc', j+1))
            if re.search(r'\bfor\s*\([^;]*;[^;]*\b' + re.escape(simple) + r'\b', l2):
                uses.append(('loop', j+1))
            if re.search(r'\b' + re.escape(simple) + r'\b\s*(<|>|<=|>=)', l2) or re.search(r'(<|>|<=|>=)\s*' + re.escape(simple) + r'\b', l2):
                checks.append(j+1)
        # same-line check
        if re.search(r'\b' + re.escape(simple) + r'\b\s*(<|>|<=|>=)', ln):
            checks.append(i+1)
        if uses:
            rows.append([f, i+1, simple, ';'.join('%s@%d' % u for u in uses[:6]), ';'.join(map(str, checks[:6])), s[:160]])
with open(out, 'w', newline='', encoding='utf-8') as fo:
    w = csv.writer(fo)
    w.writerow(['file','line','var','uses','compare_lines','text'])
    w.writerows(rows)
print(len(rows))
