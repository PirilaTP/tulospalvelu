# ODR check on COMDAT-like (segment virtual) symbols across units; normalises local labels, EH descriptor names, hash labels
import re,collections,os,sys
D=chr(36); HASH=re.compile('['+D+'][a-z]{8}'); ECT=re.compile('[_][$][A-Z]{3,8}[$]'); LAB=re.compile('@[0-9]+')
d=sys.argv[1]; flt=sys.argv[2] if len(sys.argv)>2 else ''
segs=collections.defaultdict(lambda: collections.defaultdict(list))
for f in sorted(os.listdir(d)):
    if not f.endswith('.asm'): continue
    L=open(os.path.join(d,f),encoding='cp1252',errors='replace').read().split(chr(10)); i=0
    while i<len(L):
        m=re.match(r'^(\S+)\s+segment virtual',L[i])
        if m and flt in m.group(1):
            name=m.group(1);j=i+1;body=[]
            while j<len(L) and not re.match(r'^%s\s+ends'%re.escape(name),L[j]):
                l=L[j].rstrip()
                if not l.strip() or l.strip().startswith((';','?debug')): j+=1;continue
                l=HASH.sub('H',l); l=ECT.sub('_ECT_',l); l=re.sub(r'[?]live[0-9]+@[0-9]+','?live',l); l=LAB.sub('@L',l); l=re.sub('s@[+][0-9]+','s@N',l)
                body.append(l); j+=1
            segs[name]['\n'.join(body)].append(f[:3]); i=j
        i+=1
multi=[k for k,v in segs.items() if sum(len(x) for x in v.values())>1]
diff=[k for k in multi if len(segs[k])>1]
print('symbols',len(segs),'in >1 unit',len(multi),'with differing bodies',len(diff))
for k in sorted(diff)[:int(sys.argv[3]) if len(sys.argv)>3 else 60]: print(' ',k[:120],sorted(len(v) for v in segs[k].values()))
