#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitSeurGr.cpp"
char sz__TSeurantaForm[(int)sizeof(TSeurantaForm)];
