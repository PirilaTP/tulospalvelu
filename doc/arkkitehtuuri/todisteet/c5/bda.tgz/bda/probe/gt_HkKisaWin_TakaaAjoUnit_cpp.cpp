#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/TakaaAjoUnit.cpp"
char sz__TTakaaAjoForm[(int)sizeof(TTakaaAjoForm)];
