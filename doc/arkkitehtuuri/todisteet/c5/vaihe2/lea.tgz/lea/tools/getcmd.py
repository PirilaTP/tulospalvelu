import sys,re
BS=chr(92); Q=chr(34)
log,src=sys.argv[1],sys.argv[2]
t=open(log,encoding='utf-8-sig').read().split(chr(10))
out=[];on=False;started=False
for l in t:
    if l.startswith('bcc32 command line for'):
        if started: break
        on = (BS+src+Q in l or Q+src+Q in l); started=on
        continue
    if on and l.startswith(' '): out.append(l.strip())
s=''
for x in out:
    s += x if (s=='' or s.endswith(';')) else ' '+x
ROOT='C:'+chr(92)+'dev'+chr(92)+'tulospalvelu'+chr(92)+'TPsource'+chr(92)+'V52'
s=s.split('bcc32.exe',1)[1]
s=re.sub(r'-o\S+','',s)
s=re.sub(r'-n'+re.escape('.'+BS+'Win32'+BS+'Release'),'',s)
s=re.sub(r'-H=\S+','',s)
s=re.sub(r'\s-H\s',' ',s+' ')
s=re.sub(r'\s\S*\.cpp\s*$',' ',s)
s=s.replace(';..;',';'+ROOT+';')
s=re.sub(r'(?<![\w.])\.\.'+re.escape(chr(92)),lambda m:ROOT+chr(92),s)
print(s.strip())
