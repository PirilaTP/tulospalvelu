@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars32.bat" >nul 2>&1
cd /d "%~dp0"
set TP=C:\dev\tulospalvelu\TPsource\V52
set COM=/nologo /W3 /EHsc /MT /GS /Gy /fp:precise /Zc:wchar_t /Zc:forScope /Zc:inline /D WIN32 /D _CRT_SECURE_NO_DEPRECATE /D _CRT_NON_CONFORMING_WCSTOK /D _CRT_NON_CONFORMING_SWPRINTFS /D _CONSOLE /D _UNICODE /D UNICODE /J /I %TP%\include /I %TP%\Tp
rem D: caller only, TextFl taken from the shipped-style tputilv2.lib (as HkMaali/ViestiMaali), console flags /GL /LTCG
cl %COM% /O2 /Oi /Oy- /GL /Fe:gs59_libgl.exe /Folibgl/ gs59.cpp /link /LTCG /DEBUG /OPT:REF /OPT:ICF /SAFESEH "%TP%\..\..\TPexe\Lib\V52\VS\Release\tputilv2.lib" > libgl.build.txt 2>&1
