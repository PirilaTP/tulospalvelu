// Probe: printf-family conversion semantics. Compile: MSVC /J /D_CRT_NON_CONFORMING_SWPRINTFS ; bcc32 as project.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <locale.h>
#ifdef _MSC_VER
#define WIDE_NOLEN 1
#endif
static char  na[16] = "ab\xE4" "d";      // narrow cp1252 "abäd"
static wchar_t wa[16] = L"ab\x00E4" L"d"; // wide
static void dumpw(const char *tag, const wchar_t *b){ printf("%-34s W:", tag); for(int i=0;i<8&&b[i];i++) printf(" %04X",(unsigned)b[i]); printf("\n"); }
static void dumpn(const char *tag, const char *b){ printf("%-34s N:", tag); for(int i=0;i<8&&b[i];i++) printf(" %02X",(unsigned char)b[i]); printf("\n"); }
#define WT(tag, fmt, arg) do{ wchar_t b[64]; memset(b,0,sizeof b); swprintf(b, fmt, arg); dumpw(tag, b);}while(0)
#define NT(tag, fmt, arg) do{ char b[64]; memset(b,0,sizeof b); sprintf(b, fmt, arg); dumpn(tag, b);}while(0)
int main(){
 #ifndef NOLOC
 setlocale(LC_ALL, "");
 #endif
 printf("sizeof(wchar_t)=%d\n",(int)sizeof(wchar_t));
 puts("-- wide function swprintf(buf,fmt,..) (no count)");
 WT("swprintf %s  <- wide ptr",  L"[%s]",  wa);
 WT("swprintf %s  <- narrow ptr", L"[%s]",  na);
 WT("swprintf %S  <- wide ptr",  L"[%S]",  wa);
 WT("swprintf %S  <- narrow ptr", L"[%S]",  na);
 WT("swprintf %hs <- narrow ptr", L"[%hs]", na);
 WT("swprintf %ls <- wide ptr",  L"[%ls]", wa);
 WT("swprintf %c  <- int 0xE4",   L"[%c]",  0xE4);
 WT("swprintf %c  <- int -28 (signed char E4)", L"[%c]", (int)(char)-28);
 WT("swprintf %c  <- (char)0xE4 expr", L"[%c]", (char)0xE4);
 WT("swprintf %c  <- L'x00E4'",   L"[%c]",  (wchar_t)0xE4);
 WT("swprintf %C  <- int 0xE4",   L"[%C]",  0xE4);
 WT("swprintf %C  <- int -28",   L"[%C]",  -28);
 WT("swprintf %hc <- int 0xE4",   L"[%hc]", 0xE4);
 WT("swprintf %lc <- int 0xE4",   L"[%lc]", 0xE4);
 WT("swprintf %.2s <- wide ptr", L"[%.2s]", wa);
 WT("swprintf %.2S <- narrow",   L"[%.2S]", na);
 puts("-- narrow sprintf");
 NT("sprintf %s  <- narrow",  "[%s]",  na);
 NT("sprintf %S  <- wide",    "[%S]",  wa);
 NT("sprintf %ls <- wide",    "[%ls]", wa);
 NT("sprintf %hs <- narrow",  "[%hs]", na);
 NT("sprintf %c  <- int 0xE4","[%c]",  0xE4);
 NT("sprintf %C  <- int 0xE4","[%C]",  0xE4);
 NT("sprintf %lc <- int 0xE4","[%lc]", 0xE4);
 NT("sprintf %s  <- wide ptr (wrong)","[%s]", wa);
 NT("sprintf %d <- 5", "[%d]", 5);
 NT("sprintf %5.1f", "[%5.1f]", 2.25);
 puts("-- fwprintf/wprintf to a file");
 FILE *f=fopen("fw.tmp","wb"); fwprintf(f,L"%s|%S|%c|%hs",wa,na,0xE4,na); fclose(f);
 f=fopen("fw.tmp","rb"); unsigned char r[64]={0}; size_t n=fread(r,1,64,f); fclose(f); printf("fwprintf file bytes (%d):",(int)n); for(size_t i=0;i<n;i++) printf(" %02X",r[i]); printf("\n");
 return 0; }
