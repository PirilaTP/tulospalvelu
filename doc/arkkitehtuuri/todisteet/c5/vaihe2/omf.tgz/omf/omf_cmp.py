"""C-5 step 2A: compare two bcc32 (Intel OMF) object files record by record.

A record is [type:1][length:2 LE][body: length-1][checksum:1]. COMENT records are
named by their comment class (e.g. COMENT_E9 = dependency file with time stamp).

compare(a, b) returns
  raw_equal        files are byte-identical
  equal_code       identical after ignoring IGNORE kinds
  differing_kinds  record kinds whose (ordered) contents differ
usage as a script: python -I omf_cmp.py a.obj b.obj
"""
import sys, collections

NAMES = {0x80: 'THEADR', 0x82: 'LHEADR', 0x88: 'COMENT', 0x8A: 'MODEND', 0x8B: 'MODEND32',
         0x8C: 'EXTDEF', 0x90: 'PUBDEF', 0x91: 'PUBDEF32', 0x94: 'LINNUM', 0x95: 'LINNUM32',
         0x96: 'LNAMES', 0x98: 'SEGDEF', 0x99: 'SEGDEF32', 0x9A: 'GRPDEF', 0x9C: 'FIXUPP',
         0x9D: 'FIXUPP32', 0xA0: 'LEDATA', 0xA1: 'LEDATA32', 0xA2: 'LIDATA', 0xA3: 'LIDATA32',
         0xB0: 'COMDEF', 0xB2: 'BAKPAT', 0xB3: 'BAKPAT32', 0xB4: 'LEXTDEF', 0xB6: 'LPUBDEF',
         0xB7: 'LPUBDEF32', 0xB8: 'LCOMDEF', 0xBC: 'CEXTDEF', 0xC2: 'COMDAT', 0xC3: 'COMDAT32',
         0xC4: 'LINSYM', 0xC5: 'LINSYM32', 0xC6: 'ALIAS', 0xC8: 'NBKPAT', 0xC9: 'NBKPAT32',
         0xCA: 'LLNAMES', 0xF0: 'LIBHDR', 0xF1: 'LIBEND'}

# Kinds that carry source names, time stamps, output paths or line numbers, not code
# or data (measured in C-5: E8 = source file name + DOS time stamp, E9 = dependency
# file + time stamp, FB = output directory path; LINNUM = line numbers).
IGNORE = {'THEADR', 'COMENT_E8', 'COMENT_E9', 'COMENT_FB', 'LINNUM', 'LINNUM32', 'LINSYM', 'LINSYM32'}


def records(path):
    b = open(path, 'rb').read()
    i, out = 0, []
    while i + 3 <= len(b):
        t = b[i]
        n = b[i + 1] | (b[i + 2] << 8)
        body = b[i + 3:i + 3 + n - 1]
        kind = NAMES.get(t, 'T%02X' % t)
        if kind == 'COMENT' and len(body) >= 2:
            kind = 'COMENT_%02X' % body[1]
        out.append((kind, body))
        i += 3 + n
        if kind in ('MODEND', 'MODEND32'):
            break
    return out, b


def compare(a, b):
    ra, ba = records(a)
    rb, bb = records(b)
    ka = collections.defaultdict(list)
    kb = collections.defaultdict(list)
    for k, body in ra:
        ka[k].append(body)
    for k, body in rb:
        kb[k].append(body)
    diff = sorted(k for k in set(ka) | set(kb) if ka.get(k) != kb.get(k))
    fa = [(k, x) for k, x in ra if k not in IGNORE]
    fb = [(k, x) for k, x in rb if k not in IGNORE]
    return {'raw_equal': ba == bb, 'equal_code': fa == fb, 'differing_kinds': diff,
            'records': [len(ra), len(rb)]}


if __name__ == '__main__':
    print(compare(sys.argv[1], sys.argv[2]))
