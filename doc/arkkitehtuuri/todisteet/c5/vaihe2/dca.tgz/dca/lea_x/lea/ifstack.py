import sys,re,json
sys.stdout.reconfigure(encoding='utf-8')
p=sys.argv[1]; want=set(int(x) for x in sys.argv[2:])
st=[]
for i,l in enumerate(open(p,'rb').read().decode('cp1252').split(chr(10)),1):
    m=re.match(r'\s*#\s*(if|ifdef|ifndef|elif|else|endif)\b(.*)',l)
    if m:
        k=m.group(1)
        if k in('if','ifdef','ifndef'): st.append(k+' '+m.group(2).strip()[:40])
        elif k=='elif': st[-1]='elif '+m.group(2).strip()[:40]
        elif k=='else': st[-1]='NOT('+st[-1]+')'
        elif k=='endif': st.pop()
    if i in want: print(i,' | '.join(st))
