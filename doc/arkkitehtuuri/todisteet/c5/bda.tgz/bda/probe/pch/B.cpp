#include "hdr.h"
#pragma hdrstop
struct BS {char c; int i;};
char sz_B_HS[(int)sizeof(HS)];
char sz_B_BS[(int)sizeof(BS)];
char sgn_B[((char)-1<0)?1:2];
