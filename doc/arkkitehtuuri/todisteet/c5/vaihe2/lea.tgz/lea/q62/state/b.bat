@echo off
set BIN=c:\program files (x86)\embarcadero\studio\37.0\bin
cd /d "%~dp0"
"%BIN%\bcc32.exe" @args_st.txt -S -ost_pch.asm -H=C:\Users\NIKO-P~1\AppData\Local\Temp\claude\a25cf22582434270\da7a5c13-d4bd-4f7b-a86d-4289d7e5797c\scratchpad\c5\s2\lea\q62\all_hk\shared.pch -H st.cpp > st_pch.txt 2>&1
"%BIN%\bcc32.exe" @args_st.txt -S -ost_nopch.asm st.cpp > st_nopch.txt 2>&1
