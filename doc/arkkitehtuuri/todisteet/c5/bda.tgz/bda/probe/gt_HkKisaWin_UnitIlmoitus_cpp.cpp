#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitIlmoitus.cpp"
char sz__TFormIlmoitus[(int)sizeof(TFormIlmoitus)];
