	.386p
	ifdef ??version
	if ??version GT 500H
	.mmx
	endif
	endif
	model flat
	ifndef	??version
	?debug	macro
	endm
	endif
	?debug	S "st.cpp"
	?debug	T "st.cpp"
_TEXT	segment dword public use32 'CODE'
_TEXT	ends
_DATA	segment dword public use32 'DATA'
_DATA	ends
_BSS	segment dword public use32 'BSS'
_BSS	ends
DGROUP	group	_BSS,_DATA
_BSS	segment dword public use32 'BSS'
_s0	label	byte
	db	5	dup(?)
_s1	label	byte
	db	8	dup(?)
_s2_after_pack_pop_of_option_push	label	byte
	db	8	dup(?)
_s3	label	byte
	db	5	dup(?)
_s4_after_option_pop_of_pack_push	label	byte
	db	5	dup(?)
_s5	label	byte
	db	5	dup(?)
_s6_expect2	label	byte
	db	6	dup(?)
_s7_expect4	label	byte
	db	8	dup(?)
_s8_pack8	label	byte
	db	8	dup(?)
_s9_after_pop	label	byte
	db	8	dup(?)
_s10_pack2	label	byte
	db	6	dup(?)
_s11_pack_empty	label	byte
	db	8	dup(?)
_BSS	ends
_TEXT	segment dword public use32 'CODE'
_TEXT	ends
	public	_s0
	public	_s1
	public	_s2_after_pack_pop_of_option_push
	public	_s3
	public	_s4_after_option_pop_of_pack_push
	public	_s5
	public	_s6_expect2
	public	_s7_expect4
	public	_s8_pack8
	public	_s9_after_pop
	public	_s10_pack2
	public	_s11_pack_empty
	?debug	D "st.cpp" 23929 1606
	end
