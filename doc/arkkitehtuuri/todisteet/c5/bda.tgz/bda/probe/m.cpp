#ifdef __BORLANDC__
BORLANDC __BORLANDC__
#endif
#ifdef __CODEGEARC__
CODEGEARC __CODEGEARC__
#endif
#ifdef __BCPLUSPLUS__
BCPLUSPLUS __BCPLUSPLUS__
#endif
#ifdef _MSC_VER
MSC_VER _MSC_VER
#endif
#ifdef _MSC_EXTENSIONS
MSC_EXT yes
#endif
#ifdef __clang__
CLANG yes
#endif
#ifdef _WIN32
WIN32u yes
#endif
#ifdef WIN32
WIN32 yes
#endif
#ifdef __WIN32__
WIN32__ yes
#endif
#ifdef _M_IX86
M_IX86 _M_IX86
#endif
#ifdef _MT
MT yes
#endif
#ifdef __MT__
MT__ yes
#endif
#ifdef _CONSOLE
CONSOLE yes
#endif
#ifdef __CONSOLE__
CONSOLE__ yes
#endif
#ifdef UNICODE
UNICODE yes
#endif
#ifdef _UNICODE
_UNICODE yes
#endif
#ifdef _MBCS
_MBCS yes
#endif
#ifdef _BORLAND_
_BORLAND_ yes
#endif
#ifdef _USE_32BIT_TIME_T
USE32T yes
#endif
#ifdef __FLAT__
FLAT yes
#endif
#ifdef _RTLDLL
RTLDLL yes
#endif
#ifdef __DLL__
DLL yes
#endif
#ifdef __WCHAR_T
WCHAR_T yes
#endif
#ifdef _WCHAR_T_DEFINED
WCHAR_T_DEFINED yes
#endif
#ifdef _CHAR_UNSIGNED
CHAR_UNSIGNED yes
#endif
#ifdef __CHAR_UNSIGNED__
CHAR_UNSIGNED__ yes
#endif
#ifdef _WIN64
WIN64 yes
#endif
#ifdef __cplusplus
CPLUSPLUS __cplusplus
#endif
#ifdef _WCHAR_T
_WCHAR_T yes
#endif
#ifdef VCL_IAMLIGHT
VCL_IAMLIGHT yes
#endif
#ifdef __STDC__
STDC __STDC__
#endif
