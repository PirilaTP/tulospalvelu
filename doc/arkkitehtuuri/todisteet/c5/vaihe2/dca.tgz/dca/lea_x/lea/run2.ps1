& "$PSScriptRoot\be-msvc.exe"
"rc=$LASTEXITCODE"
