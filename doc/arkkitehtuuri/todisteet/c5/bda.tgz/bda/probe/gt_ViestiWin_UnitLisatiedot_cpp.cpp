#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitLisatiedot.cpp"
char sz__TFormLisatiedot[(int)sizeof(TFormLisatiedot)];
