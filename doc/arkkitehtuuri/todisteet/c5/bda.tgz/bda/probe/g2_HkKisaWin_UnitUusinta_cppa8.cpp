#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitUusinta.cpp"
char off__TFormUusinta__CBYhteydet[(int)(long)&(((TFormUusinta*)0)->CBYhteydet)+1];
char off__TFormUusinta__RGTapa[(int)(long)&(((TFormUusinta*)0)->RGTapa)+1];
char off__TFormUusinta__Label1[(int)(long)&(((TFormUusinta*)0)->Label1)+1];
char off__TFormUusinta__EdtRaja[(int)(long)&(((TFormUusinta*)0)->EdtRaja)+1];
char off__TFormUusinta__Label2[(int)(long)&(((TFormUusinta*)0)->Label2)+1];
char off__TFormUusinta__Button1[(int)(long)&(((TFormUusinta*)0)->Button1)+1];
char off__TFormUusinta__Button2[(int)(long)&(((TFormUusinta*)0)->Button2)+1];
char off__TFormUusinta__RGTila[(int)(long)&(((TFormUusinta*)0)->RGTila)+1];
char off__TFormUusinta__Button3[(int)(long)&(((TFormUusinta*)0)->Button3)+1];
char off__TFormUusinta__Panel1[(int)(long)&(((TFormUusinta*)0)->Panel1)+1];
char off__TFormUusinta__Button4[(int)(long)&(((TFormUusinta*)0)->Button4)+1];
char off__TFormUusinta__EdtSulku[(int)(long)&(((TFormUusinta*)0)->EdtSulku)+1];
char off__TFormUusinta__Label3[(int)(long)&(((TFormUusinta*)0)->Label3)+1];
char off__TFormUusinta__CBSarjat[(int)(long)&(((TFormUusinta*)0)->CBSarjat)+1];
char off__TFormUusinta__CBOsuudet[(int)(long)&(((TFormUusinta*)0)->CBOsuudet)+1];
char off__TFormUusinta__Label4[(int)(long)&(((TFormUusinta*)0)->Label4)+1];
char off__TFormUusinta__Button5[(int)(long)&(((TFormUusinta*)0)->Button5)+1];
char off__TFormUusinta__RGRajaus[(int)(long)&(((TFormUusinta*)0)->RGRajaus)+1];
char off__TFormUusinta__GBAikavali[(int)(long)&(((TFormUusinta*)0)->GBAikavali)+1];
char off__TFormUusinta__EdtAlku[(int)(long)&(((TFormUusinta*)0)->EdtAlku)+1];
char off__TFormUusinta__Label5[(int)(long)&(((TFormUusinta*)0)->Label5)+1];
char off__TFormUusinta__Label6[(int)(long)&(((TFormUusinta*)0)->Label6)+1];
char off__TFormUusinta__EdtLoppu[(int)(long)&(((TFormUusinta*)0)->EdtLoppu)+1];
