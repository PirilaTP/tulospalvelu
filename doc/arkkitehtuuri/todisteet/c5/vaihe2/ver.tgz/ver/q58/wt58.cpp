// Q58 probe: is wcstok state per thread? Two threads interleave wcstok(NULL,...).
#include <windows.h>
#include <process.h>
#include <stdio.h>
#include <wchar.h>
static HANDLE evA1, evB1, evA2;   // A: first call done; B: first call done; A: second call may proceed
static wchar_t bufA[] = L"a1,a2,a3", bufB[] = L"b1,b2,b3";
static wchar_t resA[3][8], resB[3][8];
#ifdef WCSTOK3
#define TOK(s,d) wcstok(s,d,&ctx)
#else
#define TOK(s,d) wcstok(s,d)
#endif
static unsigned __stdcall thA(void *) {
  wchar_t *ctx = 0; (void)ctx;
  wchar_t *p = TOK(bufA, L","); wcscpy(resA[0], p ? p : L"(null)");
  SetEvent(evA1);                       // let B start its own tokenizing
  WaitForSingleObject(evB1, 5000);      // B did its first wcstok
  p = TOK(NULL, L","); wcscpy(resA[1], p ? p : L"(null)");   // expected a2 if per-thread
  p = TOK(NULL, L","); wcscpy(resA[2], p ? p : L"(null)");
  return 0; }
static unsigned __stdcall thB(void *) {
  wchar_t *ctx = 0; (void)ctx;
  WaitForSingleObject(evA1, 5000);
  wchar_t *p = TOK(bufB, L","); wcscpy(resB[0], p ? p : L"(null)");
  SetEvent(evB1);
  Sleep(300);                           // A runs two NULL calls meanwhile
  p = TOK(NULL, L","); wcscpy(resB[1], p ? p : L"(null)");   // expected b2 if per-thread
  p = TOK(NULL, L","); wcscpy(resB[2], p ? p : L"(null)");
  return 0; }
int main() {
  evA1 = CreateEvent(0,1,0,0); evB1 = CreateEvent(0,1,0,0);
#ifdef USE_CT
  HANDLE h[2] = { CreateThread(0,0,(LPTHREAD_START_ROUTINE)thA,0,0,0), CreateThread(0,0,(LPTHREAD_START_ROUTINE)thB,0,0,0) };
#else
  HANDLE h[2] = { (HANDLE)_beginthreadex(0,0,thA,0,0,0), (HANDLE)_beginthreadex(0,0,thB,0,0,0) };
#endif
  WaitForMultipleObjects(2, h, 1, 10000);
  wprintf(L"A: %ls %ls %ls\nB: %ls %ls %ls\n", resA[0],resA[1],resA[2], resB[0],resB[1],resB[2]);
  bool ok = !wcscmp(resA[1],L"a2") && !wcscmp(resA[2],L"a3") && !wcscmp(resB[1],L"b2") && !wcscmp(resB[2],L"b3");
  wprintf(L"%ls\n", ok ? L"PER-THREAD" : L"SHARED-STATE");
  return 0; }
