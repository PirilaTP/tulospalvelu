#include <stdio.h>
int before2(char c){ return c < 0; }
int before3(char *p){ return p[0] < 0; }
struct T0 { char c; int i; };
#include "kk.h"
int after2(char c){ return c < 0; }
int after3(char *p){ return p[0] < 0; }
struct T1 { char c; int i; };
int main(){ char c=(char)0xE4; printf("before2=%d before3=%d after2=%d after3=%d sizeof(T0)=%d sizeof(T1)=%d (int)c=%d\n", before2(c), before3(&c), after2(c), after3(&c), (int)sizeof(T0), (int)sizeof(T1), (int)c); return 0; }
