#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitSelect3.cpp"
char off__TFormSelect3__Sanoma[(int)(long)&(((TFormSelect3*)0)->Sanoma)+1];
char off__TFormSelect3__Button1[(int)(long)&(((TFormSelect3*)0)->Button1)+1];
char off__TFormSelect3__Button2[(int)(long)&(((TFormSelect3*)0)->Button2)+1];
char off__TFormSelect3__Button3[(int)(long)&(((TFormSelect3*)0)->Button3)+1];
char off__TFormSelect3__selResult[(int)(long)&(((TFormSelect3*)0)->selResult)+1];
