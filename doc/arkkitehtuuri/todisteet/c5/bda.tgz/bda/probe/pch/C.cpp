#include "hdr.h"
#pragma hdrstop
struct CS {char c; int i;};
char chk_size_is_5[sizeof(CS)==5?1:-1];
char chk_unsigned[((char)-1<0)?-1:1];
