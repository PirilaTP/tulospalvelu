#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitOsuuskopiointi.cpp"
char sz__TFormOsuuskopiointi[(int)sizeof(TFormOsuuskopiointi)];
