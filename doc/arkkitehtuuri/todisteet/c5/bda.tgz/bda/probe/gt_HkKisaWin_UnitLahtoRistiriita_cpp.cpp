#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitLahtoRistiriita.cpp"
char sz__TFormLahtoRistiriita[(int)sizeof(TFormLahtoRistiriita)];
