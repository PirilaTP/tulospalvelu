#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/VertAikaUnit.cpp"
char sz__TVertAikaFrm[(int)sizeof(TVertAikaFrm)];
