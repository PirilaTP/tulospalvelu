#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/RADStudio10/HkKisaWin.cpp"
char off__TFormBrowser__WebBrowser1[(int)(long)&(((TFormBrowser*)0)->WebBrowser1)+1];
char off__TFormBrowser__EditURL[(int)(long)&(((TFormBrowser*)0)->EditURL)+1];
char off__TFormBrowser__NavigComplete[(int)(long)&(((TFormBrowser*)0)->NavigComplete)+1];
