#include <stdio.h>
#include <string.h>
#include <time.h>
int main(){
  time_t t=25000; t*=86400; struct tm *g=gmtime(&t);
  printf("sizeof(time_t)=%d t=%lld gmtime=%s\n",(int)sizeof(time_t),(long long)t,g? "non-NULL":"NULL");
  if(g) printf("  -> %04d-%02d-%02d\n",g->tm_year+1900,g->tm_mon+1,g->tm_mday);
  struct tm tm; memset(&tm,0,sizeof tm); tm.tm_year=140; tm.tm_mon=0; tm.tm_mday=1; tm.tm_hour=12;
  time_t m=mktime(&tm); printf("mktime(2040-01-01)=%lld /86400=%lld\n",(long long)m,(long long)(m/86400));
  return 0;}
