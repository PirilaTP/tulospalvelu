// Probe: _wfopen_s modes as used by TextFl (tputilv2/TextFileClass.cpp:296-305), and fputws/fwprintf/fputs newline handling.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#ifdef _MSC_VER
#include <crtdbg.h>
#include <stdlib.h>
static void __cdecl ih(const wchar_t*,const wchar_t*,const wchar_t*,unsigned,uintptr_t){ printf("  [invalid parameter handler called]"); fflush(stdout);}
#endif
static void dumpfile(const char *tag, const char *fn){ FILE *f=fopen(fn,"rb"); unsigned char b[64]; size_t n= f? fread(b,1,64,f):0; if(f) fclose(f); printf("%-44s (%d):",tag,(int)n); for(size_t i=0;i<n&&i<40;i++) printf(" %02X",b[i]); printf("\n"); }
static void t(const wchar_t *mode, const char *tag, int how){
  FILE *f=0; errno_t e=_wfopen_s(&f, L"wfo.tmp", mode);
  if(e||!f){ printf("%-44s open failed err=%d\n",tag,(int)e); return; }
  const wchar_t *s=L"a\x00E4\n\x20AC";
  if(how==0) fputws(s,f);
  else if(how==1) fwrite(s,2,wcslen(s),f);
  else if(how==2) fwprintf(f,L"%s",s);
  else if(how==3) fputs("a\xE4\n",f);
  fclose(f); dumpfile(tag,"wfo.tmp");
}
int main(){
#ifdef _MSC_VER
  _set_invalid_parameter_handler(ih); _CrtSetReportMode(0,0);
#endif
  setvbuf(stdout,0,_IONBF,0);
  t(L"wb",                   "wb  + fputws(a,ae,LF,euro)", 0);
  t(L"wb",                   "wb  + fwrite(wide, raw)", 1);
  t(L"wb",                   "wb  + fputs(narrow a,E4,LF)", 3);
  t(L"wt",                   "wt  + fputs(narrow a,E4,LF)", 3);
  t(L"wb, ccs=UTF-16LE",     "wb,ccs=UTF-16LE + fputws", 0);
  t(L"wb, ccs=UTF-16LE",     "wb,ccs=UTF-16LE + fwrite raw wide", 1);
  t(L"wb, ccs=UTF-16BE",     "wb,ccs=UTF-16BE + fwrite raw wide", 1);
  t(L"wb, ccs=UTF-8",        "wb,ccs=UTF-8 + fputws", 0);
  t(L"wb, ccs=UNICODE",      "wb,ccs=UNICODE + fputws", 0);
  t(L"w+b, ccs=UTF-16LE",    "w+b,ccs=UTF-16LE + fputws", 0);
  return 0; }
