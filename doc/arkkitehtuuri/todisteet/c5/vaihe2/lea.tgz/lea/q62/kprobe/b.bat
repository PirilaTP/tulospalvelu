@echo off
set BIN=c:\program files (x86)\embarcadero\studio\37.0\bin
set INC=-I"c:\program files (x86)\embarcadero\studio\37.0\include\windows\vcl";"c:\program files (x86)\embarcadero\studio\37.0\include";"c:\program files (x86)\embarcadero\studio\37.0\include\dinkumware";"c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl";"c:\program files (x86)\embarcadero\studio\37.0\include\windows\sdk";"c:\program files (x86)\embarcadero\studio\37.0\include\windows\rtl";"c:\program files (x86)\embarcadero\studio\37.0\include\windows\vcl";"c:\program files (x86)\embarcadero\studio\37.0\include\windows\fmx";C:\Users\Public\Documents\Embarcadero\Studio\37.0\hpp\Win32
set OPT=-DWIN32 -DSTRICT -D_BORLAND_ -DFRAMEWORK_VCL -DUSEPACKAGES -Q -tR -tM -tU -tW -C8 -O2 -v- -vi -S
"%BIN%\bcc32.exe" %OPT% %INC% -ok_signed.asm k.cpp > signed.txt 2>&1
"%BIN%\bcc32.exe" %OPT% -K %INC% -ok_unsigned.asm k.cpp > unsigned.txt 2>&1
