"""C-5 step 2A: sensitivity test - a one-character code change without new symbols
(tputilv2/kello.cpp ct[8] -> ct[9], same test as the MSVC procedure in merkistot.md)
must be detected. usage: python -I sens.py <build-logs> <srccopy> <outdir> <vertaa_omf.py>"""
import os, re, sys, subprocess, ctypes, shutil, importlib.util
logdir, srccopy, outdir, tool = sys.argv[1:5]
spec = importlib.util.spec_from_file_location('v', tool)
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)


def short(p):
    b = ctypes.create_unicode_buffer(1024)
    ctypes.windll.kernel32.GetShortPathNameW(p, b, 1024)
    return b.value


t = open(os.path.join(logdir, 'Tputil-XE.log'), encoding='utf-8-sig', errors='replace').read().splitlines()
i = [k for k, l in enumerate(t) if l == 'bcc32 command line for "..\\tputilv2\\kello.cpp"'][0]
parts = []
j = i + 1
while t[j].startswith('  '):
    parts.append(t[j][2:])
    j += 1
cmd = ''.join(parts).rstrip()
wd = os.path.join(srccopy, 'RADStudio10')
src = os.path.join(srccopy, 'tputilv2', 'kello.cpp')
orig = open(src, 'rb').read()
assert orig.count(b'ct[8] = 0;') == 1
objs = []
try:
    for name, body in (('a', orig), ('b', orig.replace(b'ct[8] = 0;', b'ct[9] = 0;'))):
        od = os.path.join(outdir, 'sens_' + name)
        shutil.rmtree(od, ignore_errors=True)
        os.makedirs(od)
        od = short(od)
        open(src, 'wb').write(body)
        obj = os.path.join(od, 'kello.obj')
        c = re.sub(r' -o\S+', lambda _: ' -o' + obj, cmd, count=1)
        c = re.sub(r' -n\S+', lambda _: ' -n' + od, c, count=1)
        c = re.sub(r' -H=\S+', lambda _: ' -H=' + os.path.join(od, 'p.pch'), c, count=1)
        exe, rest = c.split('.exe ', 1)
        r = subprocess.run('"' + exe + '.exe" ' + rest, cwd=wd, capture_output=True, text=True)
        assert r.returncode == 0, r.stdout + r.stderr
        objs.append(obj)
finally:
    open(src, 'wb').write(orig)
print('ct[8] -> ct[9]:', v.compare(*objs) or 'EQUAL')
