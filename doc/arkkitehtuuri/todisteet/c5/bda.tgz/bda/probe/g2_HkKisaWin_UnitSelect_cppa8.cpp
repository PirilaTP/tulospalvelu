#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitSelect.cpp"
char off__TValitse__Sanoma[(int)(long)&(((TValitse*)0)->Sanoma)+1];
char off__TValitse__Optiot[(int)(long)&(((TValitse*)0)->Optiot)+1];
char off__TValitse__Valittu[(int)(long)&(((TValitse*)0)->Valittu)+1];
char off__TValitse__OKBtn[(int)(long)&(((TValitse*)0)->OKBtn)+1];
char off__TValitse__Label1[(int)(long)&(((TValitse*)0)->Label1)+1];
char off__TValitse__opts[(int)(long)&(((TValitse*)0)->opts)+1];
char off__TValitse__val[(int)(long)&(((TValitse*)0)->val)+1];
