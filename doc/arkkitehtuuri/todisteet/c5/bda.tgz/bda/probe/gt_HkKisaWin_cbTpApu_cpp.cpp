#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/cbTpApu.cpp"
char sz__TFormIlmoitus[(int)sizeof(TFormIlmoitus)];
