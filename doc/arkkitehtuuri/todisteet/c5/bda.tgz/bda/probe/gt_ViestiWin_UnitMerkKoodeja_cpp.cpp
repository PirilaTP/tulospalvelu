#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitMerkKoodeja.cpp"
char sz__TFormMerkKoodeja[(int)sizeof(TFormMerkKoodeja)];
