import sys, os, shutil
sys.argv = [sys.argv[0]] + sys.argv[1:]
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'probe.py')).read())
S = srccopy
ue = os.path.join(S,'cbHk','UnitEmit.cpp'); hd = os.path.join(S,'Hk','HkDef.h')
out = os.path.abspath(outdir); shutil.rmtree(out, ignore_errors=True)
res = {}
U = ('HkKisaWin', r'..\cbHk\UnitEmit.cpp')
A = compile(*U, os.path.join(out,'A'))
pchA = os.path.join(short(os.path.join(out,'A')),'p.pch')
B = compile(*U, os.path.join(out,'B'), pch=pchA)
def infunc(L):
    # 1-based 521 is multi-line if; insert after it, plus inline block comment in expression, plus line in function at 151
    L[520] = L[520].replace(b'Kilp.id() > 0 &&', b'Kilp.id() > 0 /* c5 probe */ &&')
    L.insert(521, b'\t\t// c5 probe: comment inside multi-line expression')
    L.insert(150, b'\t// c5 probe: comment inside function body')
    return L
o = edit(ue, infunc)
try: C = compile(*U, os.path.join(out,'C'))
finally: open(ue,'wb').write(o)
def nonascii(L):
    L.insert(1, b'// c5 probe \xe4\xf6\xe5\xc4\xd6 \x80 \x81 \x8d \x9f \xff \xa0 end')
    L.insert(2, b'/* \xe4\xf6 \x81\x5c */')
    return L
o = edit(ue, nonascii)
try: D = compile(*U, os.path.join(out,'D'))
finally: open(ue,'wb').write(o)
def hdr(L):
    L.insert(1, b'// c5 probe header comment \xe4\xf6')
    L.insert(2, b'/* c5 probe block */')
    return L
o = edit(hd, hdr)
try:
    E = compile(*U, os.path.join(out,'E'))
    F = compile(*U, os.path.join(out,'F'), pch=pchA)
finally: open(hd,'wb').write(o)
def cmt(L):
    L.insert(1, b'// c5 probe line'); return L
o = edit(ue, cmt)
try: G = compile(*U, os.path.join(out,'G'), pch=pchA)
finally: open(ue,'wb').write(o)
for n,x in (('B pch-reuse base',B),('C infunc/multiline',C),('D nonascii',D),('E header cmt',E),('F header cmt + reused pch',F),('G cmt + reused pch',G)):
    print(n, v.compare(A,x) or 'EQUAL', open(A,'rb').read()==open(x,'rb').read())
K = ('Tputil-XE', r'..\tputilv2\kello.cpp'); kf = os.path.join(S,'tputilv2','kello.cpp')
KA = compile(*K, os.path.join(out,'KA'))
def kin(L):
    L.insert(32, b'   // c5 probe in function \xe4'); L[34] = L[34].replace(b'ct[8] = 0;', b'ct[8] /* x */ = 0;'); return L
o = edit(kf, kin)
try: KB = compile(*K, os.path.join(out,'KB'))
finally: open(kf,'wb').write(o)
print('kello infunc', v.compare(KA,KB) or 'EQUAL')
