#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitOsanottajat.cpp"
char sz__TFormSuodatus[(int)sizeof(TFormSuodatus)];
