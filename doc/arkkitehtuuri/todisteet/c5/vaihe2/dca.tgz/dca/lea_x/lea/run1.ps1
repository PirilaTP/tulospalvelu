& "$PSScriptRoot\wfo-msvc.exe"
"rc=$LASTEXITCODE"
