	.386p
	ifdef ??version
	if ??version GT 500H
	.mmx
	endif
	endif
	model flat
	ifndef	??version
	?debug	macro
	endm
	endif
	?debug	S "p1.cpp"
	?debug	T "p1.cpp"
_TEXT	segment dword public use32 'CODE'
_TEXT	ends
_DATA	segment dword public use32 'DATA'
_DATA	ends
_BSS	segment dword public use32 'BSS'
_BSS	ends
DGROUP	group	_BSS,_DATA
_BSS	segment dword public use32 'BSS'
_pre_enum	label	byte
	db	4	dup(?)
_pre_S1	label	byte
	db	8	dup(?)
_pre_S1b	label	byte
	db	16	dup(?)
_pre_charsigned	label	byte
	db	101	dup(?)
_pre_wchar	label	byte
	db	2	dup(?)
_pre_time_t	label	byte
	db	4	dup(?)
_pre_tchar	label	byte
	db	2	dup(?)
_pre_long	label	byte
	db	4	dup(?)
_pre_ldouble	label	byte
	db	10	dup(?)
_pre_bool	label	byte
	db	1	dup(?)
_pre_wint	label	byte
	db	2	dup(?)
_post_enum	label	byte
	db	4	dup(?)
_post_S2	label	byte
	db	5	dup(?)
_post_S2b	label	byte
	db	11	dup(?)
_post_charsigned	label	byte
	db	100	dup(?)
_pk_S3	label	byte
	db	5	dup(?)
_pk_S4_after_pop	label	byte
	db	5	dup(?)
_optpush_a8_S5	label	byte
	db	8	dup(?)
_optpop_S6	label	byte
	db	5	dup(?)
_BSS	ends
_TEXT	segment dword public use32 'CODE'
_TEXT	ends
	public	_pre_enum
	public	_pre_S1
	public	_pre_S1b
	public	_pre_charsigned
	public	_pre_wchar
	public	_pre_time_t
	public	_pre_tchar
	public	_pre_long
	public	_pre_ldouble
	public	_pre_bool
	public	_pre_wint
	public	_post_enum
	public	_post_S2
	public	_post_S2b
	public	_post_charsigned
	public	_pk_S3
	public	_pk_S4_after_pop
	public	_optpush_a8_S5
	public	_optpop_S6
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\mem.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\_loc.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\locale.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\_str.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\tchar.h" 23780 45058
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\wchar.h" 23780 45058
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\_null.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\_defs.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\_stddef.h" 23780 45057
	?debug	D "c:\program files (x86)\embarcadero\studio\37.0\include\windows\crtl\time.h" 23780 45058
	?debug	D "p1.cpp" 23929 1297
	end
