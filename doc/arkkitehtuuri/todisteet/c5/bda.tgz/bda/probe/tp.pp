/* m.cpp 1: */
/* m.cpp 2: */BORLANDC 0x0780
/* m.cpp 3: */
/* m.cpp 4: */
/* m.cpp 5: */CODEGEARC 0x0780
/* m.cpp 6: */
/* m.cpp 7: */
/* m.cpp 8: */BCPLUSPLUS 0x0780
/* m.cpp 9: */
/* m.cpp 10: */
/* m.cpp 11: */
/* m.cpp 12: */
/* m.cpp 13: */
/* m.cpp 14: */
/* m.cpp 15: */
/* m.cpp 16: */
/* m.cpp 17: */
/* m.cpp 18: */
/* m.cpp 19: */
/* m.cpp 20: */WIN32u yes
/* m.cpp 21: */
/* m.cpp 22: */
/* m.cpp 23: */
/* m.cpp 24: */
/* m.cpp 25: */
/* m.cpp 26: */WIN32__ yes
/* m.cpp 27: */
/* m.cpp 28: */
/* m.cpp 29: */M_IX86 300
/* m.cpp 30: */
/* m.cpp 31: */
/* m.cpp 32: */MT yes
/* m.cpp 33: */
/* m.cpp 34: */
/* m.cpp 35: */MT__ yes
/* m.cpp 36: */
/* m.cpp 37: */
/* m.cpp 38: */
/* m.cpp 39: */
/* m.cpp 40: */
/* m.cpp 41: */
/* m.cpp 42: */
/* m.cpp 43: */
/* m.cpp 44: */ yes
/* m.cpp 45: */
/* m.cpp 46: */
/* m.cpp 47: */ yes
/* m.cpp 48: */
/* m.cpp 49: */
/* m.cpp 50: */ yes
/* m.cpp 51: */
/* m.cpp 52: */
/* m.cpp 53: */
/* m.cpp 54: */
/* m.cpp 55: */
/* m.cpp 56: */
/* m.cpp 57: */
/* m.cpp 58: */
/* m.cpp 59: */FLAT yes
/* m.cpp 60: */
/* m.cpp 61: */
/* m.cpp 62: */RTLDLL yes
/* m.cpp 63: */
/* m.cpp 64: */
/* m.cpp 65: */
/* m.cpp 66: */
/* m.cpp 67: */
/* m.cpp 68: */
/* m.cpp 69: */
/* m.cpp 70: */
/* m.cpp 71: */WCHAR_T_DEFINED yes
/* m.cpp 72: */
/* m.cpp 73: */
/* m.cpp 74: */CHAR_UNSIGNED yes
/* m.cpp 75: */
/* m.cpp 76: */
/* m.cpp 77: */
/* m.cpp 78: */
/* m.cpp 79: */
/* m.cpp 80: */
/* m.cpp 81: */
/* m.cpp 82: */
/* m.cpp 83: */CPLUSPLUS 1
/* m.cpp 84: */
/* m.cpp 85: */
/* m.cpp 86: */ yes
/* m.cpp 87: */
/* m.cpp 88: */
/* m.cpp 89: */
/* m.cpp 90: */
/* m.cpp 91: */
/* m.cpp 92: */
/* m.cpp 93: */
/* m.cpp 94: */
/* m.cpp 95: */