#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <locale.h>
#include <ctype.h>
#include <wctype.h>
static char  na[16] = "ab\xE4" "d";
static wchar_t wa[16] = L"ab\x00E4" L"d";
static void dumpw(const char *tag, const wchar_t *b){ printf("%-30s W:", tag); for(int i=0;i<8&&b[i];i++) printf(" %04X",(unsigned)b[i]); printf("\n"); }
int main(){
 wchar_t b[64];
 memset(b,0,sizeof b); _snwprintf(b,60,L"[%s]",wa); dumpw("_snwprintf %s wide",b);
 memset(b,0,sizeof b); _snwprintf(b,60,L"[%S]",na); dumpw("_snwprintf %S narrow",b);
 memset(b,0,sizeof b); _snwprintf(b,60,L"[%s]",na); dumpw("_snwprintf %s narrow(wrong)",b);
 memset(b,0,sizeof b); _snwprintf(b,4,L"[%s]",wa); printf("_snwprintf trunc n=4: len terminator? b[3]=%04X b[4]=%04X\n",b[3],b[4]);
 memset(b,0x55,sizeof b); int r=_snwprintf(b,4,L"abcdefgh"); printf("_snwprintf ret=%d b[3]=%04X b[4]=%04X\n",r,b[3],b[4]);
 char nb[16]; memset(nb,0x55,sizeof nb); r=_snprintf(nb,4,"abcdefgh"); printf("_snprintf ret=%d nb[3]=%02X nb[4]=%02X\n",r,(unsigned char)nb[3],(unsigned char)nb[4]);
 wchar_t t[64]; int r2=swprintf(t,L"%d-%s",5,wa); printf("swprintf noLen ret=%d\n",r2);
 // conversions
 wchar_t w2[16]; memset(w2,0,sizeof w2); size_t n=mbstowcs(w2,na,15); printf("mbstowcs(C locale) n=%d w2[2]=%04X\n",(int)n,w2[2]);
 char *lc=setlocale(LC_CTYPE,"fi-FI"); printf("setlocale fi-FI -> %s\n", lc?lc:"(null)");
 if(lc){ memset(w2,0,sizeof w2); n=mbstowcs(w2,na,15); printf("mbstowcs(fi-FI) n=%d w2[2]=%04X\n",(int)n,w2[2]); memset(b,0,sizeof b); swprintf(b,L"%S",na); printf("swprintf %%S(fi-FI) -> %04X\n",b[2]); }
 wchar_t *wl=_wsetlocale(LC_CTYPE,L"fi-FI"); printf("_wsetlocale fi-FI -> %s\n", wl?"ok":"(null)");
 printf("towupper(0xE4)=%04X toupper(0xE4)=%02X towlower(0xC4)=%04X isalpha(0xE4)=%d iswalpha(0xE4)=%d tolower(0xC4)=%02X\n",(unsigned)towupper(0xE4),(unsigned)toupper(0xE4),(unsigned)towlower(0xC4),isalpha(0xE4),iswalpha(0xE4),(unsigned)tolower(0xC4));
 return 0;}
