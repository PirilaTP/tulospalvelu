#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitKilpMaaritys.cpp"
char sz__TFormVaiheMaar[(int)sizeof(TFormVaiheMaar)];
