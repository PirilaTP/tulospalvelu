@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars32.bat" >nul 2>&1
cd /d "%~dp0"
set TP=C:\dev\tulospalvelu\TPsource\V52
set COM=/nologo /W3 /EHsc /MT /GS /Gy /fp:precise /Zc:wchar_t /Zc:forScope /Zc:inline /D WIN32 /D _CRT_SECURE_NO_DEPRECATE /D _CRT_NON_CONFORMING_WCSTOK /D _CRT_NON_CONFORMING_SWPRINTFS /D _CONSOLE /D _UNICODE /D UNICODE /J /I %TP%\include /I %TP%\Tp
rem A: GL variant (console options of JukLuenta: TextFileClass compiled in the exe project) 
cl %COM% /O2 /Oi /Oy- /GL /FAs /Fagl/ /Fe:gs59_gl.exe /Fogl/ gs59.cpp %TP%\tputilv2\TextFileClass.cpp /link /LTCG /DEBUG /OPT:REF /OPT:ICF /SAFESEH /DYNAMICBASE "%TP%\..\..\TPexe\Lib\V52\VS\Release\tputilv2.lib" > gl.build.txt 2>&1
rem B: tputilv2.lib flags (O2 Ob1 Oy-, no GL) = how HkMaali/ViestiMaali get TextFileClass
cl %COM% /O2 /Ob1 /Oy- /FAs /Fanogl/ /Fe:gs59_nogl.exe /Fonogl/ gs59.cpp %TP%\tputilv2\TextFileClass.cpp /link /DEBUG /OPT:REF /OPT:ICF /SAFESEH /DYNAMICBASE "%TP%\..\..\TPexe\Lib\V52\VS\Release\tputilv2.lib" > nogl.build.txt 2>&1
rem C: same as B but without /GS (control)
cl %COM:/GS=/GS-% /O2 /Ob1 /Oy- /FAs /Fanogs/ /Fe:gs59_nogs.exe /Fonogs/ gs59.cpp %TP%\tputilv2\TextFileClass.cpp /link /DEBUG /SAFESEH "%TP%\..\..\TPexe\Lib\V52\VS\Release\tputilv2.lib" > nogs.build.txt 2>&1
