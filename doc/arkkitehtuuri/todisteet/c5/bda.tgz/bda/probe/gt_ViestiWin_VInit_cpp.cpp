#include "C:/dev/tulospalvelu/TPsource/V52/Juk/VInit.cpp"
char sz__ipparamtp[(int)sizeof(ipparamtp)];
