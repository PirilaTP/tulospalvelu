#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/VertAikaUnit.cpp"
char sz__TVertAikaFrm[(int)sizeof(TVertAikaFrm)];
