@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars32.bat" >nul 2>&1
cd /d "%~dp0"
dumpbin /disasm /nologo gs59_gl.exe > gl.dis.txt 2>&1
