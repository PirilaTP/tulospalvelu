import os, re, sys, subprocess, ctypes, shutil, importlib.util
logdir, srccopy, outdir, tool = sys.argv[1:5]
spec = importlib.util.spec_from_file_location('v', tool); v = importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
def short(p):
    b = ctypes.create_unicode_buffer(1024); ctypes.windll.kernel32.GetShortPathNameW(p, b, 1024); return b.value
def recorded(log, src):
    t = open(os.path.join(logdir, log + '.log'), encoding='utf-8-sig', errors='replace').read().splitlines()
    for i, l in enumerate(t):
        m = re.match(r'bcc32 command line for "(.*)"$', l)
        if m and m.group(1).lower() == src.lower():
            parts = []; j = i + 1
            while j < len(t) and t[j].startswith('  '):
                parts.append(t[j][2:]); j += 1
            return ''.join(parts).rstrip()
wd = os.path.join(srccopy, 'RADStudio10')
def compile(log, src, od, pch=None, extra=''):
    cmd = recorded(log, src)
    os.makedirs(od, exist_ok=True); od = short(od)
    obj = os.path.join(od, 'u.obj')
    c = re.sub(r' -o\S+', lambda _: ' -o' + obj, cmd, count=1)
    c = re.sub(r' -n\S+', lambda _: ' -n' + od, c, count=1)
    c = re.sub(r' -H=\S+', lambda _: ' -H=' + (pch or os.path.join(od, 'p.pch')), c, count=1)
    if extra: c = c.replace(' -c ', ' -c ' + extra + ' ')
    exe, rest = c.split('.exe ', 1)
    r = subprocess.run('"' + exe + '.exe" ' + rest, cwd=wd, capture_output=True, text=True, errors='replace')
    open(os.path.join(od,'out.txt'),'w').write(c+'\n'+r.stdout+r.stderr)
    assert r.returncode == 0, r.stdout + r.stderr
    return obj
def edit(path, fn):
    raw = open(path,'rb').read(); nl = b'\r\n' if b'\r\n' in raw else b'\n'
    L = raw.split(nl); L = fn(L); open(path,'wb').write(nl.join(L)); return raw
