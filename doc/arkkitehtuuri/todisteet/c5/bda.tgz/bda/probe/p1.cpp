#include <time.h>
#include <wchar.h>
#include <tchar.h>
#define SZ(n,x) char n[(int)sizeof(x)]
#define VAL(n,x) char n[(x)+100]
enum E1 {A1,B1};
struct S1 {char c; int i;};
struct S1b {char c; short s; double d;};
SZ(pre_enum,E1);
SZ(pre_S1,S1);
SZ(pre_S1b,S1b);
VAL(pre_charsigned, ((char)-1<0)?1:0);
SZ(pre_wchar,wchar_t);
SZ(pre_time_t,time_t);
SZ(pre_tchar,_TCHAR);
SZ(pre_long,long);
SZ(pre_ldouble,long double);
SZ(pre_bool,bool);
SZ(pre_wint,wint_t);
#pragma option -K -a1
enum E2 {A2,B2};
struct S2 {char c; int i;};
struct S2b {char c; short s; double d;};
SZ(post_enum,E2);
SZ(post_S2,S2);
SZ(post_S2b,S2b);
VAL(post_charsigned, ((char)-1<0)?1:0);
#pragma pack(push,1)
struct S3 {char c; int i;};
#pragma pack(pop)
struct S4 {char c; int i;};
SZ(pk_S3,S3);
SZ(pk_S4_after_pop,S4);
#pragma option push -a8
struct S5 {char c; int i;};
SZ(optpush_a8_S5,S5);
#pragma option pop
struct S6 {char c; int i;};
SZ(optpop_S6,S6);
