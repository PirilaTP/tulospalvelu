import os,re,subprocess,sys,ctypes,json,time
from multiprocessing import Pool
WORK=r'C:\dev\tulospalvelu\TPsource\V52\RADStudio10'
ROOT=r'C:\dev\tulospalvelu\TPsource\V52'
SCR=r'C:\Users\KAYTTA~1\AppData\Local\Temp\claude\a25cf22582434270\da7a5c13-d4bd-4f7b-a86d-4289d7e5797c\scratchpad\c5\bda'
TMP=os.path.join(SCR,'tmp_pp')
LOGS={'HkKisaWin':'HkKisaWin','ViestiWin':'ViestiWin','Tputil-XE':'Tputil-XE','DBboxm-XE':'DBboxm-XE'}
def getcmds(log):
    text=open(os.path.join(WORK,'build-logs',log+'.log'),encoding='utf-8-sig',errors='replace').read().splitlines()
    cmds=[];i=0
    while i<len(text):
        m=re.match(r'bcc32 command line for "(.*)"$',text[i])
        if m:
            src=m.group(1);parts=[];i+=1
            while i<len(text) and text[i].startswith('  '):
                parts.append(text[i][2:]);i+=1
            cmds.append((src,''.join(parts).rstrip()))
        else:i+=1
    return cmds
PFX=re.compile(r'^/\* (.*?) (\d+): \*/(.*)$')
PRAG=re.compile(r'^\s*#\s*pragma\s+(option|pack)\b\s*(.*)$')
DEF1=re.compile(r'^\s*(?:typedef\s+)?(struct|class|union|enum)\b([^;{()=]*?)(?::[^;{]*)?(\{)?\s*$')
def norm(p):
    p=p.strip()
    if 'embarcadero' in p.lower(): return None
    try: a=os.path.normpath(os.path.join(WORK,p))
    except: return p
    try: return os.path.relpath(a,ROOT).replace(chr(92),'/')
    except: return a
def apply_opts(st,toks):
    for t in toks:
        if t=='-K': st['K']='u'
        elif t=='-K-': st['K']='s'
        elif t in('-a-',): st['a']=1
        elif re.fullmatch(r'-a\d+',t): st['a']=int(t[2:])
        elif t=='-a': st['a']=8 if False else st['a']
        elif t in('-b','-bi'): st['e']='int'
        elif t in('-b-','-bi-'): st['e']='min'
def work(args):
    proj,n,src,cmd=args
    cmd=cmd.replace('bcc32.exe','cpp32.exe',1)
    cmd=re.sub(r' -o\S+','',cmd);cmd=re.sub(r' -n\S+','',cmd);cmd=re.sub(r' -H=\S+',' ',cmd)
    cmd=re.sub(r' -H(c)? ',' ',cmd);cmd=cmd.replace(' -c ',' ')
    init={'a':8,'K':'u' if re.search(r' -K( |$)',cmd) else 's','e':'min' if re.search(r' -bi?- ',cmd) else 'int'}
    am=re.search(r' -a(\d+) ',cmd)
    if am: init['a']=int(am.group(1))
    exe,rest=cmd.split('.exe ',1)
    out=os.path.join(TMP,'%s_%03d.i'%(proj,n))
    line='"'+exe+'.exe" '+rest[:-len(src)]+'-o'+out+' '+src
    t0=time.time()
    p=subprocess.run(line,cwd=WORK,capture_output=True,text=True,encoding='cp1252',errors='replace')
    if not os.path.exists(out): return {'proj':proj,'src':src,'err':(p.stdout+p.stderr)[-300:]}
    st=dict(init);stack=[];packstack=[]
    firstinc=[];seen=set();defs=[];pend=None;opened=[];depth=0;events=[];prevfile=None
    errs=(p.stdout+p.stderr).count('Error')
    with open(out,encoding='cp1252',errors='replace') as f:
        for ln in f:
            m=PFX.match(ln)
            if not m:
                if ln.lstrip().startswith('#pragma'):
                    fl,no,body=(prevfile or ''),0,ln.rstrip()
                else: continue
            else:
                fl,no,body=m.group(1),int(m.group(2)),m.group(3)
            if fl!=prevfile:
                prevfile=fl
                nf=norm(fl)
                if nf and nf not in seen:
                    seen.add(nf);firstinc.append((nf,dict(st)))
            if '#' in body:
                pm=PRAG.match(body)
                if pm:
                    kind,arg=pm.group(1),pm.group(2).strip()
                    nf=norm(fl)
                    if kind=='option':
                        toks=arg.split()
                        if toks and toks[0]=='push':
                            stack.append(dict(st));apply_opts(st,toks[1:])
                        elif toks and toks[0]=='pop':
                            if stack: st=stack.pop()
                        else:
                            apply_opts(st,toks)
                            if nf: events.append((nf,no,'option '+arg,dict(st)))
                    else:
                        a=re.sub(r'\s+','',arg)
                        mm=re.match(r'\((?:(push|pop)(?:,(\d+))?|(\d+)?)\)',a)
                        if mm:
                            if mm.group(1)=='push':
                                packstack.append(dict(st))
                                if mm.group(2): st['a']=int(mm.group(2))
                            elif mm.group(1)=='pop':
                                if packstack: st['a']=packstack.pop()['a']
                            else:
                                st['a']=int(mm.group(3)) if mm.group(3) else init['a']
                            if nf: events.append((nf,no,'pack '+a,dict(st)))
                    continue
            nf=norm(fl)
            if not nf: pend=None;continue
            if pend:
                if body.strip()=='' : continue
                if body.lstrip().startswith('{'):
                    defs.append(list(pend)+[dict(st)]);opened.append((len(defs)-1,depth))
                pend=None
            mm=DEF1.match(body)
            if mm:
                kw=mm.group(1);mid=mm.group(2).strip()
                toks=[t for t in re.findall(r'\w+',mid) if t not in('PACKAGE','__declspec','dllexport','dllimport','__export','_export','_RTLENTRY','_EXPCLASS','_CLASSTYPE','_CLASSDEF')]
                name=toks[-1] if toks else '<anon>'
                pe=(nf,no,kw,name)
                if mm.group(3): defs.append(list(pe)+[dict(st)]);opened.append((len(defs)-1,depth))
                else: pend=pe
            code=re.sub(r"'[^']*'",'',re.sub(r'"[^"]*"','',body))
            code=code.split('//')[0]
            for ch in code:
                if ch=='{': depth+=1
                elif ch=='}':
                    depth-=1
                    if opened and opened[-1][1]==depth:
                        di,_=opened.pop()
                        tail=code[code.index('}')+1:] if depth>=0 else ''
                        tm=re.match(r'\s*([\w\s,*\[\]]*);',tail)
                        if tm and defs[di][3]=='<anon>':
                            nm=[x for x in re.findall(r'\w+',tm.group(1)) if x not in('far','near')]
                            if nm: defs[di][3]=nm[0]+'(typedef)'
    try: os.remove(out)
    except: pass
    return {'proj':proj,'src':src,'init':init,'errs':errs,'firstinc':firstinc,'events':events,'defs':defs,'final':st,'secs':round(time.time()-t0,1)}
if __name__=='__main__':
    os.makedirs(TMP,exist_ok=True)
    projs=sys.argv[1].split(',');lim=int(sys.argv[2]) if len(sys.argv)>2 else 10**9
    jobs=[]
    for p in projs:
        for n,(s,c) in enumerate(getcmds(LOGS[p])[:lim]): jobs.append((p,n,s,c))
    res=[]
    with Pool(int(os.environ.get('NP','6'))) as pool:
        for r in pool.imap_unordered(work,jobs):
            res.append(r);print(r['proj'],r['src'],r.get('secs'),r.get('errs'),r.get('err',''),flush=True)
    json.dump(res,open(os.path.join(SCR,'ana_%s.json'%'_'.join(projs)),'w'))
