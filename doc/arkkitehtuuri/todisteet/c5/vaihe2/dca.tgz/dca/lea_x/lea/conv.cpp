#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <errno.h>
#include <limits.h>
int main(){
 setvbuf(stdout,0,_IONBF,0);
 const wchar_t *t[]={L"99999999999",L"2147483648",L"-2147483649",L"4294967296",L"4294967297",L" 12",L"+5",L"12abc",L"0x10",L"1e3",L"-0",L"",L"abc",L"1 2",L"٣", 0};
 for(int i=0;t[i];i++){
   errno=0; long a=wcstol(t[i],0,10); int e1=errno;
   printf("%-14ls _wtoi=%d _wtol=%ld wcstol=%ld(errno=%d) atoi(narrow)=%d\n",t[i],_wtoi(t[i]),_wtol(t[i]),a,e1,0);
 }
 wchar_t b[40]; 
 _itow(-5,b,10); printf("_itow(-5,10)=%ls\n",b);
 _itow(255,b,16); printf("_itow(255,16)=%ls\n",b);
 _ltow(-2147483647L-1,b,10); printf("_ltow(INT_MIN)=%ls\n",b);
 _ultow(4294967295UL,b,10); printf("_ultow(max)=%ls\n",b);
 printf("_wtof(1,5)=%g _wtof(1.5)=%g _wtof(1e2)=%g _wtof( .5)=%g _wtof(-.5e1)=%g\n",_wtof(L"1,5"),_wtof(L"1.5"),_wtof(L"1e2"),_wtof(L" .5"),_wtof(L"-.5e1"));
 printf("wcstod(inf)=%g wcstod(0x1p3)=%g\n",wcstod(L"inf",0),wcstod(L"0x1p3",0));
 printf("atoi(99999999999)=%d atoi(2147483648)=%d\n",atoi("99999999999"),atoi("2147483648"));
 return 0;}
