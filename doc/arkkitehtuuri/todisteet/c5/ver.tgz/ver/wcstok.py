import os,re,sys,collections
root=sys.argv[1]
FN=re.compile(r'^(?:[A-Za-z_][\w\s\*&:<>,]*?[\s\*&])?([A-Za-z_][\w:~]*)\s*\([^;]*\)\s*(?:const)?\s*\{?\s*$')
files={}
for dp,dn,fn in os.walk(root):
    if 'Tests' in dp or '.vs' in dp: continue
    for f in fn:
        if f.lower().endswith('.cpp'):
            p=os.path.join(dp,f); files[p]=open(p,encoding='cp1252',errors='replace').read().split('\n')
# map function -> (file, start, end lines) crude: function starts at a line matching FN at col 0
funcs={}  # name -> list of (file, lines)
spans=[]
for p,L in files.items():
    cur=None;start=0
    for i,l in enumerate(L):
        if l and not l[0].isspace() and not l.startswith(('#','//','/*','}','{')) and FN.match(l.strip()) and not l.rstrip().endswith(';'):
            if cur: spans.append((p,cur,start,i))
            cur=FN.match(l.strip()).group(1).split('::')[-1];start=i
    if cur: spans.append((p,cur,start,len(L)))
tokf=set()
for p,n,s,e in spans:
    if any('wcstok' in x or 'strtok' in x for x in files[p][s:e]): tokf.add(n)
tokf-= {'if','while','for','switch','return'}
print('functions using wcstok/strtok:',len(tokf))
hits=0
for p,n,s,e in spans:
    L=files[p][s:e]; last=None
    for i,l in enumerate(L):
        code=l.split('//')[0]
        if re.search(r'\b(wcs|str)tok\s*\(',code):
            if re.search(r'\b(wcs|str)tok\s*\(\s*NULL',code) and last is not None:
                between=' '.join(x.split('//')[0] for x in L[last+1:i])
                called=set(re.findall(r'\b([A-Za-z_]\w*)\s*\(',between))&tokf
                called-= {n}
                if called:
                    hits+=1; print('%s:%d %s(): between lines %d-%d calls %s'%(os.path.relpath(p,root),s+i+1,n,s+last+1,s+i+1,sorted(called)))
            last=i
print('hits',hits)
