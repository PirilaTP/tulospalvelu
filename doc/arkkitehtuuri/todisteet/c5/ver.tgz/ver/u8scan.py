import os,sys,re
root=sys.argv[1]
res=[]
for dp,dn,fn in os.walk(root):
    for f in fn:
        if not f.lower().endswith(('.cpp','.h','.c','.hpp')): continue
        p=os.path.join(dp,f); b=open(p,'rb').read()
        if all(x<128 for x in b): continue
        bom=b.startswith(b'\xef\xbb\xbf')
        try: t=b.decode('utf-8'); u8=True
        except UnicodeDecodeError: u8=False
        if not u8: continue
        # tokenize: skip comments, find string/char literals with non-ascii
        n=0;i=0;L=len(t);line=1;lits=[]
        while i<L:
            c=t[i]
            if c=='\n': line+=1;i+=1;continue
            if t.startswith('//',i):
                j=t.find('\n',i); i=L if j<0 else j; continue
            if t.startswith('/*',i):
                j=t.find('*/',i+2); seg=t[i:j]; line+=seg.count('\n'); i=L if j<0 else j+2; continue
            if c in '"\'':
                pre=t[max(0,i-2):i]
                j=i+1
                while j<L and t[j]!=c and t[j]!='\n':
                    j+= 2 if t[j]==chr(92) else 1
                lit=t[i:j+1]
                if any(ord(x)>127 for x in lit): lits.append((line,('L' if pre.endswith('L') else 'N'),lit))
                i=j+1; continue
            i+=1
        res.append((os.path.relpath(p,root),bom,lits))
for p,bom,l in sorted(res):
    print('%s bom=%s nonascii_literals=%d'%(p,bom,len(l)))
    for x in l: print('   ',x[0],x[1],x[2].encode('unicode_escape').decode()[:80])
