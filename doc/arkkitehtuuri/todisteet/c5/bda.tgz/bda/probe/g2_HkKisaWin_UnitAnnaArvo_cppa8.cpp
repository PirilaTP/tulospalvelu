#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitAnnaArvo.cpp"
char off__TFormAnnaArvo__EdArvo[(int)(long)&(((TFormAnnaArvo*)0)->EdArvo)+1];
char off__TFormAnnaArvo__Button1[(int)(long)&(((TFormAnnaArvo*)0)->Button1)+1];
char off__TFormAnnaArvo__Button2[(int)(long)&(((TFormAnnaArvo*)0)->Button2)+1];
char off__TFormAnnaArvo__LblPrompt[(int)(long)&(((TFormAnnaArvo*)0)->LblPrompt)+1];
char off__TFormAnnaArvo__Arvo[(int)(long)&(((TFormAnnaArvo*)0)->Arvo)+1];
