#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitNollaus.cpp"
char off__TFormNollaus__CBTulokset[(int)(long)&(((TFormNollaus*)0)->CBTulokset)+1];
char off__TFormNollaus__CBEil[(int)(long)&(((TFormNollaus*)0)->CBEil)+1];
char off__TFormNollaus__CBPoissa[(int)(long)&(((TFormNollaus*)0)->CBPoissa)+1];
char off__TFormNollaus__CBLahto[(int)(long)&(((TFormNollaus*)0)->CBLahto)+1];
char off__TFormNollaus__CBEmit[(int)(long)&(((TFormNollaus*)0)->CBEmit)+1];
char off__TFormNollaus__CBRadat[(int)(long)&(((TFormNollaus*)0)->CBRadat)+1];
char off__TFormNollaus__CBVa[(int)(long)&(((TFormNollaus*)0)->CBVa)+1];
char off__TFormNollaus__Label1[(int)(long)&(((TFormNollaus*)0)->Label1)+1];
char off__TFormNollaus__CBVaiheet[(int)(long)&(((TFormNollaus*)0)->CBVaiheet)+1];
char off__TFormNollaus__RGSarjat[(int)(long)&(((TFormNollaus*)0)->RGSarjat)+1];
char off__TFormNollaus__LBSarjat[(int)(long)&(((TFormNollaus*)0)->LBSarjat)+1];
char off__TFormNollaus__Label2[(int)(long)&(((TFormNollaus*)0)->Label2)+1];
char off__TFormNollaus__Button1[(int)(long)&(((TFormNollaus*)0)->Button1)+1];
char off__TFormNollaus__CBVak[(int)(long)&(((TFormNollaus*)0)->CBVak)+1];
char off__TFormNollaus__RGMerkinta[(int)(long)&(((TFormNollaus*)0)->RGMerkinta)+1];
char off__TFormNollaus__MainMenu1[(int)(long)&(((TFormNollaus*)0)->MainMenu1)+1];
char off__TFormNollaus__Erikoistoiminnot1[(int)(long)&(((TFormNollaus*)0)->Erikoistoiminnot1)+1];
char off__TFormNollaus__Kerrokaikkiajatkymmenell1[(int)(long)&(((TFormNollaus*)0)->Kerrokaikkiajatkymmenell1)+1];
char off__TFormNollaus__Jaakaikkiajatkymmenell1[(int)(long)&(((TFormNollaus*)0)->Jaakaikkiajatkymmenell1)+1];
char off__TFormNollaus__SUKUNIMIisoillakirjaimilla1[(int)(long)&(((TFormNollaus*)0)->SUKUNIMIisoillakirjaimilla1)+1];
char off__TFormNollaus__Sukunimiisollaalkukirjaimella1[(int)(long)&(((TFormNollaus*)0)->Sukunimiisollaalkukirjaimella1)+1];
char off__TFormNollaus__Etunimiisollaalkukirjaimella1[(int)(long)&(((TFormNollaus*)0)->Etunimiisollaalkukirjaimella1)+1];
char off__TFormNollaus__BitBtn1[(int)(long)&(((TFormNollaus*)0)->BitBtn1)+1];
