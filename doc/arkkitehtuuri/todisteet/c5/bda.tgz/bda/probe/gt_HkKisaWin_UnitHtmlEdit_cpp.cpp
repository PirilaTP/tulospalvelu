#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitHtmlEdit.cpp"
char sz__TFormHtmlEdit[(int)sizeof(TFormHtmlEdit)];
