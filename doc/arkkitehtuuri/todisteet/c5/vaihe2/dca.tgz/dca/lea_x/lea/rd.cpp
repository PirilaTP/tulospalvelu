#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
static void mk(const char*fn,const unsigned char*b,int n){ FILE*f=fopen(fn,"wb"); fwrite(b,1,n,f); fclose(f);}
static void rd(const wchar_t*mode,const wchar_t*fn,const char*tag,int skip){
  FILE*f=0; if(_wfopen_s(&f,fn,mode)||!f){printf("%-40s open failed\n",tag);return;}
  if(skip) fseek(f,skip,SEEK_SET);
  wchar_t b[40]; int n=0;
  printf("%-40s",tag);
  while(fgetws(b,40,f)){ printf(" line%d:",++n); for(int i=0;b[i]&&i<10;i++) printf(" %04X",(unsigned)b[i]); }
  printf(" | pos=%ld\n",ftell(f)); fclose(f);}
int main(){
 setvbuf(stdout,0,_IONBF,0);
 static const unsigned char le[]={0xFF,0xFE,'a',0,0x0D,0,0x0A,0,0xE4,0,0x0D,0,0x0A,0};
 mk("le.tmp",le,sizeof le);
 rd(L"rb, ccs=UTF-16LE",L"le.tmp","LE file, rb ccs=UTF-16LE (skip 0)",0);
 rd(L"rb, ccs=UTF-16LE",L"le.tmp","LE file, rb ccs=UTF-16LE (fseek 2)",2);
 rd(L"rb",L"le.tmp","LE file, rb (fseek 2)",2);
 static const unsigned char le2[]={'a',0,0x0D,0,0x0A,0,0xE4,0,0x0D,0,0x0A,0};
 mk("le2.tmp",le2,sizeof le2);
 rd(L"rb, ccs=UTF-16LE",L"le2.tmp","LE no BOM, rb ccs=UTF-16LE",0);
 rd(L"rb",L"le2.tmp","LE no BOM, rb",0);
 return 0;}
