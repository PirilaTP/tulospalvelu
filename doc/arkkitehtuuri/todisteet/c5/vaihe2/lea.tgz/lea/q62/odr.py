# usage: odr.py DIR : find COMDAT-like (segment virtual) symbols whose normalized bodies differ between units
import sys,os,re,collections
HASH=re.compile('['+chr(36)+'][a-z]{8}')
d=sys.argv[1]
segs=collections.defaultdict(lambda: collections.defaultdict(list))   # sym -> body -> [units]
cnt=0
for f in sorted(os.listdir(d)):
    if not f.endswith('.asm'): continue
    cnt+=1
    L=open(os.path.join(d,f),encoding='cp1252',errors='replace').read().split(chr(10))
    i=0
    while i<len(L):
        m=re.match(r'^(\S+)\s+segment virtual',L[i])
        if m:
            name=m.group(1);j=i+1;body=[]
            while j<len(L) and not re.match(r'^%s\s+ends'%re.escape(name),L[j]):
                l=L[j]
                if l.strip().startswith(';') or l.strip().startswith('?debug') or l.strip()=='' : j+=1;continue
                l=HASH.sub('H',l); l=re.sub(r'\?live\d+@\d+','?live',l); l=re.sub(r'@\d+\b','@L',l); l=re.sub(r'\?patch\d+','?patch',l)
                body.append(l.rstrip()); j+=1
            segs[name]['\n'.join(body)].append(f)
            i=j
        i+=1
tot=len(segs); multi=sum(1 for s in segs.values() if sum(len(v) for v in s.values())>1)
diff=[(n,b) for n,b in segs.items() if len(b)>1]
print('units',cnt,'virtual symbols',tot,'defined in >1 unit',multi,'with differing bodies',len(diff))
for n,b in sorted(diff)[:int(sys.argv[2]) if len(sys.argv)>2 else 40]:
    print(' ',n[:100],[len(v) for v in b.values()])
