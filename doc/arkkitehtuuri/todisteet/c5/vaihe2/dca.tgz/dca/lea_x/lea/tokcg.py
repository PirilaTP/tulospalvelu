import os,re,sys
sys.stdout.reconfigure(encoding='utf-8')
ROOT='C:/dev/tulospalvelu/TPsource/V52'
files=[]
for d,dn,fn in os.walk(ROOT):
    if 'Tests' in d or '.git' in d: continue
    for f in fn:
        if f.lower().endswith('.cpp'): files.append(os.path.join(d,f))
fdef=re.compile(r'^(?:[A-Za-z_][\w:<>\*&\s]*?)\b([A-Za-z_]\w*(?:::\w+)?)\s*\([^;{}]*\)\s*(?:const\s*)?(?:\{|$)')
funcs={}  # name -> list of (file, start, end, tokline_first, tokline_last)
for p in files:
    L=open(p,'rb').read().decode('cp1252',errors='replace').split(chr(10))
    cur=None; depth=0
    for i,l in enumerate(L,1):
        s=l.rstrip()
        if depth==0:
            m=fdef.match(s)
            if m and not s.startswith(('#','//')) and not re.match(r'\s*(if|for|while|switch|return|else)\b',s):
                cur=[m.group(1),i,None,[]]
        depth+=s.count('{')-s.count('}')
        if cur and depth>0 and 'wcstok' in s and not s.lstrip().startswith('//') and '#define' not in s:
            cur[3].append(i)
        if cur and depth==0 and i>cur[1] and ('}' in s):
            cur[2]=i
            if cur[3]: funcs.setdefault(cur[0],[]).append((p,cur[1],cur[2],cur[3][0],cur[3][-1]))
            cur=None
        if depth<0: depth=0
names=set(funcs)
print(len(names),'functions containing wcstok')
for n,lst in funcs.items():
    for (p,a,b,t0,t1) in lst:
        L=open(p,'rb').read().decode('cp1252',errors='replace').split(chr(10))
        for i in range(t0,t1+1):
            s=L[i-1]
            if s.lstrip().startswith('//'): continue
            for c in re.findall(r'\b([A-Za-z_]\w*)\s*\(',s):
                if c in names and c!=n and c not in ('wcstok',):
                    print(os.path.relpath(p,ROOT).replace(os.sep,'/'),i,n,'->',c)
