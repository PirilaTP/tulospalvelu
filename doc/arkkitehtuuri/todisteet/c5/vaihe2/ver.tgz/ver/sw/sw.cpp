#include <stdio.h>
#include <wchar.h>
#include <string.h>
int main() {
  wchar_t msg[12]; int r;
  wmemset(msg, L'#', 12);
  r = swprintf(msg, 8, L"ab%s", L"cdefghijklmn");
  printf("ret=%d :", r);
  for (int i = 0; i < 12; i++) printf(" %04X", (unsigned)msg[i]);
  printf("\n");
  return 0;
}
