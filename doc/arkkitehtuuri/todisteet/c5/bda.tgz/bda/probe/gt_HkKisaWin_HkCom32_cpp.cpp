#include "C:/dev/tulospalvelu/TPsource/V52/Hk/HkCom32.cpp"
char sz__ipparamtp[(int)sizeof(ipparamtp)];
