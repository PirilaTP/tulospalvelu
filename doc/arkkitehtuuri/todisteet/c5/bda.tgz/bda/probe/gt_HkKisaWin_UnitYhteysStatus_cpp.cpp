#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitYhteysStatus.cpp"
char sz__TFormYhteysStatus[(int)sizeof(TFormYhteysStatus)];
