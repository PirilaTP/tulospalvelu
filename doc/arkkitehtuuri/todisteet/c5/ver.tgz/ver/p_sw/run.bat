@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars32.bat" >nul
cd /d "%~dp0"
cl /nologo /O2 /MT /J /D_CRT_SECURE_NO_DEPRECATE /D_CRT_NON_CONFORMING_SWPRINTFS /D_CRT_NON_CONFORMING_WCSTOK sw.cpp /Fe:sw-msvc.exe > build-msvc.txt 2>&1
