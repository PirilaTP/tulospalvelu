import sys,re
# args: file, then prefixes (ascii) to search as UTF-16LE and as narrow
data=open(sys.argv[1],'rb').read()
for pre in sys.argv[2:]:
    w=pre.encode('utf-16-le'); n=pre.encode('ascii')
    hits=[]
    for m in re.finditer(re.escape(w),data):
        tail=data[m.end():m.end()+16]
        hits.append('W:'+' '.join('%04X'%int.from_bytes(tail[i:i+2],'little') for i in range(0,12,2)))
    for m in re.finditer(re.escape(n)+b'[^\x00]',data):
        tail=data[m.end()-1:m.end()+6]
        hits.append('N:'+tail.hex(' '))
    print(repr(pre),len(hits),hits[:3])
