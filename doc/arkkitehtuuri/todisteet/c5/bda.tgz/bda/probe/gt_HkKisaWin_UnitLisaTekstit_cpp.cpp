#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitLisaTekstit.cpp"
char sz__TFormLisaTekstit[(int)sizeof(TFormLisaTekstit)];
