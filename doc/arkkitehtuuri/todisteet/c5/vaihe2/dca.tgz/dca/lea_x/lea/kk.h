#if defined(__BORLANDC__)
#pragma option -K -a1
#endif
