import json,glob,collections,csv,os,sys
S=os.path.dirname(os.path.abspath(__file__))
R=json.load(open(glob.glob(S+'/ana_Tputil*.json')[0]))
progs={'HkKisaWin':['HkKisaWin','Tputil-XE','DBboxm-XE'],'ViestiWin':['ViestiWin','Tputil-XE','DBboxm-XE']}
# A: headers before tputil.h
rowsA=[]
cnt=collections.defaultdict(lambda: collections.Counter())
for r in R:
    if 'firstinc' not in r: continue
    names=[f[0] for f in r['firstinc']]
    if 'include/tputil.h' in names:
        i=names.index('include/tputil.h')
        before=[n for n in names[:i] if n!=names[0]]
        ev=[e for e in r['events'] if e[0]=='include/tputil.h' and e[2].startswith('option')]
        evpos=ev[0][1] if ev else None
        rowsA.append([r['proj'],r['src'].replace(chr(92),'/'),names[0],';'.join(before),i,evpos])
        for n in before: cnt[r['proj']][n]+=1
    else:
        rowsA.append([r['proj'],r['src'].replace(chr(92),'/'),names[0] if names else '','(tputil.h not included)',-1,None])
w=csv.writer(open(S+'/tbl_tputil_order.csv','w',newline=''));w.writerow(['project','tu','first','repo_headers_before_tputil_h','idx','pragma_line']);w.writerows(rowsA)
print('A: TUs per proj / tputil.h included / with repo header before')
for p in ['HkKisaWin','ViestiWin','Tputil-XE','DBboxm-XE']:
    rr=[x for x in rowsA if x[0]==p]
    inc=[x for x in rr if x[4]>=0]
    bef=[x for x in inc if x[3]]
    print(p,len(rr),len(inc),len(bef)); 
    for n,c in cnt[p].most_common(25): print('   ',n,c)
# no tputil.h TUs
for p in ['HkKisaWin','ViestiWin']:
    print('NO tputil.h:',p,[x[1] for x in rowsA if x[0]==p and x[4]<0][:20],len([x for x in rowsA if x[0]==p and x[4]<0]))
# B/C: defs
def key(d): return (d[2],d[3],d[0],d[1])
res={}
for prog,ps in progs.items():
    D=collections.defaultdict(lambda: collections.defaultdict(list))
    for r in R:
        if r['proj'] not in ps or 'defs' not in r: continue
        for d in r['defs']:
            st=d[4];D[key(d)][(st['a'],st['K'],st['e'])].append(r['proj']+':'+r['src'].replace(chr(92),'/'))
    res[prog]=D
    rows=[]
    for k,v in D.items():
        a_set={s[0] for s in v};e_set={s[2] for s in v};k_set={s[1] for s in v}
        rows.append([prog,k[0],k[1],k[2],k[3],len(a_set)>1,len(e_set)>1,len(k_set)>1,';'.join('a=%s,K=%s,e=%s:%d'%(s[0],s[1],s[2],len(t)) for s,t in v.items()),'|'.join('a=%s,K=%s,e=%s:%s'%(s[0],s[1],s[2],','.join(sorted({x.split(':')[0] for x in t}))) for s,t in v.items()),len(sum(v.values(),[]))])
    w=csv.writer(open(S+'/tbl_types_%s.csv'%prog,'w',newline=''));w.writerow(['program','kind','name','file','line','a_differs','enum_size_differs','K_differs','states_count','states_projects','n_tu_defs']);w.writerows(rows)
    print('==',prog,'total type defs',len(rows),'a_differs',sum(1 for r in rows if r[5]),'enum_differs',sum(1 for r in rows if r[6]),'K_differs',sum(1 for r in rows if r[7]))
    for r in rows:
        if r[5]: print('  A-DIFF',r[1],r[2],r[3]+':'+str(r[4]),r[8])
    for r in rows:
        if r[6] and r[1]=='enum': print('  ENUM-DIFF',r[2],r[3]+':'+str(r[4]),r[8])
