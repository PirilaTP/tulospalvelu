#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitEmitKoodit.cpp"
char sz__TFormEmitKoodit[(int)sizeof(TFormEmitKoodit)];
