@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars32.bat" >nul 2>&1
cd /d "%~dp0"
cl /nologo /J /EHsc /MT /D_UNICODE /DUNICODE /D_CRT_SECURE_NO_DEPRECATE /D_CRT_NON_CONFORMING_SWPRINTFS /D_CONSOLE /W3 /Fe:%1-msvc.exe /Fo:%1-msvc.obj %1.cpp > %1-msvc.build.txt 2>&1
