#include <typeinfo>
struct B{virtual ~B(){}}; struct D:B{};
int f(B*p){ try{ throw 1;}catch(...){return 2;} }
int g(B*p){ return typeid(*p)==typeid(D); }
