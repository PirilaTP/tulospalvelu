#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitVakLisays.cpp"
char sz__TFormVakLisays[(int)sizeof(TFormVakLisays)];
