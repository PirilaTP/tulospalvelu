#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitOhjtiedot.cpp"
char sz__TFormOhjtiedot[(int)sizeof(TFormOhjtiedot)];
