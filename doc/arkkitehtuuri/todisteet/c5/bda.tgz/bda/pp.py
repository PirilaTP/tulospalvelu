import os,re,subprocess,sys,ctypes
log,workdir,outdir=sys.argv[1:4]
only=sys.argv[4] if len(sys.argv)>4 else None
os.makedirs(outdir,exist_ok=True)
b=ctypes.create_unicode_buffer(1024);ctypes.windll.kernel32.GetShortPathNameW(os.path.abspath(outdir),b,1024);outdir=b.value
text=open(log,encoding='utf-8-sig',errors='replace').read().splitlines()
cmds=[];i=0
while i<len(text):
    m=re.match(r'bcc32 command line for "(.*)"$',text[i])
    if m:
        src=m.group(1);parts=[];i+=1
        while i<len(text) and text[i].startswith('  '):
            parts.append(text[i][2:]);i+=1
        cmds.append((src,''.join(parts).rstrip()))
    else:i+=1
for n,(src,cmd) in enumerate(cmds):
    if only and only not in src: continue
    cmd=cmd.replace('bcc32.exe','cpp32.exe',1)
    cmd=re.sub(r' -o\S+','',cmd);cmd=re.sub(r' -n\S+','',cmd);cmd=re.sub(r' -H=\S+',' ',cmd)
    cmd=re.sub(r' -H(c)? ',' ',cmd);cmd=cmd.replace(' -c ',' ')
    exe,rest=cmd.split('.exe ',1)
    out=os.path.join(outdir,'%03d_%s.i'%(n,os.path.splitext(os.path.basename(src))[0]))
    line='"'+exe+'.exe" '+rest.replace(' '+src,' -o'+out+' '+src) if rest.endswith(src) else None
    p=subprocess.run(line,cwd=workdir,capture_output=True,text=True,encoding='cp1252',errors='replace')
    print(n,src,p.returncode,os.path.getsize(out) if os.path.exists(out) else -1,(p.stdout+p.stderr)[-200:].replace('\n',' | '),flush=True)
