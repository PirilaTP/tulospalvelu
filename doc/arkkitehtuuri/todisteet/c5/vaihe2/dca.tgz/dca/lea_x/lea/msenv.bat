@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars32.bat" >nul
cd /d "%~dp0"
for %%n in (cp u8 u8b) do (
  cl /nologo /J /EHsc /MT /D_UNICODE /DUNICODE /D_CRT_SECURE_NO_DEPRECATE /D_CRT_NON_CONFORMING_SWPRINTFS /D_CONSOLE /W3 /Fe:%%n-msvc.exe /Fo:%%n-msvc.obj %%n.cpp > %%n-msvc.build.txt 2>&1
  echo == msvc %%n >> msvc-enc.out
  %%n-msvc.exe >> msvc-enc.out
)
