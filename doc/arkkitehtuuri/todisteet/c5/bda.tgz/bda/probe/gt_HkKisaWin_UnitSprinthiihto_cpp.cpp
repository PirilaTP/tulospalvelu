#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitSprinthiihto.cpp"
char sz__TFormSprinthiihto[(int)sizeof(TFormSprinthiihto)];
