#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitEmitMuutokset.cpp"
char sz__TFormEmitMuutokset[(int)sizeof(TFormEmitMuutokset)];
