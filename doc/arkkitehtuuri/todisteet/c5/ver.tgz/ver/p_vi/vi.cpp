#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <wchar.h>
#define VERSIOKDI L"5.21"
int VersioInt(void) { return((int)(100*_wtof(VERSIOKDI))); }
int VersioInt20(void) { return((int)(100*_wtof(L"5.20"))); }
int main(){ printf("cw=%04X VersioInt=%d v520=%d\n", _control87(0,0), VersioInt(), VersioInt20()); return 0; }
