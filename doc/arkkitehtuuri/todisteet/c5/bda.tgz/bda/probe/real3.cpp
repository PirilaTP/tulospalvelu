#include <windows.h>
#ifdef WIN32
char macro_WIN32_after_windows_h[1];
#endif
#include <boxr.h>
char sz_datafile[(int)sizeof(datafile)];
char sz_HANDLE[(int)sizeof(HANDLE)];
char off_hDatf[(int)(long)&(((datafile*)0)->hDatf)+1];
