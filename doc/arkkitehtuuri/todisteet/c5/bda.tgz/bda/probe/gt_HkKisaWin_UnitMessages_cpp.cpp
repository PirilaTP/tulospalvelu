#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitMessages.cpp"
char sz__TFormMessages[(int)sizeof(TFormMessages)];
