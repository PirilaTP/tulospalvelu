#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitUusinta.cpp"
char sz__TFormUusinta[(int)sizeof(TFormUusinta)];
