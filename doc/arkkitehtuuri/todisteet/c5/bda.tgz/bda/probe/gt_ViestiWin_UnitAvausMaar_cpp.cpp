#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitAvausMaar.cpp"
char sz__TFormAvausMaar[(int)sizeof(TFormAvausMaar)];
