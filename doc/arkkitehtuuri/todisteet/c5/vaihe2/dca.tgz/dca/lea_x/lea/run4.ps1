& "$PSScriptRoot\tm-msvc.exe"
"rc=$LASTEXITCODE"
