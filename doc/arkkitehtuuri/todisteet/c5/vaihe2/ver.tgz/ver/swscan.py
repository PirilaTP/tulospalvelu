import re, sys, os
root = sys.argv[1]; units = [l.strip() for l in open(sys.argv[2]) if l.strip()]
files = set()
for u in units:
    p = u.split(',')[0] if ',' in u else u
    files.add(p)
# also headers? include all .cpp/.h under dirs
hits = []
for f in sorted(files):
    fp = os.path.join(root, f)
    if not os.path.exists(fp): print('nofile', f); continue
    t = open(fp, 'rb').read().decode('cp1252', 'replace')
    for m in re.finditer(r'\bswprintf\s*\(', t):
        # extract args up to matching paren
        i = m.end(); depth = 1; j = i; s = ''
        while j < len(t) and depth:
            c = t[j]
            if c == '(': depth += 1
            elif c == ')': depth -= 1
            j += 1
        args = t[i:j-1]
        # split top-level commas (ignore strings roughly)
        parts = []; d = 0; cur = ''; ins = False
        for c in args:
            if c == '"' : ins = not ins
            if not ins and c in '([': d += 1
            if not ins and c in ')]': d -= 1
            if c == ',' and d == 0 and not ins: parts.append(cur); cur = ''
            else: cur += c
        parts.append(cur)
        if len(parts) >= 3:
            a2 = parts[1].strip()
            if not re.match(r'^L?"', a2):
                line = t.count('\n', 0, m.start()) + 1
                hits.append((f, line, a2[:30], parts[2].strip()[:40].replace('\n',' ')))
for h in hits: print('%s:%d  n=%s  fmt=%s' % h)
print(len(hits))
