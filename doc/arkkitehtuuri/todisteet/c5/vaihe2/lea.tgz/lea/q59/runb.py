import subprocess,os,stat,sys
os.environ['PATH']=r'c:\program files (x86)\embarcadero\studio\37.0\bin;'+os.environ['PATH']
for m in ('r','w','r+'):
    p='../run/tb.txt'
    if os.path.exists(p): os.chmod(p,stat.S_IWRITE); os.remove(p)
    r=subprocess.run(['./gs59_bcc.exe',p,m],capture_output=True)
    print('bcc32 Open(%-2s) rc=0x%08X'%(m,r.returncode&0xFFFFFFFF), r.stdout.decode('utf-8','replace').replace('\r','').replace('\n',' | '), r.stderr.decode()[:100])
