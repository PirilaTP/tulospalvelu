import re,sys,collections,csv
res={}
for lg in ['HkKisaWin','ViestiWin','Tputil-XE','DBboxm-XE']:
    t=open(lg+'.log',encoding='utf-8-sig',errors='replace').read().split('\n')
    cmds=[];i=0
    while i<len(t):
        m=re.match(r'bcc32 command line for "(.*)"',t[i])
        if m:
            j=i+1;s=''
            while j<len(t) and t[j].startswith('  '):
                s+=' '+t[j].strip();j+=1
            cmds.append((m.group(1),s));i=j
        else:i+=1
    grp=collections.defaultdict(list)
    for f,s in cmds:
        s=re.sub(r'"[^"]*"','Q',s)
        toks=s.split()
        defs=[];flags=[]
        for k in toks[1:]:
            if k.startswith('-D'): defs+= [d for d in k[2:].split(';') if d]
            elif k.startswith('-I') or k.startswith('-n') or k.startswith('-o') or k.startswith('-H=') : continue
            elif k.startswith('-') : flags.append(k)
            else: continue
        grp[(tuple(sorted(defs)),tuple(flags))].append(f)
    res[lg]=grp
    print('==',lg,len(cmds),'cmds',len(grp),'distinct')
    for (d,fl),fs in grp.items():
        print(len(fs),'files e.g.',fs[:3]);print('  DEFS',';'.join(d));print('  FLAGS',' '.join(fl))
