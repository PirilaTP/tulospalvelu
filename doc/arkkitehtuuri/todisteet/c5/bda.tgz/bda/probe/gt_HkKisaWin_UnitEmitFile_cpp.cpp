#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitEmitFile.cpp"
char sz__TFormEmitFile[(int)sizeof(TFormEmitFile)];
