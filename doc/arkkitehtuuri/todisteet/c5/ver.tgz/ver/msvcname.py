import re,os,sys,glob,collections
out=sys.argv[1]
progs={'HkMaali':['HkMaali','tputilv2','dbboxm'],'JukMaali':['JukMaali','tputilv2','dbboxm'],'JukLuenta':['JukLuenta','tputilv2','dbboxm']}
H=re.compile(r'^class (.+?)\tsize\((\d+)\):')
W=re.compile(r'[^ \t\n|][^\n|]*?\(\d+\): (warning|note|error) [^\n]*\n')
def parse(p):
    t=open(p,encoding='cp1252',errors='replace').read();t=W.sub('',t);L=t.splitlines();i=0;R=[]
    while i<len(L):
        m=H.match(L[i]);i+=1
        if not m: continue
        mem=[];bars=0
        while i<len(L):
            l=L[i];i+=1
            if l.strip()=='+---':
                bars+=1
                if bars==2: break
                continue
            mm=re.match(r'^\s*(\d*)\s*\|\s*(.*)$',l)
            if mm: mem.append((mm.group(1),re.sub(r'\s+',' ',mm.group(2))))
            elif bars==1: mem.append(('?','NONMEMBER:'+l[:60]))
        R.append((m.group(1),int(m.group(2)),tuple(mem)))
    return R
for prog,ps in progs.items():
    T=collections.defaultdict(lambda: collections.defaultdict(list))
    for p in ps:
        for f in glob.glob(os.path.join(out,p,'*.txt')):
            u=p+'/'+os.path.basename(f)[:-4]
            for n,s,m in set(parse(f)): T[n][(s,m)].append(u)
    print('==',prog,len(T),'names')
    for n,v in sorted(T.items()):
        if len(v)<2: continue
        per=collections.defaultdict(set)
        for k,us in v.items():
            for u in us: per[u].add(k)
        if len(set(frozenset(x) for x in per.values()))>1:
            print(' ',n,'|',' || '.join('size=%d nmem=%d units=%d e.g.%s'%(sz,len(m),len(us),us[:2]) for (sz,m),us in sorted(v.items(),key=lambda kv:-len(kv[1]))))
if len(sys.argv)>2:
    for f in sys.argv[3:]:
        for n,s,m in parse(os.path.join(out,f+'.txt')):
            if n==sys.argv[2]: print(f,s,m)
