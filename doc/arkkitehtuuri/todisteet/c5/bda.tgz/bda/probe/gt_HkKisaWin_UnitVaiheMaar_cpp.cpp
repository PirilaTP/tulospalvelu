#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitVaiheMaar.cpp"
char sz__TFormVaiheMaar[(int)sizeof(TFormVaiheMaar)];
