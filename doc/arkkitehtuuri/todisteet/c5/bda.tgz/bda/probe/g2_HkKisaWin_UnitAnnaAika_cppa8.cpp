#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitAnnaAika.cpp"
char off__TFormAnnaAika__EdAika[(int)(long)&(((TFormAnnaAika*)0)->EdAika)+1];
char off__TFormAnnaAika__Button1[(int)(long)&(((TFormAnnaAika*)0)->Button1)+1];
char off__TFormAnnaAika__Button2[(int)(long)&(((TFormAnnaAika*)0)->Button2)+1];
char off__TFormAnnaAika__LblPrompt[(int)(long)&(((TFormAnnaAika*)0)->LblPrompt)+1];
char off__TFormAnnaAika__Len[(int)(long)&(((TFormAnnaAika*)0)->Len)+1];
char off__TFormAnnaAika__T0[(int)(long)&(((TFormAnnaAika*)0)->T0)+1];
char off__TFormAnnaAika__Aika[(int)(long)&(((TFormAnnaAika*)0)->Aika)+1];
