& "$PSScriptRoot\rd-msvc.exe"
"rc=$LASTEXITCODE"
