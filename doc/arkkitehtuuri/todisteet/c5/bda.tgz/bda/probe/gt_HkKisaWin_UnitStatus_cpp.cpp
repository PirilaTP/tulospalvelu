#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitStatus.cpp"
char sz__TFormYhteysStatus[(int)sizeof(TFormYhteysStatus)];
