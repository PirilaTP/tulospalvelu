#define SZ(n) struct n##_t {char c; int i;}; char n[(int)sizeof(n##_t)];
#pragma option -a1
SZ(s0)
#pragma option push -a8
SZ(s1)
#pragma pack(pop)
SZ(s2_after_pack_pop_of_option_push)
#pragma option -a8
#pragma pack(push,1)
SZ(s3)
#pragma option pop
SZ(s4_after_option_pop_of_pack_push)
#pragma option -a4
#pragma option push -a2
#pragma pack(push,1)
SZ(s5)
#pragma pack(pop)
SZ(s6_expect2)
#pragma option pop
SZ(s7_expect4)
#pragma pack(push,1)
#pragma pack(8)
SZ(s8_pack8)
#pragma pack(pop)
SZ(s9_after_pop)
#pragma pack(2)
SZ(s10_pack2)
#pragma pack()
SZ(s11_pack_empty)
