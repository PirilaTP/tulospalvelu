#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitYLahdot.cpp"
char sz__TFormYLahdot[(int)sizeof(TFormYLahdot)];
