// Probe: VersioInt() pattern (Tp/TpApu.cpp:66-69) and wcstomaksu pattern (TpApu.cpp:139) for all x.yz versions.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <math.h>
static int VersioInt(const wchar_t *s){ return (int)(100*_wtof(s)); }
static int Maksu(const wchar_t *s){ return (int)(100*_wtof(s)+0.1); }
int main(){
 volatile int dummy=0; (void)dummy;
 int bad=0, bad2=0; wchar_t b[16];
 for(int v=500; v<=599; v++){ swprintf(b,L"%d.%02d",v/100,v%100); int r=VersioInt(b); int r2=Maksu(b); if(r!=v){ bad++; if(bad<=8) printf("VersioInt(%ls)=%d (expected %d)\n",b,r,v);} if(r2!=v) bad2++; }
 printf("VersioInt mismatches for 5.00..5.99: %d ; Maksu pattern mismatches: %d\n",bad,bad2);
 wchar_t s1[]=L"5.21", s2[]=L"5.20"; printf("VersioInt(5.21)=%d VersioInt(5.20)=%d\n",VersioInt(s1),VersioInt(s2));
 // floor(x+0.500001) pattern: HkTls.cpp:1717
 int diff=0; for(int i=0;i<2000;i++){ double x=i/8.0+ i*1e-7; int a=(int)floor(x+0.500001); (void)a; }
 printf("done\n"); return 0;}
