import os,re,subprocess,sys,ctypes
log,src,probe,asm=sys.argv[1:5]
text=open(log,encoding='utf-8-sig',errors='replace').read().splitlines()
i=0
cmd=None
while i<len(text):
    m=re.match(r'bcc32 command line for "(.*)"$',text[i])
    if m and m.group(1).lower().endswith(src.lower()):
        parts=[];i+=1
        while i<len(text) and text[i].startswith('  '):
            parts.append(text[i][2:]);i+=1
        cmd=''.join(parts).rstrip();break
    i+=1
orig=m.group(1)
cmd=cmd[:-len(orig)]
cmd=re.sub(r' -o\S+','',cmd);cmd=re.sub(r' -n\S+','',cmd);cmd=re.sub(r' -H=\S+',' ',cmd);cmd=re.sub(r' -H(c)? ',' ',cmd)
cmd=cmd.replace(' -c ',' -S ')
exe,rest=cmd.split('.exe ',1)
line='"'+exe+'.exe" '+rest+' -o'+asm+' '+probe
p=subprocess.run(line,cwd=r'C:\dev\tulospalvelu\TPsource\V52\RADStudio10',capture_output=True,text=True,encoding='cp1252',errors='replace')
print(p.returncode,(p.stdout+p.stderr)[-600:])
t=open(asm,encoding='latin1').read()
print(' '.join('%s=%s'%(m.group(1),m.group(2)) for m in re.finditer(r'^_(\w+)\s+label\s+byte\s*\n\s*db\s+(\d+)\s+dup',t,re.M)))
