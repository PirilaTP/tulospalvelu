#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/OsuusTiedot.cpp"
char sz__TFormOsuus[(int)sizeof(TFormOsuus)];
