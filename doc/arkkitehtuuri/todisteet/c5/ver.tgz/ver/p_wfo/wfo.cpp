#include <stdio.h>
#include <wchar.h>
int main(int argc, char **argv){
  FILE *f=0; setvbuf(stdout,0,_IONBF,0);
  printf("before\n");
  errno_t e=_wfopen_s(&f, L"be.txt", L"rb, ccs=UTF-16BE");
  printf("after e=%d f=%p\n",(int)e,(void*)f);
  return 0;
}
