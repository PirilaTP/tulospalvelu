import sys, glob, collections, importlib.util
spec = importlib.util.spec_from_file_location('v', sys.argv[1]); v = importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
cnt = collections.Counter(); ex = {}
for f in sys.argv[2:]:
    for k, b in v.records(f):
        cnt[k] += 1
        if k.startswith('COMENT') and k not in ex: ex[k] = (f.split('/')[-1], b[:70])
    raw = open(f,'rb').read()
    # check trailing data after MODEND
    n = sum(3 + (raw[i+1]|raw[i+2]<<8) for i in [0]) 
for k in sorted(cnt): print(k, cnt[k], ex.get(k, ''))
