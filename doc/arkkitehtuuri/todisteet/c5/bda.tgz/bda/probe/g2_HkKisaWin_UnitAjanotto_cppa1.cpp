#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitAjanotto.cpp"
char off__TFormNappain__Edit1[(int)(long)&(((TFormNappain*)0)->Edit1)+1];
char off__TFormNappain__Button1[(int)(long)&(((TFormNappain*)0)->Button1)+1];
char off__TFormNappain__Label1[(int)(long)&(((TFormNappain*)0)->Label1)+1];
char off__TFormNappain__Edit2[(int)(long)&(((TFormNappain*)0)->Edit2)+1];
char off__TFormNappain__Edit3[(int)(long)&(((TFormNappain*)0)->Edit3)+1];
char off__TFormNappain__Label2[(int)(long)&(((TFormNappain*)0)->Label2)+1];
char off__TFormNappain__Button2[(int)(long)&(((TFormNappain*)0)->Button2)+1];
char off__TFormNappain__CBPiste[(int)(long)&(((TFormNappain*)0)->CBPiste)+1];
char off__TFormNappain__Label3[(int)(long)&(((TFormNappain*)0)->Label3)+1];
char off__TFormNappain__KeyCode[(int)(long)&(((TFormNappain*)0)->KeyCode)+1];
char off__TFormNappain__KeyShift[(int)(long)&(((TFormNappain*)0)->KeyShift)+1];
char off__TFormNappain__MaxVa[(int)(long)&(((TFormNappain*)0)->MaxVa)+1];
char off__TFormNappain__Piste[(int)(long)&(((TFormNappain*)0)->Piste)+1];
