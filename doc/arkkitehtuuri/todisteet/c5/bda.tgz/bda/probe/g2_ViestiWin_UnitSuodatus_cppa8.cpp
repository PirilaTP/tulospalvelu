#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitSuodatus.cpp"
char off__TFormSuodatus__RGPeruste[(int)(long)&(((TFormSuodatus*)0)->RGPeruste)+1];
char off__TFormSuodatus__EdtTieto[(int)(long)&(((TFormSuodatus*)0)->EdtTieto)+1];
char off__TFormSuodatus__Label1[(int)(long)&(((TFormSuodatus*)0)->Label1)+1];
char off__TFormSuodatus__CBSarja[(int)(long)&(((TFormSuodatus*)0)->CBSarja)+1];
char off__TFormSuodatus__CBSeura[(int)(long)&(((TFormSuodatus*)0)->CBSeura)+1];
char off__TFormSuodatus__Label2[(int)(long)&(((TFormSuodatus*)0)->Label2)+1];
char off__TFormSuodatus__Label3[(int)(long)&(((TFormSuodatus*)0)->Label3)+1];
char off__TFormSuodatus__BtnSulje[(int)(long)&(((TFormSuodatus*)0)->BtnSulje)+1];
char off__TFormSuodatus__BtnKayta[(int)(long)&(((TFormSuodatus*)0)->BtnKayta)+1];
char off__TFormSuodatus__Button1[(int)(long)&(((TFormSuodatus*)0)->Button1)+1];
char off__TFormSuodatus__Label4[(int)(long)&(((TFormSuodatus*)0)->Label4)+1];
char off__TFormSuodatus__CBTark[(int)(long)&(((TFormSuodatus*)0)->CBTark)+1];
char off__TFormSuodatus__CBOsuus[(int)(long)&(((TFormSuodatus*)0)->CBOsuus)+1];
char off__TFormSuodatus__Label5[(int)(long)&(((TFormSuodatus*)0)->Label5)+1];
char off__TFormSuodatus__CBTyhja[(int)(long)&(((TFormSuodatus*)0)->CBTyhja)+1];
char off__TFormSuodatus__EdtValittu[(int)(long)&(((TFormSuodatus*)0)->EdtValittu)+1];
char off__TFormSuodatus__nMukana[(int)(long)&(((TFormSuodatus*)0)->nMukana)+1];
