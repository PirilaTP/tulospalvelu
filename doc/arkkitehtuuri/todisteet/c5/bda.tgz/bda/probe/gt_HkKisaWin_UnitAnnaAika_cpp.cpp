#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitAnnaAika.cpp"
char sz__TFormAnnaAika[(int)sizeof(TFormAnnaAika)];
