#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitAutoFile.cpp"
char sz__TFormAutoFile[(int)sizeof(TFormAutoFile)];
