import json,glob,os,re,subprocess,sys,collections,csv
from multiprocessing import Pool
S=os.path.dirname(os.path.abspath(__file__))
WORK=r'C:\dev\tulospalvelu\TPsource\V52\RADStudio10'
R=json.load(open(glob.glob(S+'/ana_Tputil*.json')[0]))
def getcmds(log):
    text=open(os.path.join(WORK,'build-logs',log+'.log'),encoding='utf-8-sig',errors='replace').read().splitlines()
    cmds={};i=0
    while i<len(text):
        m=re.match(r'bcc32 command line for "(.*)"$',text[i])
        if m:
            src=m.group(1);parts=[];i+=1
            while i<len(text) and text[i].startswith('  '):
                parts.append(text[i][2:]);i+=1
            cmds[src]=''.join(parts).rstrip()
        else:i+=1
    return cmds
CM={p:getcmds(p) for p in ['HkKisaWin','ViestiWin']}
def key(d): return (d[2],d[3],d[0],d[1])
def job(a):
    proj,src,classes,tag=a
    cmd=CM[proj][src]
    cmd=cmd[:-len(src)]
    cmd=re.sub(r' -o\S+','',cmd);cmd=re.sub(r' -n\S+','',cmd);cmd=re.sub(r' -H=\S+',' ',cmd);cmd=re.sub(r' -H(c)? ',' ',cmd)
    cmd=cmd.replace(' -c ',' -S ')
    absrc=os.path.normpath(os.path.join(WORK,src)).replace(chr(92),'/')
    base=re.sub(r'\W','_',proj+'_'+os.path.basename(src))
    pf=os.path.join(S,'probe','gt_%s.cpp'%base);asm=os.path.join(S,'probe','gt_%s.asm'%base)
    body='#include "%s"\n'%absrc+''.join('char sz__%s[(int)sizeof(%s)];\n'%(re.sub(r'\W','_',c),c) for c in classes)
    open(pf,'w').write(body)
    exe,rest=cmd.split('.exe ',1)
    line='"'+exe+'.exe" '+rest+' -o'+asm+' '+pf
    p=subprocess.run(line,cwd=WORK,capture_output=True,text=True,encoding='cp1252',errors='replace')
    out={}
    if os.path.exists(asm):
        t=open(asm,encoding='latin1').read()
        for m in re.finditer(r'^_sz__(\w+)\s+label\s+byte\s*\n\s*db\s+(\d+)\s+dup',t,re.M): out[m.group(1)]=int(m.group(2))
        os.remove(asm)
    err=[l for l in (p.stdout+p.stderr).splitlines() if 'Error' in l][:3]
    return (proj,src,tag,out,err)
if __name__=="__main__":
    grp={'HkKisaWin':['HkKisaWin','Tputil-XE','DBboxm-XE'],'ViestiWin':['ViestiWin','Tputil-XE','DBboxm-XE']}
    jobs=[];meta={}
    for prog,ps in grp.items():
        D=collections.defaultdict(lambda: collections.defaultdict(list))
        for r in R:
            if r['proj']!=prog or 'defs' not in r: continue   # only program TUs (library TUs have no VCL forms)
            for d in r['defs']:
                if d[2] in('class','struct','union') and d[3] not in('<anon>',) :
                    D[key(d)][d[4]['a']].append(r['src'])
        # also include library-defined types seen in program TUs with a differing from lib TUs: handled by sizing in lib TUs separately
        per=collections.defaultdict(set)
        for k,v in D.items():
            if len(v)>1:
                nm=k[1].replace('(typedef)','')
                for a,tus in v.items():
                    per[(prog,tus[0],a)].add(nm)
        for (prog_,src,a),cl in per.items():
            jobs.append((prog_,src,sorted(cl),'a%d'%a))
    print(len(jobs),'jobs',flush=True)
    res=[]
    with Pool(6) as pool:
        for r in pool.imap_unordered(job,jobs):
            res.append(r);print(r[0],r[1],r[2],len(r[3]),r[4],flush=True)
    json.dump(res,open(S+'/gt_res.json','w'))
