#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/LoppuKilpUnit.cpp"
char sz__TLoppuKilpForm[(int)sizeof(TLoppuKilpForm)];
