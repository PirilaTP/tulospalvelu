import json,collections,csv,sys,os
W=sys.argv[1]
d=json.load(open(W+r'\bda\ana_Tputil-XE_DBboxm-XE_HkKisaWin_ViestiWin.json'))
diff=set()
for r in csv.DictReader(open(W+r'\bda\tbl_gt_sizes.csv')):
    if r['differs']=='True': diff.add((r['program'],r['type']))
D=collections.defaultdict(lambda: collections.defaultdict(list))
for t in d:
    for df in t['defs']:
        nm=df[3].replace('(typedef)','')
        if (t['proj'],nm) in diff:
            D[(t['proj'],nm,df[0])]['a%d'%df[4]['a']].append(os.path.basename(t['src']))
for k in sorted(D):
    print(k[0],k[1],k[2],' | '.join('%s: %s'%(a,','.join(v)) for a,v in D[k].items()))
