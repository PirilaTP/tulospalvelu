#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
int main(int argc,char**argv){
  FILE *f=0; setvbuf(stdout,0,_IONBF,0);
  printf("before _wfopen_s with ccs=UTF-16BE\n");
  errno_t e=_wfopen_s(&f, L"be.tmp", L"wb, ccs=UTF-16BE");
  printf("after: err=%d f=%p\n",(int)e,(void*)f);
  return 0; }
