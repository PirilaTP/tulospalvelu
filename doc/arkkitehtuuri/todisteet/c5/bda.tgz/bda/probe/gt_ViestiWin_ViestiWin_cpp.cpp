#include "C:/dev/tulospalvelu/TPsource/V52/RADStudio10/ViestiWin.cpp"
char sz__ipparamtp[(int)sizeof(ipparamtp)];
