#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitSeurat.cpp"
char sz__TEditDialog[(int)sizeof(TEditDialog)];
