#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitStatus.cpp"
char sz__TFormYhteysStatus[(int)sizeof(TFormYhteysStatus)];
