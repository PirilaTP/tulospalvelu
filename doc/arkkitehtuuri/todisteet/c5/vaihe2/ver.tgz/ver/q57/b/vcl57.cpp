// Q57 probe: x87 control word in a VCL GUI program (packages, dynamic RTL)
#include <vcl.h>
#pragma hdrstop
#include <windows.h>
#include <float.h>
#include <stdio.h>
extern int VersioInt(void);           // real Tp/TpApu.cpp
extern int VersioIntProbe(const wchar_t *s);   // vi57.cpp, same expression
static unsigned cw_now(void) { return _control87(0, 0) ; }
#pragma argsused
WINAPI _tWinMain(HINSTANCE, HINSTANCE, LPTSTR, int)
{
	FILE *f = fopen("q57.out", "w");
	fprintf(f, "cw_at_WinMain_entry   _control87=%04X Get8087CW=%04X\n", cw_now() & 0xFFFF, (unsigned)Get8087CW());
	fprintf(f, "VersioInt_entry=%d probe_5.21=%d\n", VersioInt(), VersioIntProbe(L"5.21"));
	Application->Initialize();
	fprintf(f, "cw_after_App_Init     _control87=%04X Get8087CW=%04X\n", cw_now() & 0xFFFF, (unsigned)Get8087CW());
	TForm *frm = new TForm(Application, 0);
	frm->Visible = false;
	fprintf(f, "cw_after_TForm        _control87=%04X Get8087CW=%04X\n", cw_now() & 0xFFFF, (unsigned)Get8087CW());
	fprintf(f, "VersioInt_after=%d probe_5.21=%d\n", VersioInt(), VersioIntProbe(L"5.21"));
	Set8087CW(0x027F);   // control experiment: 53-bit precision
	fprintf(f, "cw_forced_027F _control87=%04X VersioInt=%d probe_5.21=%d\n", cw_now() & 0xFFFF, VersioInt(), VersioIntProbe(L"5.21"));
	Set8087CW(0x037F);
	fprintf(f, "Default8087CW=%04X\n", (unsigned)Default8087CW);
	fclose(f);
	return 0;
}
