@echo off
set BIN=c:\program files (x86)\embarcadero\studio\37.0\bin
set LIBROOT=c:\program files (x86)\embarcadero\studio\37.0\lib
set TP=C:\dev\tulospalvelu\TPsource\V52
"%BIN%\bcc32.exe" @..\tpapu.args -n. -o.\TpApu.obj "%TP%\Tp\TpApu.cpp" > cc_tpapu.txt 2>&1
"%BIN%\bcc32.exe" @..\tpapu.args -n. -o.\vcl57.obj vcl57.cpp > cc_vcl57.txt 2>&1
"%BIN%\bcc32.exe" @..\tpapu.args -n. -o.\vi57.obj vi57.cpp > cc_vi57.txt 2>&1
"%BIN%\ilink32.exe" -G8 -L"%LIBROOT%\win32\release";"%LIBROOT%\win32\release\psdk";"C:\Users\Public\Documents\Embarcadero\Studio\37.0\DCP" -aa -Tpe c0w32w rtl.bpi vcl.bpi memmgr.lib sysinit.obj vcl57.obj vi57.obj TpApu.obj , vcl57.exe , vcl57.map , "%TP%\..\..\TPexe\Lib\V521\release_build\Tputil-XE.lib" import32.lib cp32mti.lib , , > link.txt 2>&1
