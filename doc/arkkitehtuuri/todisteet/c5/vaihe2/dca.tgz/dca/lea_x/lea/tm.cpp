#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
int main(){
 setvbuf(stdout,0,_IONBF,0);
 struct tm tt; memset(&tt,0,sizeof tt); tt.tm_year=140; tt.tm_mon=5; tt.tm_mday=15; tt.tm_hour=12;
 time_t r=mktime(&tt); printf("mktime(2040-06-15 12:00) = %ld (sizeof time_t=%d)\n",(long)r,(int)sizeof(time_t));
 time_t days=(time_t)25000; time_t t=days; t*=86400;   // time_t_date: t *= 86400 (days 25000 = 2038-06-..)
 struct tm *g=gmtime(&t); printf("days=25000 -> t=%ld gmtime=%s", (long)t, g?"":"NULL\n"); if(g) printf("%04d-%02d-%02d\n",g->tm_year+1900,g->tm_mon+1,g->tm_mday);
 time_t d2=20000; d2*=86400; g=gmtime(&d2); printf("days=20000 -> %04d-%02d-%02d\n",g->tm_year+1900,g->tm_mon+1,g->tm_mday);
 return 0;}
