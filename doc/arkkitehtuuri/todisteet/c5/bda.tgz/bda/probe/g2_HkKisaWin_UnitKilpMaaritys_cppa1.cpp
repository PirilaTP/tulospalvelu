#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitKilpMaaritys.cpp"
char off__TFormVaiheMaar__SG1[(int)(long)&(((TFormVaiheMaar*)0)->SG1)+1];
char off__TFormVaiheMaar__Button1[(int)(long)&(((TFormVaiheMaar*)0)->Button1)+1];
char off__TFormVaiheMaar__Button2[(int)(long)&(((TFormVaiheMaar*)0)->Button2)+1];
char off__TFormVaiheMaar__aktCol[(int)(long)&(((TFormVaiheMaar*)0)->aktCol)+1];
char off__TFormVaiheMaar__aktRow[(int)(long)&(((TFormVaiheMaar*)0)->aktRow)+1];
