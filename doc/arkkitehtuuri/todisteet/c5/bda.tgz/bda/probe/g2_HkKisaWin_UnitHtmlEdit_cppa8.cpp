#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitHtmlEdit.cpp"
char off__TFormHtmlEdit__PageControl1[(int)(long)&(((TFormHtmlEdit*)0)->PageControl1)+1];
char off__TFormHtmlEdit__TabText[(int)(long)&(((TFormHtmlEdit*)0)->TabText)+1];
char off__TFormHtmlEdit__TabHtml[(int)(long)&(((TFormHtmlEdit*)0)->TabHtml)+1];
char off__TFormHtmlEdit__MemoText[(int)(long)&(((TFormHtmlEdit*)0)->MemoText)+1];
char off__TFormHtmlEdit__MainMenu1[(int)(long)&(((TFormHtmlEdit*)0)->MainMenu1)+1];
char off__TFormHtmlEdit__Tiedosto1[(int)(long)&(((TFormHtmlEdit*)0)->Tiedosto1)+1];
char off__TFormHtmlEdit__Tallenna1[(int)(long)&(((TFormHtmlEdit*)0)->Tallenna1)+1];
char off__TFormHtmlEdit__allennanimell1[(int)(long)&(((TFormHtmlEdit*)0)->allennanimell1)+1];
char off__TFormHtmlEdit__Sulje1[(int)(long)&(((TFormHtmlEdit*)0)->Sulje1)+1];
char off__TFormHtmlEdit__RGLuonne[(int)(long)&(((TFormHtmlEdit*)0)->RGLuonne)+1];
char off__TFormHtmlEdit__Merkist1[(int)(long)&(((TFormHtmlEdit*)0)->Merkist1)+1];
char off__TFormHtmlEdit__UTF81[(int)(long)&(((TFormHtmlEdit*)0)->UTF81)+1];
char off__TFormHtmlEdit__ISO885911[(int)(long)&(((TFormHtmlEdit*)0)->ISO885911)+1];
char off__TFormHtmlEdit__WebBrowser1[(int)(long)&(((TFormHtmlEdit*)0)->WebBrowser1)+1];
char off__TFormHtmlEdit__OpenDialog1[(int)(long)&(((TFormHtmlEdit*)0)->OpenDialog1)+1];
char off__TFormHtmlEdit__Luetiedosto1[(int)(long)&(((TFormHtmlEdit*)0)->Luetiedosto1)+1];
char off__TFormHtmlEdit__SaveDialog1[(int)(long)&(((TFormHtmlEdit*)0)->SaveDialog1)+1];
char off__TFormHtmlEdit__Button1[(int)(long)&(((TFormHtmlEdit*)0)->Button1)+1];
char off__TFormHtmlEdit__Button2[(int)(long)&(((TFormHtmlEdit*)0)->Button2)+1];
char off__TFormHtmlEdit__FileName[(int)(long)&(((TFormHtmlEdit*)0)->FileName)+1];
char off__TFormHtmlEdit__CurrentDir[(int)(long)&(((TFormHtmlEdit*)0)->CurrentDir)+1];
