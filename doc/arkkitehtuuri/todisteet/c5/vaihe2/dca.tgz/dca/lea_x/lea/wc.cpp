#include <stdio.h>
#include <wchar.h>
#include <wctype.h>
#include <string.h>
int main(){
 wchar_t w=(wchar_t)-1; wint_t we=WEOF; wchar_t c=(wchar_t)WEOF;
 printf("sizeof wint_t=%d WEOF=%X (wchar_t)-1>0:%d  (wchar_t)WEOF==WEOF:%d  (int)(wchar_t)0xFFE4=%d\n",(int)sizeof(wint_t),(unsigned)we,w>0,c==WEOF,(int)(wchar_t)0xFFE4);
 printf("wcscmp(L\"\xE4\",L\"z\")=%d wcscmp(L\"\xC4\",L\"\xE4\")=%d strcmp(\"\xE4\",\"z\")=%d wcsicmp(a-uml,A-uml)=%d _wcsicmp=%d\n", wcscmp(L"\xE4",L"z")<0?-1:1, wcscmp(L"\xC4",L"\xE4")<0?-1:1, strcmp("\xE4","z")<0?-1:1, _wcsicmp(L"\xE4",L"\xC4"), _wcsicmp(L"\xE4",L"\xE4"));
 wchar_t b[8]; wcsncpy(b,L"ab",6); printf("wcsncpy pads: b[2..5]=%d %d %d %d\n",b[2],b[3],b[4],b[5]);
 return 0;}
