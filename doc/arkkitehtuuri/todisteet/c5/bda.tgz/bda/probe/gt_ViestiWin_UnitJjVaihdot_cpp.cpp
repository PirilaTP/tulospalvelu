#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitJjVaihdot.cpp"
char sz__TFormJjVaihdot[(int)sizeof(TFormJjVaihdot)];
