import sys, os, importlib.util
spec = importlib.util.spec_from_file_location('v', sys.argv[1]); v = importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
for d1, d2 in [(sys.argv[2], sys.argv[3])]:
    for f in sorted(os.listdir(d1)):
        a = [(k,b) for k,b in v.records(os.path.join(d1,f)) if k=='COMENT_FB']
        b = [(k,b) for k,b in v.records(os.path.join(d2,f)) if k=='COMENT_FB']
        sa = sorted(set(x[1][2] for x in a if x not in b)); sb = sorted(set(x[1][2] for x in b if x not in a))
        print(f, 'FB subtypes differing:', sa, sb)
