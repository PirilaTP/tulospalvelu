#include <stdio.h>
#include "kk.h"
#pragma hdrstop
int after2(char c){ return c < 0; }
int main(){ char c=(char)0xE4; printf("after2=%d\n", after2(c)); return 0; }
