#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitEditDialog.cpp"
char sz__TEditDialog[(int)sizeof(TEditDialog)];
