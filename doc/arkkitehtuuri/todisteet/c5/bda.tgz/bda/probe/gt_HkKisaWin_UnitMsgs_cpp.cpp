#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitMsgs.cpp"
char sz__TFormMsgs[(int)sizeof(TFormMsgs)];
