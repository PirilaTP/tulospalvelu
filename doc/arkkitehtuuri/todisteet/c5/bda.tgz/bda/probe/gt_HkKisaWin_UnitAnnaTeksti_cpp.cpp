#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitAnnaTeksti.cpp"
char sz__TFormAnnaTeksti[(int)sizeof(TFormAnnaTeksti)];
