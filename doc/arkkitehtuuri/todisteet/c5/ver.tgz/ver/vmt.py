import re,glob,sys,collections,os
d=sys.argv[1]
r=re.compile(r"Name: *\d+: '(\w+)::'\s+virtual\(_DATA\)")
m=collections.defaultdict(list)
for f in glob.glob(d+'/*.txt'):
    for l in open(f,errors='replace'):
        x=r.search(l)
        if x: m[x.group(1)].append(os.path.basename(f)[:-4])
for k,v in sorted(m.items()):
    if len(v)>1 or len(sys.argv)>2: print(k,len(v),' '.join(v))
