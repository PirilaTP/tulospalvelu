#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitVaPisteet.cpp"
char off__TFormVaToisto__EdtSarja[(int)(long)&(((TFormVaToisto*)0)->EdtSarja)+1];
char off__TFormVaToisto__Label1[(int)(long)&(((TFormVaToisto*)0)->Label1)+1];
char off__TFormVaToisto__Label2[(int)(long)&(((TFormVaToisto*)0)->Label2)+1];
char off__TFormVaToisto__EdtVali[(int)(long)&(((TFormVaToisto*)0)->EdtVali)+1];
char off__TFormVaToisto__Label3[(int)(long)&(((TFormVaToisto*)0)->Label3)+1];
char off__TFormVaToisto__EdtMtk1[(int)(long)&(((TFormVaToisto*)0)->EdtMtk1)+1];
char off__TFormVaToisto__Label4[(int)(long)&(((TFormVaToisto*)0)->Label4)+1];
char off__TFormVaToisto__EdtEnspiste[(int)(long)&(((TFormVaToisto*)0)->EdtEnspiste)+1];
char off__TFormVaToisto__Label5[(int)(long)&(((TFormVaToisto*)0)->Label5)+1];
char off__TFormVaToisto__EdtLkm[(int)(long)&(((TFormVaToisto*)0)->EdtLkm)+1];
char off__TFormVaToisto__Label6[(int)(long)&(((TFormVaToisto*)0)->Label6)+1];
char off__TFormVaToisto__EdtAskel[(int)(long)&(((TFormVaToisto*)0)->EdtAskel)+1];
char off__TFormVaToisto__Label7[(int)(long)&(((TFormVaToisto*)0)->Label7)+1];
char off__TFormVaToisto__CBJulkisuus[(int)(long)&(((TFormVaToisto*)0)->CBJulkisuus)+1];
char off__TFormVaToisto__Button1[(int)(long)&(((TFormVaToisto*)0)->Button1)+1];
char off__TFormVaToisto__Button2[(int)(long)&(((TFormVaToisto*)0)->Button2)+1];
char off__TFormVaToisto__Label8[(int)(long)&(((TFormVaToisto*)0)->Label8)+1];
char off__TFormVaToisto__CBtapa[(int)(long)&(((TFormVaToisto*)0)->CBtapa)+1];
char off__TFormVaToisto__RGdes[(int)(long)&(((TFormVaToisto*)0)->RGdes)+1];
