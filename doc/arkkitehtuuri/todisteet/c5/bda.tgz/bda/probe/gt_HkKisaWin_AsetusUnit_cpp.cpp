#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/AsetusUnit.cpp"
char sz__IV_KEY[(int)sizeof(IV_KEY)];
char sz__comparamtp[(int)sizeof(comparamtp)];
char sz__ipparamtp[(int)sizeof(ipparamtp)];
char sz__sendtestparamtp[(int)sizeof(sendtestparamtp)];
