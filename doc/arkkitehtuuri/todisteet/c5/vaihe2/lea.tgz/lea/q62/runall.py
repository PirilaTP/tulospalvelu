# usage: runall.py LOG OUTDIR : compile every unit of the log with -S, once with the recorded -H=pch -H (sequential, shared pch), once without -H
import sys,re,os,subprocess,collections
BS=chr(92);Q=chr(34)
log,out=sys.argv[1],os.path.abspath(sys.argv[2])
cwd=r'C:\dev\tulospalvelu\TPsource\V52\RADStudio10'
bcc=r'c:\program files (x86)\embarcadero\studio\37.0\bin\bcc32.exe'
blocks=[];cur=None
for l in open(log,encoding='utf-8-sig').read().split(chr(10)):
    if l.startswith('bcc32 command line for'):
        cur=[l.split(Q)[1],[]];blocks.append(cur)
    elif cur and l.startswith(' '): cur[1].append(l.strip())
    else: cur=None
def join(ls):
    s=''
    for x in ls: s+= x if (s=='' or s.endswith(';')) else ' '+x
    return s
os.makedirs(out+'/pch',exist_ok=True);os.makedirs(out+'/nopch',exist_ok=True)
pch=out+'/shared.pch'
res=[]
for i,(src,ls) in enumerate(blocks):
    s=join(ls).split('bcc32.exe',1)[1]
    s=re.sub(r'-o\S+','',s); s=re.sub(r'-n'+re.escape('.'+BS+'Win32'+BS+'Release'),'',s)
    s=re.sub(r'-H=\S+','',s); s=re.sub(r'\s-H\s',' ',s+' ')
    s=re.sub(r'\s\S*\.cpp\s*$',' ',s).strip()
    name='%03d_%s'%(i,os.path.basename(src.replace(BS,'/')))
    for mode in ('pch','nopch'):
        a=s+' -S -o'+out+'/'+mode+'/'+name+'.asm'
        if mode=='pch': a+=' -H='+pch+' -H'
        a+=' '+src
        rf=out+'/'+mode+'/'+name+'.rsp'; open(rf,'w').write(a)
        r=subprocess.run([bcc,'@'+rf],cwd=cwd,capture_output=True)
        open(out+'/'+mode+'/'+name+'.txt','wb').write(r.stdout)
        res.append((name,mode,r.returncode))
print('done',len(blocks),sum(1 for r in res if r[2]!=0),'nonzero rc')
