import json,glob,os,re,subprocess,sys,collections,csv
from multiprocessing import Pool
S=os.path.dirname(os.path.abspath(__file__))
ROOT=r'C:\dev\tulospalvelu\TPsource\V52'
WORK=ROOT+r'\RADStudio10'
sys.path.insert(0,S)
import gt
R=gt.R;CM=gt.CM
gtres=json.load(open(S+'/gt_res.json'))
sz=collections.defaultdict(lambda: collections.defaultdict(set))
for proj,src,tag,out,err in gtres:
    for c,v in out.items(): sz[(proj,c)][tag].add(v)
diffc={k for k,d in sz.items() if len({x for s in d.values() for x in s})>1}
SKIP=re.compile(r'\(|\)|typedef|friend|using|static|extern|enum |__property|__fastcall|return|^\s*#|^\s*//|__published:|public:|private:|protected:|virtual|\bclass\b|\bstruct\b')
MEM=re.compile(r'^\s*([A-Za-z_][\w:<>,\s\*&]*?)[\s\*&]+([A-Za-z_]\w*)\s*(\[[^\]]*\])?\s*;\s*(//.*)?$')
def members(path,line):
    t=open(os.path.join(ROOT,path),encoding='cp1252',errors='replace').read().replace('\r','').split('\n')
    depth=0;started=False;out=[]
    for i in range(line-1,len(t)):
        l=t[i]
        if '{' in l: started=True
        if started and depth==1 and not SKIP.search(l):
            m=MEM.match(l)
            if m: out.append(m.group(2))
        depth+=l.count('{')-l.count('}')
        if started and depth<=0: break
    return out
def job(a):
    proj,src,items,tag=a   # items: list of (cls,[members])
    cmd=CM[proj][src];cmd=cmd[:-len(src)]
    cmd=re.sub(r' -o\S+','',cmd);cmd=re.sub(r' -n\S+','',cmd);cmd=re.sub(r' -H=\S+',' ',cmd);cmd=re.sub(r' -H(c)? ',' ',cmd)
    cmd=cmd.replace(' -c ',' -S ')
    absrc=os.path.normpath(os.path.join(WORK,src)).replace(chr(92),'/')
    base=re.sub(r'\W','_',proj+'_'+os.path.basename(src)+tag)
    pf=os.path.join(S,'probe','g2_%s.cpp'%base);asm=os.path.join(S,'probe','g2_%s.asm'%base)
    body='#define private public\n#define protected public\n#include "%s"\n'%absrc
    for c,ms in items:
        for m in ms: body+='char off__%s__%s[(int)(long)&(((%s*)0)->%s)+1];\n'%(c,m,c,m)
    open(pf,'w').write(body)
    exe,rest=cmd.split('.exe ',1)
    p=subprocess.run('"'+exe+'.exe" '+rest+' -o'+asm+' '+pf,cwd=WORK,capture_output=True,text=True,encoding='cp1252',errors='replace')
    out={}
    if os.path.exists(asm):
        t=open(asm,encoding='latin1').read()
        for m in re.finditer(r'^_off__(\w+?)__(\w+)\s+label\s+byte\s*\n\s*db\s+(\d+)\s+dup',t,re.M): out[(m.group(1),m.group(2))]=int(m.group(3))-1
        os.remove(asm)
    err=[l for l in (p.stdout+p.stderr).splitlines() if 'Error' in l][:3]
    return (proj,src,tag,[[k[0],k[1],v] for k,v in out.items()],err)
if __name__=='__main__':
    jobs=[];hdr={}
    for prog in ['HkKisaWin','ViestiWin']:
        D=collections.defaultdict(lambda: collections.defaultdict(list))
        for r in R:
            if r['proj']!=prog: continue
            for d in r['defs']:
                if d[2]=='class' or d[2]=='struct':
                    D[(d[3].replace('(typedef)',''),d[0],d[1])][d[4]['a']].append(r['src'])
        per=collections.defaultdict(list)
        for (nm,f,l),v in D.items():
            if (prog,nm) in diffc and len(v)>1:
                ms=members(f,l);hdr[(prog,nm)]=(f,l,ms)
                for a,tus in v.items(): per[(prog,tus[0],'a%d'%a)].append((nm,ms))
        for (p,src,tag),items in per.items(): jobs.append((p,src,items,tag))
    print(len(jobs),'jobs',flush=True)
    res=[]
    with Pool(6) as pool:
        for r in pool.imap_unordered(job,jobs):
            res.append(r);print(r[0],r[1],r[2],len(r[3]),r[4],flush=True)
    json.dump({'res':res,'hdr':{'%s|%s'%k:v for k,v in hdr.items()}},open(S+'/gt2_res.json','w'))
