// Q62a probe: same include sequence as cbHk/UnitEmitMuutokset.cpp, then report the effective -K / -a state.
#include <vcl.h>
#pragma hdrstop
#include "UnitEmitMuutokset.h"
#include "UnitEmit.h"
#include "HkDeclare.h"
struct ProbeS { char a; int b; };
int g_char_is_unsigned = ((char)-1 > 0);
int g_sizeof_probe = sizeof(ProbeS);
int g_sizeof_TextFl = sizeof(TextFl);
int g_sizeof_kilptietue = sizeof(kilptietue);
int g_sizeof_TFormEmitMuutokset = sizeof(TFormEmitMuutokset);
