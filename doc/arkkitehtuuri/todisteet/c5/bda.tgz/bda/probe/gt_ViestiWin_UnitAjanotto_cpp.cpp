#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitAjanotto.cpp"
char sz__TFormNappain[(int)sizeof(TFormNappain)];
