import re,os,sys,subprocess,collections,glob
ROOT='C:/dev/tulospalvelu/TPsource/V52'
lines=subprocess.run([sys.executable,'-I',sys.argv[1]+'/ver/states.py',sys.argv[1]],capture_output=True,text=True).stdout.splitlines()
allcpp={}
for f in glob.glob(ROOT+'/**/*.cpp',recursive=True): allcpp.setdefault(os.path.basename(f),[]).append(f)
for l in lines:
    prog,cls,hdr,rest=l.split(' ',3)
    if not cls.startswith('T'): continue
    own=[];others=[]
    for part in rest.split(' | '):
        a,tus=part.split(': ');tus=tus.split(',')
        (own if a=='a8' else others).extend(tus)
    h=open(os.path.join(ROOT,hdr),encoding='cp1252',errors='replace').read()
    ptrs=set(re.findall(r'extern\s+PACKAGE\s+'+cls+r'\s*\*\s*(\w+)',h))
    acc=collections.defaultdict(set)
    for tu in others:
        sub='ViestiWin' if prog=='ViestiWin' else 'cbHk'
        cands=allcpp.get(tu,[])
        # prefer proper dir
        for f in [c.replace(chr(92),'/') for c in cands]:
            if prog=='HkKisaWin' and ('ViestiWin' in f or '/Juk/' in f): continue
            if prog=='ViestiWin' and ('cbHk' in f or '/Hk/' in f): continue
            t=open(f,encoding='cp1252',errors='replace').read()
            locs=set(re.findall(r'\b'+cls+r'\s*\*\s*(\w+)',t))|ptrs
            for p in locs:
                for m in re.finditer(r'\b'+p+r'\s*->\s*(\w+)',t): acc[m.group(1)].add(os.path.basename(f))
            if re.search(r'new\s+'+cls+r'\b|sizeof\s*\(\s*'+cls,t): acc['<new/sizeof>'].add(os.path.basename(f))
    print(prog,cls,'ptrs=',sorted(ptrs),'->',dict((k,sorted(v)) for k,v in acc.items()))
