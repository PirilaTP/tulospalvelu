#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitSelect3.cpp"
char sz__TFormSelect3[(int)sizeof(TFormSelect3)];
char sz__TMyMessage2[(int)sizeof(TMyMessage2)];
