import re,sys,os
root=sys.argv[1]; exes=sys.argv[2:]
data={os.path.basename(e):open(e,'rb').read() for e in exes}
for p in ['Hk/HkAjat.cpp','Juk/vajat.cpp','Tp/TpLaitteet.cpp']:
    t=open(os.path.join(root,p),encoding='utf-8').read().split('\n')
    for i,l in enumerate(t,1):
        BS=chr(92); RX='(L?)"((?:[^"'+BS+BS+']|'+BS+BS+'.)*)"'
        for m in re.finditer(RX, l.split('//')[0] if '"' not in l.split('//')[0] else l):
            s=m.group(2)
            if not any(ord(c)>127 for c in s): continue
            k=next(j for j,c in enumerate(s) if ord(c)>127)
            pre=s[max(0,k-12):k].replace('\t','\t').replace('\n','\n')
            if len(pre)<4: pre=s[:k]
            row=[]
            for n,d in data.items():
                if m.group(1)=='L':
                    w=pre.encode('utf-16-le'); idx=d.find(w)
                    if idx<0: row.append('%s:-'%n); continue
                    nxt=int.from_bytes(d[idx+len(w):idx+len(w)+2],'little')
                    row.append('%s:%04X'%(n,nxt))
                else:
                    w=pre.encode('latin-1'); idx=d.find(w)
                    if idx<0: row.append('%s:-'%n); continue
                    row.append('%s:%02X'%(n,d[idx+len(w)]))
            print('%s:%d %s %r'%(p,i,m.group(1) or 'N',pre[-10:]),' '.join(row))
