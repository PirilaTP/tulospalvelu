#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitOhjtiedot.cpp"
char sz__TFormOhjtiedot[(int)sizeof(TFormOhjtiedot)];
