#include <stdio.h>
#include <string.h>
#include <locale.h>
#include <ctype.h>
#include <wctype.h>
static void show(const char *tag){ printf("%-28s toupper(E4)=%02X tolower(C4)=%02X isalpha(E4)=%d  towupper(E4)=%04X towlower(C4)=%04X iswalpha(E4)=%d towupper(FF)=%04X\n",tag,(unsigned)toupper(0xE4),(unsigned)tolower(0xC4),isalpha(0xE4)!=0,(unsigned)towupper(0xE4),(unsigned)towlower(0xC4),iswalpha(0xE4)!=0,(unsigned)towupper(0xFF)); }
int main(){
 show("startup (no setlocale)");
 const char *names[]={"","C","fi-FI","fi_FI","Finnish","Finnish_Finland.1252",".1252",".ACP","fi",0};
 for(int i=0;names[i];i++){ char *r=setlocale(LC_ALL,names[i]); char t[80]; sprintf(t,"LC_ALL '%s'->%s",names[i],r?"ok":"NULL"); show(t); }
 wchar_t *w=_wsetlocale(LC_ALL,L"Finnish_Finland.1252"); printf("_wsetlocale ret %s\n",w?"ok":"NULL"); show("after _wsetlocale Finnish");
 w=_wsetlocale(LC_CTYPE,L"fi-FI"); printf("_wsetlocale CTYPE fi-FI ret %s\n",w?"ok":"NULL"); show("after _wsetlocale fi-FI");
 return 0;}
