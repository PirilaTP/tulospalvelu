import sys, os, shutil
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'probe.py')).read())
S = srccopy; ue = os.path.join(S,'cbHk','UnitEmit.cpp')
out = os.path.abspath(outdir); shutil.rmtree(out, ignore_errors=True)
U = ('HkKisaWin', r'..\cbHk\UnitEmit.cpp')
A = compile(*U, os.path.join(out,'A'))
tests = {
 'no_resource': lambda L: [l.replace(b'#pragma resource "*.dfm"', b'//#pragma resource "*.dfm"') for l in L],
 'no_smartinit': lambda L: [l.replace(b'#pragma package(smart_init)', b'//#pragma package(smart_init)') for l in L],
 'add_link': lambda L: L[:44] + [b'#pragma link "c5probe.obj"'] + L[44:],
 'add_commentlib': lambda L: L[:44] + [b'#pragma comment(lib, "c5probe.lib")'] + L[44:],
}
for n, fn in tests.items():
    o = edit(ue, fn)
    try: X = compile(*U, os.path.join(out,n))
    finally: open(ue,'wb').write(o)
    print(n, v.compare(A,X) or 'EQUAL')
