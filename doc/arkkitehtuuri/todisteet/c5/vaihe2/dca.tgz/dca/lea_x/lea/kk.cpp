#include <stdio.h>
inline int before(char c){ return c < 0; }
#include "kk.h"
inline int after(char c){ return c < 0; }
struct S { char c; int i; };
int main(){ char c=(char)0xE4; printf("before(E4)=%d after(E4)=%d (wchar_t)c=%04X sizeof(S)=%d\n", before(c), after(c), (unsigned)(wchar_t)c, (int)sizeof(S)); return 0; }
