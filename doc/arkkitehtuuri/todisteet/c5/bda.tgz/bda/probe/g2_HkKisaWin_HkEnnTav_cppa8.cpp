#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/Hk/HkEnnTav.cpp"
char off__sendtestparamtp__inSendCopy[(int)(long)&(((sendtestparamtp*)0)->inSendCopy)+1];
char off__sendtestparamtp__valilaji[(int)(long)&(((sendtestparamtp*)0)->valilaji)+1];
char off__sendtestparamtp__aloituslaji[(int)(long)&(((sendtestparamtp*)0)->aloituslaji)+1];
char off__sendtestparamtp__cn[(int)(long)&(((sendtestparamtp*)0)->cn)+1];
char off__sendtestparamtp__Jono[(int)(long)&(((sendtestparamtp*)0)->Jono)+1];
char off__sendtestparamtp__NJono[(int)(long)&(((sendtestparamtp*)0)->NJono)+1];
char off__sendtestparamtp__ValiKerroin[(int)(long)&(((sendtestparamtp*)0)->ValiKerroin)+1];
char off__sendtestparamtp__ens[(int)(long)&(((sendtestparamtp*)0)->ens)+1];
char off__sendtestparamtp__viim[(int)(long)&(((sendtestparamtp*)0)->viim)+1];
char off__sendtestparamtp__t_alku[(int)(long)&(((sendtestparamtp*)0)->t_alku)+1];
char off__sendtestparamtp__t_vert[(int)(long)&(((sendtestparamtp*)0)->t_vert)+1];
char off__sendtestparamtp__t_aloitus[(int)(long)&(((sendtestparamtp*)0)->t_aloitus)+1];
char off__sendtestparamtp__RecLen[(int)(long)&(((sendtestparamtp*)0)->RecLen)+1];
char off__sendtestparamtp__LahRivi[(int)(long)&(((sendtestparamtp*)0)->LahRivi)+1];
char off__sendtestparamtp__ComFileName[(int)(long)&(((sendtestparamtp*)0)->ComFileName)+1];
char off__sendtestparamtp__ComFile[(int)(long)&(((sendtestparamtp*)0)->ComFile)+1];
char off__comparamtp__baud[(int)(long)&(((comparamtp*)0)->baud)+1];
char off__comparamtp__bits[(int)(long)&(((comparamtp*)0)->bits)+1];
char off__comparamtp__sbits[(int)(long)&(((comparamtp*)0)->sbits)+1];
char off__comparamtp__parity[(int)(long)&(((comparamtp*)0)->parity)+1];
