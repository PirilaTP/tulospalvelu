#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitAjanotto.cpp"
char sz__TFormNappain[(int)sizeof(TFormNappain)];
