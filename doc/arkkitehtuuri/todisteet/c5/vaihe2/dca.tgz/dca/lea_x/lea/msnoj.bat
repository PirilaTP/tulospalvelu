@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars32.bat" >nul 2>&1
cd /d "%~dp0"
cl /nologo /EHsc /MT /W1 /Fe:kk5-msvc-noJ.exe /Fo:kk5-msvc-noJ.obj kk5.cpp > kk5-msvc-noJ.build.txt 2>&1
