#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitJoukkueet.cpp"
char sz__TFormSuodatus[(int)sizeof(TFormSuodatus)];
