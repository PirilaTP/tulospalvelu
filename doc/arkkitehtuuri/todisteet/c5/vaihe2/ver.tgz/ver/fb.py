import sys, collections, importlib.util
spec = importlib.util.spec_from_file_location('v', sys.argv[1]); v = importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
c = collections.Counter(); ex = {}
for f in sys.argv[2:]:
    for k, b in v.records(f):
        if k in ('COMENT_FB','COMENT_E9','COMENT_E8'):
            key = (k, b[0], b[2] if len(b)>2 else None)
            c[key] += 1
            ex.setdefault(key, (f[-40:], b[:90]))
for k in sorted(c, key=str): print(k, c[k], ex[k])
