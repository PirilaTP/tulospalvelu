import re,os,sys,glob,collections
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
out=sys.argv[1]; root=sys.argv[2]
# repo type names
names=set()
for dp,dn,fn in os.walk(root):
    if 'Tests' in dp or '.vs' in dp: continue
    for f in fn:
        if f.endswith(('.h','.cpp')):
            t=open(os.path.join(dp,f),encoding='cp1252',errors='replace').read()
            names|=set(re.findall(r'^\s*}\s*([A-Za-z_]\w*)\s*;',t,re.M))
            names|=set(re.findall(r'^\s*(?:class|struct)\s+([A-Za-z_]\w*)\s*(?::[^{;]*)?\{',t,re.M))
H=re.compile(r'^class (.+?)\tsize\((\d+)\):')
W=re.compile(r'[^ \t\n|][^\n|]*?\(\d+\): (warning|note|error) [^\n]*\n')
res={}
for prog in ['HkMaali','JukMaali','JukLuenta']:
    for f in glob.glob(os.path.join(out,prog,'*.txt')):
        t=W.sub('',open(f,encoding='cp1252',errors='replace').read()); L=t.splitlines()
        for i,l in enumerate(L):
            m=H.match(l)
            if not m: continue
            n=m.group(1)
            j=i+2;body=[]
            while j<len(L) and L[j].strip()!='+---': body.append(L[j]);j+=1
            if any('<alignment member>' in b for b in body):
                key=(prog,n)
                if n in names or (n=='<unnamed-tag>'):
                    mem=[re.sub(r'\s+',' ',b.split('|',1)[1].strip()) for b in body if '|' in b and '<alignment' not in b]
                    res.setdefault(key if n!='<unnamed-tag>' else (prog,'anon:'+','.join(mem[:4])),(m.group(2),mem[:8]))
for k in sorted(res): print(k[0],k[1],'size',res[k][0],res[k][1])
