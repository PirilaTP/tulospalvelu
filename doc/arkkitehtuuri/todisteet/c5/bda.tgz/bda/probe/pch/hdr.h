#include <stdio.h>
#pragma option -K -a1
struct HS {char c; int i;};
