#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/VertAikaUnit.cpp"
char off__TVertAikaFrm__OKBtn[(int)(long)&(((TVertAikaFrm*)0)->OKBtn)+1];
char off__TVertAikaFrm__PeruutaBtn[(int)(long)&(((TVertAikaFrm*)0)->PeruutaBtn)+1];
char off__TVertAikaFrm__GroupBox1[(int)(long)&(((TVertAikaFrm*)0)->GroupBox1)+1];
char off__TVertAikaFrm__Label6[(int)(long)&(((TVertAikaFrm*)0)->Label6)+1];
char off__TVertAikaFrm__EdMaxLkm[(int)(long)&(((TVertAikaFrm*)0)->EdMaxLkm)+1];
char off__TVertAikaFrm__Label7[(int)(long)&(((TVertAikaFrm*)0)->Label7)+1];
char off__TVertAikaFrm__Label8[(int)(long)&(((TVertAikaFrm*)0)->Label8)+1];
char off__TVertAikaFrm__EdMaxPros[(int)(long)&(((TVertAikaFrm*)0)->EdMaxPros)+1];
char off__TVertAikaFrm__Label9[(int)(long)&(((TVertAikaFrm*)0)->Label9)+1];
char off__TVertAikaFrm__Label10[(int)(long)&(((TVertAikaFrm*)0)->Label10)+1];
char off__TVertAikaFrm__SeurLstVal[(int)(long)&(((TVertAikaFrm*)0)->SeurLstVal)+1];
char off__TVertAikaFrm__SeurGrVal[(int)(long)&(((TVertAikaFrm*)0)->SeurGrVal)+1];
char off__TVertAikaFrm__TlsLuetVal[(int)(long)&(((TVertAikaFrm*)0)->TlsLuetVal)+1];
char off__TVertAikaFrm__MainMenu1[(int)(long)&(((TVertAikaFrm*)0)->MainMenu1)+1];
char off__TVertAikaFrm__Nytt1[(int)(long)&(((TVertAikaFrm*)0)->Nytt1)+1];
char off__TVertAikaFrm__Luekorostustiedot1[(int)(long)&(((TVertAikaFrm*)0)->Luekorostustiedot1)+1];
char off__TVertAikaFrm__Muitaasetuksia1[(int)(long)&(((TVertAikaFrm*)0)->Muitaasetuksia1)+1];
char off__TVertAikaFrm__Kuuluttajarajoitukset1[(int)(long)&(((TVertAikaFrm*)0)->Kuuluttajarajoitukset1)+1];
char off__TVertAikaFrm__Maksimikesto1[(int)(long)&(((TVertAikaFrm*)0)->Maksimikesto1)+1];
