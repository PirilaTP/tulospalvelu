#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitOhjtiedot.cpp"
char off__TFormOhjtiedot__Label1[(int)(long)&(((TFormOhjtiedot*)0)->Label1)+1];
char off__TFormOhjtiedot__Label2[(int)(long)&(((TFormOhjtiedot*)0)->Label2)+1];
char off__TFormOhjtiedot__Label3[(int)(long)&(((TFormOhjtiedot*)0)->Label3)+1];
char off__TFormOhjtiedot__Label4[(int)(long)&(((TFormOhjtiedot*)0)->Label4)+1];
char off__TFormOhjtiedot__Label5[(int)(long)&(((TFormOhjtiedot*)0)->Label5)+1];
char off__TFormOhjtiedot__Memo1[(int)(long)&(((TFormOhjtiedot*)0)->Memo1)+1];
char off__TFormOhjtiedot__Label6[(int)(long)&(((TFormOhjtiedot*)0)->Label6)+1];
