#include <stdio.h>
#include <wchar.h>
#include <string.h>
int main(){
  wchar_t b[16]; for(int i=0;i<16;i++) b[i]=0x5555;
  int r=swprintf(b, 4, L"%s", L"abcdefgh");
  printf("swprintf(b,4,\"abcdefgh\") ret=%d b[0..5]=",r); for(int i=0;i<6;i++) printf(" %04X",(unsigned)b[i]); printf("\n");
  for(int i=0;i<16;i++) b[i]=0x5555;
  r=swprintf(b, 4, L"%s", L"abc");
  printf("swprintf(b,4,\"abc\") ret=%d b[0..5]=",r); for(int i=0;i<6;i++) printf(" %04X",(unsigned)b[i]); printf("\n");
  return 0;}
