#include "hdr.h"
#pragma hdrstop
struct BS {char c; int i;};
char sz_A_HS[(int)sizeof(HS)];
char sz_A_BS[(int)sizeof(BS)];
char sgn_A[((char)-1<0)?1:2];
