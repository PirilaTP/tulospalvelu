#ifndef _CONSOLE
#define _CONSOLE
#endif
#include <stdlib.h>
#include <ctype.h>
#include <tputil.h>
struct PS_after {char c; int i;};
char sz_PS_after[(int)sizeof(PS_after)];
char sz_dbindex[(int)sizeof(dbindex)];
char sz_ipparamtp[(int)sizeof(ipparamtp)];
