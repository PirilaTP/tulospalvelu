import re,sys,os,difflib
D=chr(36); HASH=re.compile('['+D+'][a-z]{8}'); ECT=re.compile('[_][$][A-Z]{3,8}[$]'); LAB=re.compile('@[0-9]+')
d=sys.argv[1]; want=sys.argv[2]; show=int(sys.argv[3]) if len(sys.argv)>3 else 12
res=[]
for f in sorted(os.listdir(d)):
    if not f.endswith('.asm'): continue
    L=open(os.path.join(d,f),encoding='cp1252',errors='replace').read().split(chr(10))
    for i,l in enumerate(L):
        m=re.match(r'^(\S+)\s+segment virtual',l)
        if m and m.group(1)==want:
            name=m.group(1);j=i+1;body=[]
            while not re.match(r'^%s\s+ends'%re.escape(name),L[j]):
                x=L[j].rstrip()
                if x.strip() and not x.strip().startswith(('?debug',';')):
                    x=HASH.sub('H',x);x=ECT.sub('_ECT_',x);x=re.sub(r'[?]live[0-9]+@[0-9]+','?live',x);x=LAB.sub('@L',x);x=re.sub('s@[+][0-9]+','s@N',x);body.append(x)
                j+=1
            if body: res.append((f[:3],body))
groups={}
for u,b in res: groups.setdefault('\n'.join(b),[]).append(u)
print(want,'units',len(res),'distinct bodies',len(groups))
bl=list(groups.items())
for k,(b,us) in enumerate(bl): print(' body',k,len(b.split(chr(10))),'lines; units',us[:6],len(us))
for k in range(1,len(bl)):
    dd=[x for x in difflib.unified_diff(bl[0][0].split(chr(10)),bl[k][0].split(chr(10)),lineterm='',n=0) if not x.startswith(('---','+++','@@'))]
    print(' diff body0 vs body%d:'%k)
    for x in dd[:show]: print('    ',x[:120])
