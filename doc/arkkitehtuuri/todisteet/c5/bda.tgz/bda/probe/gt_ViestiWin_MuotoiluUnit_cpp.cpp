#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/MuotoiluUnit.cpp"
char sz__TFormMuotoilu[(int)sizeof(TFormMuotoilu)];
