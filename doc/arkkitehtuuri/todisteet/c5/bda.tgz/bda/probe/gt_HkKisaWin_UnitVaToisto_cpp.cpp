#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitVaToisto.cpp"
char sz__TFormVaToisto[(int)sizeof(TFormVaToisto)];
