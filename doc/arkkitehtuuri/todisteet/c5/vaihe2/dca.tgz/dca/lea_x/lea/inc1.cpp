#include <stdio.h>
#include "inc_bom.h"
int main(){ printf("bom-hdr W:%04X %04X N:%02X %02X\n",hw[0],hw[1],(unsigned char)hn[0],(unsigned char)hn[1]); return 0;}
