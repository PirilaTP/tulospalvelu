#include <windows.h>
#include <stdio.h>
#include <wchar.h>
#include <process.h>
static HANDLE e1,e2;
static unsigned __stdcall thr(void*){ wchar_t b[]=L"X1 X2 X3"; WaitForSingleObject(e1,INFINITE); wchar_t *p=wcstok(b,L" "); printf("B first=%ls\n",p); SetEvent(e2); return 0; }
int main(){
  e1=CreateEvent(0,0,0,0); e2=CreateEvent(0,0,0,0);
  HANDLE h=(HANDLE)_beginthreadex(0,0,thr,0,0,0);
  wchar_t a[]=L"A1 A2 A3"; wchar_t *p=wcstok(a,L" "); printf("A first=%ls\n",p);
  SetEvent(e1); WaitForSingleObject(e2,INFINITE);
  p=wcstok(NULL,L" "); printf("A second=%ls (expected A2 if per-thread)\n",p? p:L"(null)");
  WaitForSingleObject(h,INFINITE); return 0; }
