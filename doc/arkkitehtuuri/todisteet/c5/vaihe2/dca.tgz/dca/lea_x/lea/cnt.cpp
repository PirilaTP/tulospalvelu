#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include <wctype.h>
#include <ctype.h>
#include <stdlib.h>
static void dumpw(const char *tag, const wchar_t *b){ printf("%-34s W:", tag); for(int i=0;i<12&&b[i];i++) printf(" %04X",(unsigned)b[i]); printf("\n"); }
int main(){
 wchar_t b[64]; int r;
 memset(b,0x55,sizeof b); r=swprintf(b,6,L"_%04X",0xE4); dumpw("swprintf(b,6,fmt,..) count form",b); printf("  ret=%d\n",r);
 memset(b,0x55,sizeof b); r=swprintf(b,4,L"abcdefgh"); printf("swprintf(b,4,\"abcdefgh\") ret=%d b[3]=%04X b[4]=%04X\n",r,b[3],b[4]);
 memset(b,0x55,sizeof b); r=swprintf(b,L"%d",12); dumpw("swprintf(b,fmt,..) no-count",b); printf("  ret=%d\n",r);
 memset(b,0x55,sizeof b); r=swprintf(b,L"abc",12); dumpw("swprintf(b,\"abc\",12)",b); printf("  ret=%d\n",r);
 printf("iswalnum(E4)=%d iswalnum(C4)=%d iswalpha(E4)=%d iswdigit(0x0664)=%d iswspace(0xA0)=%d iswupper(C4)=%d iswprint(E4)=%d\n",iswalnum(0xE4)!=0,iswalnum(0xC4)!=0,iswalpha(0xE4)!=0,iswdigit(0x664)!=0,iswspace(0xA0)!=0,iswupper(0xC4)!=0,iswprint(0xE4)!=0);
 printf("isspace(0xA0)=%d isspace(-96)=%d\n",isspace(0xA0)!=0,isspace(-96)!=0);
 return 0;}
