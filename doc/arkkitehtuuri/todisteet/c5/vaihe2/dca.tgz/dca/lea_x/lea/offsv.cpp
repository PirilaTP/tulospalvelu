#include "VDeclare.h"
#include <stddef.h>
#include <stdio.h>
#define O(T,m) printf("  %-10s.%-10s off=%3d size=%3d\n",#T,#m,(int)offsetof(T,m),(int)sizeof(((T*)0)->m))
int MAINF(){
 printf("sizeof aikatp=%d emittp=%d emitvatp=%d combufrec=%d\n",(int)sizeof(aikatp),(int)sizeof(emittp),(int)sizeof(emitvatp),(int)sizeof(combufrec));
 O(aikatp,t);O(aikatp,date);O(aikatp,kno);O(aikatp,osuus);O(aikatp,piste);O(aikatp,badge);O(aikatp,kanava);O(aikatp,lahde);O(aikatp,jono);O(aikatp,status);
 O(emittp,package);O(emittp,badge);O(emittp,maali);O(emittp,time);O(emittp,ctrlcode);O(emittp,ctrltime);O(emittp,sc);O(emittp,kilpno);O(emittp,osuus);O(emittp,kirjaus);
 O(emitvatp,kilpno);O(emitvatp,tulos);O(emitvatp,rata);O(emitvatp,rastit);
 O(combufrec,lahetetty);O(combufrec,portti);O(combufrec,so);O(combufrec,pkgclass);O(combufrec,len);O(combufrec,checksum);O(combufrec,d);
 return 0;}
