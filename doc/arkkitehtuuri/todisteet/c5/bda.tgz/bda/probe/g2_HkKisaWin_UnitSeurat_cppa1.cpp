#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitSeurat.cpp"
char off__TEditDialog__Edit1[(int)(long)&(((TEditDialog*)0)->Edit1)+1];
char off__TEditDialog__Label1[(int)(long)&(((TEditDialog*)0)->Label1)+1];
char off__TEditDialog__Arvo[(int)(long)&(((TEditDialog*)0)->Arvo)+1];
