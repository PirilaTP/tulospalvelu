"""C-5 step 2A (Q8): can a comment-only change be proven not to alter bcc32 output?

For each selected unit: compile the recorded bcc32 command (outputs redirected) on a
scratch copy of the sources in four variants and compare the OMF objects record by
record with omf_cmp.compare().

  base   unchanged source
  base2  unchanged source, compiled again (determinism)
  cmt    ASCII comment lines inserted after line 1 + trailing comment on the first
         #include line (shifts all line numbers)
  code   base + one extra global definition at the end (must differ)

usage: python -I bcc_cmp.py <repo>/TPsource/V52/RADStudio10/build-logs <srccopy> <outdir> unit...
unit = <log name>:<source path as in the log>, e.g. HkKisaWin:..\\cbHk\\UnitEmit.cpp
"""
import os, re, sys, json, shutil, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import omf_cmp

logdir, srccopy, outdir = sys.argv[1:4]
units = sys.argv[4:]
outdir = os.path.abspath(outdir)
os.makedirs(outdir, exist_ok=True)


def short(p):
    import ctypes
    b = ctypes.create_unicode_buffer(1024)
    ctypes.windll.kernel32.GetShortPathNameW(p, b, 1024)
    return b.value


def recorded(log, src):
    t = open(os.path.join(logdir, log + '.log'), encoding='utf-8-sig', errors='replace').read().splitlines()
    for i, l in enumerate(t):
        m = re.match(r'bcc32 command line for "(.*)"$', l)
        if m and m.group(1).lower() == src.lower():
            parts = []
            j = i + 1
            while j < len(t) and t[j].startswith('  '):
                parts.append(t[j][2:])
                j += 1
            return ''.join(parts).rstrip()
    raise SystemExit('not found: %s %s' % (log, src))


def variant(raw, kind):
    nl = b'\r\n' if b'\r\n' in raw else b'\n'
    if kind in ('base', 'base2'):
        return raw
    lines = raw.split(nl)
    if kind == 'code':
        # before the first #include: some files end with a ^Z (0x1A) EOF byte, so an
        # appended line would be ignored by the compiler
        for k, l in enumerate(lines):
            if l.lstrip().startswith(b'#include'):
                lines.insert(k, b'int c5_probe_dummy_definition = 1;')
                break
        return nl.join(lines)
    for k, l in enumerate(lines):
        if l.lstrip().startswith(b'#include'):
            lines[k] = l + b' // C-5 probe: trailing comment'
            break
    lines.insert(1, b'// C-5 probe: inserted comment line 1')
    lines.insert(2, b'/* C-5 probe: inserted block comment */')
    return nl.join(lines)


results = []
for u in units:
    log, src = u.split(':', 1)
    cmd = recorded(log, src)
    wd = os.path.join(srccopy, 'RADStudio10')
    srcpath = os.path.normpath(os.path.join(wd, src))
    orig = open(srcpath, 'rb').read()
    objs = {}
    try:
        for kind in ('base', 'base2', 'cmt', 'code'):
            od = os.path.join(outdir, log, os.path.basename(src) + '.' + kind)
            if os.path.isdir(od):
                shutil.rmtree(od)
            os.makedirs(od)
            od = short(od)
            assert od and ' ' not in od, od
            obj = os.path.join(od, 'u.obj')
            open(srcpath, 'wb').write(variant(orig, kind))
            c = re.sub(r' -o\S+', lambda _: ' -o' + obj, cmd, count=1)
            c = re.sub(r' -n\S+', lambda _: ' -n' + od, c, count=1)
            c = re.sub(r' -H=\S+', lambda _: ' -H=' + os.path.join(od, 'p.pch'), c, count=1)
            exe, rest = c.split('.exe ', 1)
            line = '"' + exe + '.exe" ' + rest
            p = subprocess.run(line, cwd=wd, capture_output=True, text=True, encoding='cp1252', errors='replace')
            open(os.path.join(od, 'out.txt'), 'w', encoding='utf-8').write(line + '\n' + p.stdout + p.stderr)
            if p.returncode:
                raise SystemExit('compile failed %s %s rc=%d' % (u, kind, p.returncode))
            objs[kind] = obj
    finally:
        open(srcpath, 'wb').write(orig)
    r = {'unit': u}
    for kind in ('base2', 'cmt', 'code'):
        r[kind] = omf_cmp.compare(objs['base'], objs[kind])
    results.append(r)
    print(u, {k: (r[k]['equal_code'], r[k]['raw_equal'], r[k]['differing_kinds']) for k in ('base2', 'cmt', 'code')}, flush=True)
json.dump(results, open(os.path.join(outdir, 'results.json'), 'w'), indent=1)
