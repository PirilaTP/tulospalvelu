#include <stdio.h>
#include <string.h>
#include <locale.h>
#include <ctype.h>
#include <wctype.h>
#include <stdlib.h>
int main(int argc,char**argv){
 int k = argc>1 ? atoi(argv[1]) : 0;
 printf("tolower(0x20AC)=%X tolower(0x178)=%X tolower(0x100)=%X tolower(-28)=%X tolower(0xC4)=%X toupper(0x20AC)=%X toupper(-28)=%X\n",(unsigned)tolower(0x20AC),(unsigned)tolower(0x178),(unsigned)tolower(0x100),(unsigned)tolower(-28),(unsigned)tolower(0xC4),(unsigned)toupper(0x20AC),(unsigned)toupper(-28));
 fflush(stdout);
 if(k==1){ wchar_t *w=_wsetlocale(LC_CTYPE,L"fi-FI"); printf("wset CTYPE fi-FI %s towupper(E4)=%X toupper(E4)=%X\n",w?"ok":"NULL",(unsigned)towupper(0xE4),(unsigned)toupper(0xE4)); }
 if(k==2){ wchar_t *w=_wsetlocale(LC_ALL,L"Finnish_Finland.1252"); printf("wset ALL Finnish %s towupper(E4)=%X\n",w?"ok":"NULL",(unsigned)towupper(0xE4)); }
 if(k==3){ wchar_t *w=_wsetlocale(LC_ALL,L""); printf("wset ALL '' %s towupper(E4)=%X\n",w?"ok":"NULL",(unsigned)towupper(0xE4)); }
 return 0;}
