// Q61 probe: which classes does /d1reportAllClassLayout report?
struct Used { char a; int b; };                       // global, used
struct Unused { char a; double b; };                  // global, never used
template<class T> struct Tpl { char a; T b; };        // template, never instantiated
template<class T> struct TplI { char a; T b; };       // instantiated and used
template<> struct TplI<char> { char x; };             // explicit specialisation, unused
struct HasUnusedSpec { TplI<short> m; };              // implicit TplI<short>, via member
typedef Tpl<double> TplDoubleName;                    // typedef only, no object (implicit spec declared but not complete?)
namespace { struct AnonNs { char a; long long b; }; } // unnamed namespace, unused
struct Outer { struct Inner { char a; short b; }; int c; };   // nested, unused
union UnionU { char a; int b; };                      // union, unused
int main() {
  struct Local { char a; int b; short c; };           // local class, used
  struct LocalUnused { char a; long long b; };        // local class, unused
  Local l; Used u; TplI<int> t; (void)sizeof(Tpl<int>);   // sizeof forces Tpl<int>
  return (int)(sizeof(l) + sizeof(u) + sizeof(t));
}
