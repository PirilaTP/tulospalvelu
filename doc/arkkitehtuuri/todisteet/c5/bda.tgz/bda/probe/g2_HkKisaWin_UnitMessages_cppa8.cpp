#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitMessages.cpp"
char off__TFormMessages__Memo1[(int)(long)&(((TFormMessages*)0)->Memo1)+1];
