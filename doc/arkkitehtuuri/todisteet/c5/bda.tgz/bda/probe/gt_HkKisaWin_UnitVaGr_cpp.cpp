#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitVaGr.cpp"
char sz__TFormVaGr[(int)sizeof(TFormVaGr)];
