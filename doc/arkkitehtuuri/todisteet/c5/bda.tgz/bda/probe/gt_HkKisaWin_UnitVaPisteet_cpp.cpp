#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitVaPisteet.cpp"
char sz__TFormVaToisto[(int)sizeof(TFormVaToisto)];
