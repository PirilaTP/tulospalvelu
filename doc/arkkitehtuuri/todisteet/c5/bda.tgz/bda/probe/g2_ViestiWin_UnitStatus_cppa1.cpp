#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitStatus.cpp"
char off__TFormYhteysStatus__YhteysGrid[(int)(long)&(((TFormYhteysStatus*)0)->YhteysGrid)+1];
