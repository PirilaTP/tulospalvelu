#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/cbTpApu.cpp"
char sz__TFormAnnaAika[(int)sizeof(TFormAnnaAika)];
char sz__TFormAnnaArvo[(int)sizeof(TFormAnnaArvo)];
char sz__TFormAnnaTeksti[(int)sizeof(TFormAnnaTeksti)];
char sz__TFormIlmoitus[(int)sizeof(TFormIlmoitus)];
char sz__TFormMsgs[(int)sizeof(TFormMsgs)];
char sz__TValitse[(int)sizeof(TValitse)];
