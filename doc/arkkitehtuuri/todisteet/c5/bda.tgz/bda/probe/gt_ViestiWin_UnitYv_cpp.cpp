#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitYv.cpp"
char sz__TFormYhtveto[(int)sizeof(TFormYhtveto)];
