import sys,os,re,collections
D=chr(36); HASH=re.compile('['+D+'][a-z]{8}')
out=sys.argv[1];bad=[];n=0;ident=0;reord=0;miss=0
SIDE=re.compile('^[ ]+(extrn|[?]debug C)')
def norm(p):
    L=[HASH.sub('H',l) for l in open(p,encoding='cp1252',errors='replace').read().split(chr(10))]
    return [l for l in L if not SIDE.match(l)], collections.Counter(l for l in L if SIDE.match(l))
for f in sorted(os.listdir(out+'/pch')):
    if not f.endswith('.asm'): continue
    a=out+'/pch/'+f;b=out+'/nopch/'+f
    n+=1
    ca,sa=norm(a);cb,sb=norm(b)
    if open(a,'rb').read()==open(b,'rb').read(): ident+=1
    elif ca==cb and sa==sb: reord+=1
    else: bad.append(f)
print('units',n,'byte-identical',ident,'identical after normalising hash labels and extrn/debug order',reord,'DIFFERENT',len(bad))
for f in bad: print(' ',f)
