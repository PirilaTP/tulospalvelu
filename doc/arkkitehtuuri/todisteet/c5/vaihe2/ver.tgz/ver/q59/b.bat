@echo off
set BIN=c:\program files (x86)\embarcadero\studio\37.0\bin
"%BIN%\bcc32.exe" @tf.args -S -n. C:\dev\tulospalvelu\TPsource\V52\tputilv2\TextFileClass.cpp > cc.txt 2>&1
