#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/HkWinApu.cpp"
char off__TFormAnnaAika__EdAika[(int)(long)&(((TFormAnnaAika*)0)->EdAika)+1];
char off__TFormAnnaAika__Button1[(int)(long)&(((TFormAnnaAika*)0)->Button1)+1];
char off__TFormAnnaAika__Button2[(int)(long)&(((TFormAnnaAika*)0)->Button2)+1];
char off__TFormAnnaAika__LblPrompt[(int)(long)&(((TFormAnnaAika*)0)->LblPrompt)+1];
char off__TFormAnnaAika__Len[(int)(long)&(((TFormAnnaAika*)0)->Len)+1];
char off__TFormAnnaAika__T0[(int)(long)&(((TFormAnnaAika*)0)->T0)+1];
char off__TFormAnnaAika__Aika[(int)(long)&(((TFormAnnaAika*)0)->Aika)+1];
char off__TFormAnnaArvo__EdArvo[(int)(long)&(((TFormAnnaArvo*)0)->EdArvo)+1];
char off__TFormAnnaArvo__Button1[(int)(long)&(((TFormAnnaArvo*)0)->Button1)+1];
char off__TFormAnnaArvo__Button2[(int)(long)&(((TFormAnnaArvo*)0)->Button2)+1];
char off__TFormAnnaArvo__LblPrompt[(int)(long)&(((TFormAnnaArvo*)0)->LblPrompt)+1];
char off__TFormAnnaArvo__Arvo[(int)(long)&(((TFormAnnaArvo*)0)->Arvo)+1];
char off__TValitse__Sanoma[(int)(long)&(((TValitse*)0)->Sanoma)+1];
char off__TValitse__Optiot[(int)(long)&(((TValitse*)0)->Optiot)+1];
char off__TValitse__Valittu[(int)(long)&(((TValitse*)0)->Valittu)+1];
char off__TValitse__OKBtn[(int)(long)&(((TValitse*)0)->OKBtn)+1];
char off__TValitse__Label1[(int)(long)&(((TValitse*)0)->Label1)+1];
char off__TValitse__opts[(int)(long)&(((TValitse*)0)->opts)+1];
char off__TValitse__val[(int)(long)&(((TValitse*)0)->val)+1];
char off__TFormSelect3__Sanoma[(int)(long)&(((TFormSelect3*)0)->Sanoma)+1];
char off__TFormSelect3__Button1[(int)(long)&(((TFormSelect3*)0)->Button1)+1];
char off__TFormSelect3__Button2[(int)(long)&(((TFormSelect3*)0)->Button2)+1];
char off__TFormSelect3__Button3[(int)(long)&(((TFormSelect3*)0)->Button3)+1];
char off__TFormSelect3__selResult[(int)(long)&(((TFormSelect3*)0)->selResult)+1];
char off__TFormMessages__Memo1[(int)(long)&(((TFormMessages*)0)->Memo1)+1];
