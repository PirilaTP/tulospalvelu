# Read-only scanner: non-ASCII bytes inside string/char literals (outside comments), per file. No backslashes in this source on purpose.
import sys, os, json, collections
sys.stdout.reconfigure(encoding='utf-8')
BS=bytes([92]); NL=bytes([10]); DQ=bytes([34]); SQ=bytes([39])
inv = json.load(open('inv.json', encoding='utf-8'))
root = 'C:/dev/tulospalvelu/TPsource/V52'
def scan(b):
    i=0; n=len(b); line=1; out=[]
    while i<n:
        c=b[i:i+1]
        if c==NL: line+=1; i+=1; continue
        if b[i:i+2]==b'//':
            while i<n and b[i:i+1]!=NL:
                if b[i:i+1]==BS and b[i+1:i+2]==NL: line+=1; i+=1
                i+=1
            continue
        if b[i:i+2]==b'/*':
            j=b.find(b'*/',i+2); j=n if j<0 else j+2
            line+=b[i:j].count(NL); i=j; continue
        if c in (DQ,SQ):
            q=c; pre=b[i-1:i] if i>0 and b[i-1:i] in (b'L',b'u',b'U') else b''
            j=i+1; start=i
            while j<n and b[j:j+1]!=q and b[j:j+1]!=NL:
                if b[j:j+1]==BS: j+=1
                j+=1
            lit=b[start:j+1]
            if any(x>127 for x in lit):
                out.append((line,'str' if q==DQ else 'chr',pre.decode(),lit))
            i=j+1; continue
        i+=1
    return out
def dec(lit):
    try: return lit.decode('utf-8'),'u8'
    except Exception: return lit.decode('cp1252',errors='replace'),'cp'
res=[]
for f in inv['files']:
    p=f['path']
    if not p.lower().endswith(('.c','.cpp','.h','.hpp')): continue
    if f['encoding'] not in ('utf-8','utf-8-bom','mixed'): continue
    b=open(os.path.join(root,p),'rb').read()
    for line,kind,pre,lit in scan(b):
        txt,e=dec(lit)
        res.append(dict(path=p,enc=f['encoding'],line=line,kind=kind,wide=(pre=='L'),litenc=e,text=txt[:70],fffd=chr(0xfffd) in txt,projects=[x.split('/')[-1] for x in f['projects']]))
json.dump(res,open('lits.json','w',encoding='utf-8'),ensure_ascii=False,indent=0)
print(len(res))
c=collections.Counter((r['enc'],r['kind'],r['wide'],r['litenc']) for r in res)
for k,v in sorted(c.items()): print(k,v)
print(len(set(r['path'] for r in res)),'files')
