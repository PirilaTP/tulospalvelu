#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/UnitAvausMaar.cpp"
char sz__TFormAvausMaar[(int)sizeof(TFormAvausMaar)];
