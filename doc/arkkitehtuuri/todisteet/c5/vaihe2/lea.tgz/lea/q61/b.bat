@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars32.bat" >nul 2>&1
cd /d "%~dp0"
cl /nologo /c /EHsc /d1reportAllClassLayout rl.cpp > rl.out 2>&1
cl /nologo /c /EHsc /O2 /GL /d1reportAllClassLayout /Fo:rl2.obj rl.cpp > rl_gl.out 2>&1
