#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/ViestiWin/UnitSeurGr.cpp"
char off__TSeurantaForm__JoukkList[(int)(long)&(((TSeurantaForm*)0)->JoukkList)+1];
char off__TSeurantaForm__Label1[(int)(long)&(((TSeurantaForm*)0)->Label1)+1];
char off__TSeurantaForm__EdMaxLkm[(int)(long)&(((TSeurantaForm*)0)->EdMaxLkm)+1];
char off__TSeurantaForm__PaivitaButton[(int)(long)&(((TSeurantaForm*)0)->PaivitaButton)+1];
char off__TSeurantaForm__PiirraBtn[(int)(long)&(((TSeurantaForm*)0)->PiirraBtn)+1];
char off__TSeurantaForm__OsVal[(int)(long)&(((TSeurantaForm*)0)->OsVal)+1];
char off__TSeurantaForm__GroupBox1[(int)(long)&(((TSeurantaForm*)0)->GroupBox1)+1];
char off__TSeurantaForm__AlinOs[(int)(long)&(((TSeurantaForm*)0)->AlinOs)+1];
char off__TSeurantaForm__YlinOs[(int)(long)&(((TSeurantaForm*)0)->YlinOs)+1];
char off__TSeurantaForm__Label3[(int)(long)&(((TSeurantaForm*)0)->Label3)+1];
char off__TSeurantaForm__Label4[(int)(long)&(((TSeurantaForm*)0)->Label4)+1];
char off__TSeurantaForm__ViivaVal[(int)(long)&(((TSeurantaForm*)0)->ViivaVal)+1];
char off__TSeurantaForm__Label5[(int)(long)&(((TSeurantaForm*)0)->Label5)+1];
char off__TSeurantaForm__SarjaVal[(int)(long)&(((TSeurantaForm*)0)->SarjaVal)+1];
char off__TSeurantaForm__Osuus[(int)(long)&(((TSeurantaForm*)0)->Osuus)+1];
char off__TSeurantaForm__seur_CriticalSection[(int)(long)&(((TSeurantaForm*)0)->seur_CriticalSection)+1];
char off__TSeurantaForm__paivitysflag[(int)(long)&(((TSeurantaForm*)0)->paivitysflag)+1];
char off__TSeurantaForm__listaPyynto[(int)(long)&(((TSeurantaForm*)0)->listaPyynto)+1];
char off__TSeurantaForm__piirraPyynto[(int)(long)&(((TSeurantaForm*)0)->piirraPyynto)+1];
char off__TSeurantaForm__Kohde[(int)(long)&(((TSeurantaForm*)0)->Kohde)+1];
