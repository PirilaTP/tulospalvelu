#include "C:/dev/tulospalvelu/TPsource/V52/cbHk/MuotoiluUnit.cpp"
char sz__TFormMuotoilu[(int)sizeof(TFormMuotoilu)];
