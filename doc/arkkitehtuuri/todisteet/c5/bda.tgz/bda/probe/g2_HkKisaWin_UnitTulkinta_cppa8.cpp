#define private public
#define protected public
#include "C:/dev/tulospalvelu/TPsource/V52/cbTp/UnitTulkinta.cpp"
char off__TFormTulkinta__SG1[(int)(long)&(((TFormTulkinta*)0)->SG1)+1];
char off__TFormTulkinta__Label1[(int)(long)&(((TFormTulkinta*)0)->Label1)+1];
char off__TFormTulkinta__EdtTietue[(int)(long)&(((TFormTulkinta*)0)->EdtTietue)+1];
char off__TFormTulkinta__BtnHyvaksy[(int)(long)&(((TFormTulkinta*)0)->BtnHyvaksy)+1];
char off__TFormTulkinta__BtnLueloput[(int)(long)&(((TFormTulkinta*)0)->BtnLueloput)+1];
char off__TFormTulkinta__BtnOhita[(int)(long)&(((TFormTulkinta*)0)->BtnOhita)+1];
char off__TFormTulkinta__BtnKeskeyta[(int)(long)&(((TFormTulkinta*)0)->BtnKeskeyta)+1];
char off__TFormTulkinta__LblSanoma[(int)(long)&(((TFormTulkinta*)0)->LblSanoma)+1];
char off__TFormTulkinta__Vastaus[(int)(long)&(((TFormTulkinta*)0)->Vastaus)+1];
