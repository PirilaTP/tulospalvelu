"""C-5 step 2A re-test after the review: the fixed vertaa_omf.py must report a
difference when #pragma resource / package(smart_init) is commented out or a
#pragma link is added in cbHk/UnitEmit.cpp (HkKisaWin options), and still EQUAL for
an unchanged rebuild. usage: python -I pragma_test.py <build-logs> <srccopy> <outdir> <vertaa_omf.py>"""
import os, re, sys, subprocess, ctypes, shutil, importlib.util
logdir, srccopy, outdir, tool = sys.argv[1:5]
spec = importlib.util.spec_from_file_location('v', tool)
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)


def short(p):
    b = ctypes.create_unicode_buffer(1024)
    ctypes.windll.kernel32.GetShortPathNameW(p, b, 1024)
    return b.value


t = open(os.path.join(logdir, 'HkKisaWin.log'), encoding='utf-8-sig', errors='replace').read().splitlines()
i = [k for k, l in enumerate(t) if l == 'bcc32 command line for "..\\cbHk\\UnitEmit.cpp"'][0]
parts, j = [], i + 1
while t[j].startswith('  '):
    parts.append(t[j][2:])
    j += 1
cmd = ''.join(parts).rstrip()
wd = os.path.join(srccopy, 'RADStudio10')
src = os.path.join(srccopy, 'cbHk', 'UnitEmit.cpp')
orig = open(src, 'rb').read()
assert orig.count(b'#pragma resource "*.dfm"') == 1 and orig.count(b'#pragma package(smart_init)') == 1
variants = {
    'base': orig, 'base2': orig,
    'no_resource': orig.replace(b'#pragma resource "*.dfm"', b'//#pragma resource "*.dfm"'),
    'no_smart_init': orig.replace(b'#pragma package(smart_init)', b'//#pragma package(smart_init)'),
    'add_link': orig.replace(b'#pragma package(smart_init)', b'#pragma package(smart_init)\r\n#pragma link "c5probe.obj"'),
}
objs = {}
try:
    for name, body in variants.items():
        od = os.path.join(outdir, 'pragma_' + name)
        shutil.rmtree(od, ignore_errors=True)
        os.makedirs(od)
        od = short(od)
        open(src, 'wb').write(body)
        obj = os.path.join(od, 'UnitEmit.obj')
        c = re.sub(r' -o\S+', lambda _: ' -o' + obj, cmd, count=1)
        c = re.sub(r' -n\S+', lambda _: ' -n' + od, c, count=1)
        c = re.sub(r' -H=\S+', lambda _: ' -H=' + os.path.join(od, 'p.pch'), c, count=1)
        exe, rest = c.split('.exe ', 1)
        r = subprocess.run('"' + exe + '.exe" ' + rest, cwd=wd, capture_output=True, text=True)
        assert r.returncode == 0, r.stdout + r.stderr
        objs[name] = obj
finally:
    open(src, 'wb').write(orig)
for name in variants:
    if name != 'base':
        print('base vs %s:' % name, v.compare(objs['base'], objs[name]) or 'EQUAL')
